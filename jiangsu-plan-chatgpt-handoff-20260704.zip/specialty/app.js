(function(){
'use strict';
const VERSION='专科版｜V1.1.68 当前学生同步修复版';
const SUPABASE_URL='https://qnspmqsrbjcgrgpqkzgl.supabase.co';
const SUPABASE_ANON_KEY='sb_publishable_pVjv5t2S338SsCW98VvwpA_PcpXBL7V';
const ADMIN_EMAIL='ycxukun@gmail.com';
const GISCUS_CONFIG={
  repo:'ycxukun/jiangsu-plan',
  repoId:'R_kgDOTIG-gg',
  category:'批注',    // GitHub Discussions 分类名
  categoryId:'DIC_kwDOTIG-gs4DAM7P',
  theme:'light',
  lang:'zh-CN'
};
const disciplineOrder=["交通运输大类", "电子与信息大类", "装备制造大类", "医药卫生大类", "财经商贸大类", "教育与体育大类", "公安与司法大类", "能源动力与材料大类", "土木建筑大类", "食品药品与粮食大类", "轻工纺织大类", "生物与化工大类", "新闻传播大类", "文化艺术大类", "旅游大类", "公共管理与服务大类", "水利大类", "资源环境与安全大类", "农林牧渔大类", "其他大类", "其他"];
const hotOrder=["铁道运输类", "城市轨道交通类", "道路运输类", "航空运输类", "水上运输类", "计算机类", "电子信息类", "通信类", "集成电路类", "电气自动化类", "自动化类", "护理类", "临床医学类", "医学技术类", "药学类", "财务会计类", "金融类", "教育类", "体育类", "机械设计制造类", "机电设备类", "汽车制造类", "新能源发电工程类"];
const provinceRegionGroups=[
  {title:'华东',items:['江苏','上海','浙江','安徽','福建','山东','江西']},
  {title:'华北',items:['北京','天津','河北','山西','内蒙古']},
  {title:'华中',items:['湖北','湖南','河南']},
  {title:'华南',items:['广东','广西','海南','香港']},
  {title:'西南',items:['四川','重庆','贵州','云南','西藏']},
  {title:'西北',items:['陕西','甘肃','青海','宁夏','新疆']},
  {title:'东北',items:['辽宁','吉林','黑龙江']}
];
const JIANGSU_CITY_GROUPS=[
  {title:'苏南',items:['南京','苏州','无锡','常州','镇江']},
  {title:'苏中',items:['扬州','南通','泰州']},
  {title:'苏北',items:['徐州','盐城','淮安','连云港','宿迁']}
];
const JIANGSU_CITIES=JIANGSU_CITY_GROUPS.flatMap(g=>g.items);
const levelFacetGroups=[
  {title:'专科层次',items:['职业本科','高水平','专科公办','专科民办','本科公办','公办','民办']},
  {title:'强势方向',items:['铁道轨交','信息技术','医药护理','电力能源','师范教育','公安司法']},
  {title:'特殊性质',items:['中外合作','联合培养','高收费','定向/军士','航海轮机']}
];
const specialTypeFacetGroups=[
  {title:'重点特殊类型',items:['定向军士男','3+2','5+0','中外合作','定向医学','司法警察男','司法警察女','石邮连云港','石邮扬州','石邮淮安','石邮镇江','定向军士女','石邮南通','石邮宿迁']},
  {title:'合作与培养模式',items:['联合培养','高收费','境外/国际培养','校企合作/产教融合']},
  {title:'政策与特殊招生',items:['定向/军士','定向/公费/优师','专项计划','民族班/预科','军警航海']},
  {title:'特殊班型',items:['实验班/拔尖班','双学位/本博硕博']}
];

const MEDICAL_CODE_META={
  '11':'严重心脏病、心肌病、高血压病：学校可以不予录取',
  '12':'重症支气管扩张、哮喘、恶性肿瘤、慢性肾炎、尿毒症：学校可以不予录取',
  '13':'严重血液、内分泌、代谢系统疾病、风湿性疾病：学校可以不予录取',
  '14':'重症或难治性癫痫、严重精神病等：学校可以不予录取',
  '15':'慢性肝炎且肝功能不正常：学校可以不予录取',
  '16':'结核病相关限制：学校可以不予录取',
  '21':'色弱：化学、化工、药学、生物、医学、食品、农林、水产、心理、材料类、建筑/风景园林、纺织服装、艺术设计等按严格风控口径限报',
  '22':'色盲：含色弱全部严格限制，另含美术、绘画、设计、摄影、动画、地理、交通运输、油气储运等限报',
  '23':'单色识别异常：含色弱/色盲全部限制，另含经管、公共管理、图书档案；显示器颜色识别异常下计算机相关专业限报',
  '24':'裸眼视力任一眼低于5.0：飞行技术、航海技术、消防工程、刑事科学技术、侦察等不能录取',
  '25':'裸眼视力任一眼低于4.8：轮机工程、运动训练、民族传统体育等不能录取',
  '26':'公安院校普通专业身体条件：公安学、公安技术、刑事科学、侦查等需重点限报',
  '31':'主要脏器手术或相关病史：地矿、水利、交通、能动、公安、体育、海洋、大气、水产、测绘、环境、土木等不宜就读',
  '32':'先天性心脏病术后或轻微缺损：不宜就读同31类专业',
  '33':'肢体残疾不继续恶化：不宜就读同31类专业',
  '34':'矫正到4.8且镜片度数>400：海洋、测控、核工、生医工、服装、飞行器制造等不宜就读',
  '35':'矫正到4.8且镜片度数>800：地矿、水利、土建、材料、能动、化工、医学、电子信息科学、测绘、交通、船舶、生物工程等不宜就读',
  '36':'一眼失明且另一眼矫正到4.8镜片度数>400：工学、农学、医学、法学及部分理学专业不宜就读',
  '37':'双耳听力均3米以内或一耳5米另一耳全聋：法学、外语、新闻、学前、音乐、土木、交通、动物、医学等不宜就读',
  '38':'嗅觉迟钝、口吃、步态异常、驼背、面部疤痕等：教育、公安、外交、法学、新闻、音乐表演、表演等不宜就读',
  '39':'斜视、嗅觉迟钝、口吃：医学类专业不宜就读'
};
let DB=Array.isArray(window.DB)?window.DB:[];
let DETAILS=window.MAJOR_DETAILS||{};
let GROUP_NAMING=window.GROUP_NAMING||{};
let GROUP_CHANGES=window.GROUP_CHANGES||{};
let ASSASSIN_GROUP_RISKS=window.ASSASSIN_GROUP_RISKS||{};
let ASSASSIN_MAJOR_RISKS=window.ASSASSIN_MAJOR_RISKS||{};
let ASSASSIN_RISK_AUTHORITATIVE=Boolean(window.ASSASSIN_RISK_AUTHORITATIVE);
let ASSASSIN_RISK_STRICT_V03=Boolean(window.ASSASSIN_RISK_STRICT_V03);
let state={batch:'',subject:'',selectedProvinces:new Set(),selectedCities:new Set(),selectedLevels:new Set(),selectedSpecialTypes:new Set(),specialTypeMode:'exclude',selectedRequirements:new Set(),requirementAutoFromStudent:false,role:'',mode:'schools',q:'',selectedClasses:new Set(),scoreRange:null,medicalCodes:new Set(loadMedicalRestrictionCodes()),compact:true,activeSchoolId:null,filtered:[]};
let notes={schools:{},groups:{},majors:{}};
let auth={accessToken:'',user:null};
let currentStudent=null;
let currentVolunteerForm=null;
const AUTH_STORAGE_KEY='js-plan-auth-v1';
const CURRENT_STUDENT_STORAGE_KEY='js-plan-current-student-v1';
const VOLUNTEER_LIMIT=40;
const MAX_MAJOR_PER_GROUP=6;
const VOLUNTEER_STORAGE_KEY='js-plan-volunteer-groups-v1';
const VOLUNTEER_MAJOR_STORAGE_KEY='js-plan-volunteer-major-keys-v2';
const VOLUNTEER_META_STORAGE_KEY='js-plan-volunteer-meta-v1';
const VOLUNTEER_EDIT_FORM_STORAGE_KEY='js-plan-volunteer-edit-form-v1';
const MEDICAL_RESTRICTION_STORAGE_KEY='js-plan-medical-restriction-codes-v1';
const STUDENT_SUBJECT_CHOICES_STORAGE_KEY='js-plan-student-subject-choices-v1';
const SUBJECT_CHOICE_OPTIONS=['化学','生物','政治','地理'];
const VOLUNTEER_STAGE_STORAGE_SCOPE='specialty';
let volunteerKeys=loadVolunteerKeys();
let volunteerMajorKeys=loadVolunteerMajorKeys();
let volunteerMeta=loadVolunteerMeta();
let volunteerDragKey='';
let volunteerSearchQuery='';
let volunteerFilterMode='';
let volunteerAllExpanded=false;
let volunteerExpandedKeys=new Set();
let volunteerMajorPoolFilter={};
let groupIndex=new Map();
let majorRefs=[];
let majorRefsBySchool=new Map();
let majorRefsByBucket=new Map();
let rankRefsBySubjectBatch=new Map();
let predictionCache=new Map();
let schoolFacetCache=new Map();
let admissionPriorityCache=new Map();
const MANUAL_ADMISSION_PRIORITY_SCHOOL_HINTS=[
  {pattern:/中国地质大学/, severity:'high', rule:'人工重点提示：该校按专业志愿优先/专业优先类规则核对风险较高，专业顺序不能随意。最终以当年招生章程为准。'}
];
const $=sel=>document.querySelector(sel);
const $$=sel=>Array.from(document.querySelectorAll(sel));
const fmt=v=>v===null||v===undefined||v===''?'—':String(v);
const fmtNum=v=>v===null||v===undefined||v===''?'—':(typeof v==='number'?Number(v.toFixed? v.toFixed(1):v):v);
const num=v=>v===null||v===undefined||v===''?null:(Number.isFinite(Number(v))?Number(v):null);
const esc=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const keySchool=s=>`${s.subject}|${s.batch}|${s.name}`;
const keyGroup=(s,g)=>`${s.subject}|${s.batch}|${s.name}|${g.groupName}`;
const keyMajor=m=>m.key;
function storageJSON(key,fallback){try{const raw=localStorage.getItem(key); return raw?JSON.parse(raw):fallback;}catch(e){return fallback;}}
function normalizeSubjectChoices(values){
  const alias={'化':'化学','化学':'化学','生':'生物','生物':'生物','政':'政治','政治':'政治','思想政治':'政治','地':'地理','地理':'地理'};
  const raw=Array.isArray(values)?values:String(values||'').split(/[，,、\s/+]+/);
  const out=[];
  raw.forEach(function(v){const t=alias[String(v||'').trim()]; if(t&&!out.includes(t))out.push(t);});
  return out;
}
function studentSubjectChoiceStorageKey(){return STUDENT_SUBJECT_CHOICES_STORAGE_KEY+':'+(auth.user?.id||'guest');}
function studentSubjectChoiceMap(){const data=storageJSON(studentSubjectChoiceStorageKey(),{}); return data&&typeof data==='object'&&!Array.isArray(data)?data:{};}
function localStudentSubjectChoices(studentId){return studentId?normalizeSubjectChoices(studentSubjectChoiceMap()[studentId]||[]):[];}
function saveLocalStudentSubjectChoices(studentId,choices){
  if(!studentId)return;
  try{
    const data=studentSubjectChoiceMap();
    data[studentId]=normalizeSubjectChoices(choices);
    localStorage.setItem(studentSubjectChoiceStorageKey(),JSON.stringify(data));
  }catch(e){}
}
function studentSubjectChoices(student){return normalizeSubjectChoices(student?.subject_choices||student?.subjectChoices||localStudentSubjectChoices(student?.id));}
function subjectChoicesFromInputs(scope){return normalizeSubjectChoices($$('[data-subject-choice="'+scope+'"]:checked').map(function(el){return el.value;}));}
function subjectChoicesInputsHTML(scope,selected){
  const chosen=new Set(normalizeSubjectChoices(selected));
  return '<div class="subject-choice-row">'+SUBJECT_CHOICE_OPTIONS.map(function(v){return '<label><input type="checkbox" data-subject-choice="'+esc(scope)+'" value="'+esc(v)+'" '+(chosen.has(v)?'checked':'')+'>'+esc(v)+'</label>';}).join('')+'</div>';
}
function studentSubjectSummary(student){
  const choices=studentSubjectChoices(student);
  return subjectLabel(student?.subject_type)+(choices.length?'+'+choices.join('+'):'+未填再选');
}
function studentSubjectShortSummary(student){
  const choices=studentSubjectChoices(student);
  const type=subjectTypeValue(student?.subject_type)==='history'?'史':'物';
  const map={化学:'化',生物:'生',政治:'政',地理:'地'};
  return type+(choices.length?choices.map(function(x){return map[x]||String(x).slice(0,1);}).join(''):'未填');
}
function studentMedicalCodes(student){
  return parseMedicalCodes(Array.isArray(student?.medical_codes)?student.medical_codes.join(' '):(student?.medical_codes||''));
}
function studentMedicalSummary(student){
  const codes=studentMedicalCodes(student);
  return codes.length?codes.join('/'):'无体检代码';
}
function studentTopSummary(student){
  if(!student)return '';
  const parts=[];
  parts.push(studentSubjectSummary(student));
  if(student.score!==null&&student.score!==undefined&&student.score!=='')parts.push(`${student.score}分`);
  if(student.rank!==null&&student.rank!==undefined&&student.rank!=='')parts.push(`位次${student.rank}`);
  const codes=studentMedicalCodes(student);
  parts.push(codes.length?`体检${codes.join('/')}`:'体检未填');
  return parts.join('｜');
}
function medicalCodePickerHTML(scope,selected){
  const chosen=new Set(parseMedicalCodes(Array.isArray(selected)?selected.join(' '):selected));
  return `<div class="medical-picker-row" data-medical-picker="${esc(scope)}">${Object.keys(MEDICAL_CODE_META).map(c=>`<label title="${esc(MEDICAL_CODE_META[c]||'体检受限')}"><input type="checkbox" data-student-medical-code="${esc(scope)}" value="${esc(c)}" ${chosen.has(c)?'checked':''}>${esc(c)}</label>`).join('')}</div><div class="medical-picker-summary" data-student-medical-summary="${esc(scope)}"></div>`;
}
function studentMedicalCodesFromInputs(scope,inputSelector){
  const checked=$$(`[data-student-medical-code="${scope}"]:checked`).map(el=>el.value);
  const typed=inputSelector&&$(inputSelector)?parseMedicalCodes($(inputSelector).value):[];
  return [...new Set([...checked,...typed])].sort((a,b)=>Number(a)-Number(b));
}
function syncStudentMedicalPicker(scope,inputSelector){
  const summary=document.querySelector(`[data-student-medical-summary="${scope}"]`);
  if(!summary)return;
  const codes=studentMedicalCodesFromInputs(scope,inputSelector);
  summary.innerHTML=codes.length?`已选：${codes.map(c=>`<b title="${esc(MEDICAL_CODE_META[c]||'体检受限')}">${esc(c)}</b>`).join('')}`:'未选择体检代码。可直接点选，也可手动输入。';
}
function bindStudentMedicalPickers(){
  const scopes=[...new Set($$('[data-student-medical-code]').map(el=>el.dataset.studentMedicalCode).filter(Boolean))];
  scopes.forEach(scope=>{
    const inputSelector=scope==='newStudentMedical'?'#newStudentMedical':scope==='editStudentMedical'?'#editStudentMedical':'';
    $$(`[data-student-medical-code="${scope}"]`).forEach(cb=>{
      cb.addEventListener('change',()=>syncStudentMedicalPicker(scope,inputSelector));
    });
    if(inputSelector&&$(inputSelector))$(inputSelector).addEventListener('input',()=>syncStudentMedicalPicker(scope,inputSelector));
    syncStudentMedicalPicker(scope,inputSelector);
  });
}
function subjectOptionForStudent(student){
  const select=$('#subjectFilter');
  const type=subjectTypeValue(student?.subject_type);
  if(!select)return '';
  const options=[...select.options].map(o=>o.value).filter(Boolean);
  return options.find(v=>type==='history'?String(v).includes('历史'):String(v).includes('物理'))||'';
}
function requirementMatchesStudent(req,student){
  const required=requirementSubjects(req);
  if(!required.length)return true;
  const choices=studentSubjectChoices(student);
  if(!choices.length)return false;
  const either=/或|任选|任一/.test(String(req||''));
  return either?required.some(x=>choices.includes(x)):required.every(x=>choices.includes(x));
}
function compatibleRequirementSetForStudent(student){
  const set=new Set();
  DB.forEach(s=>(s.groups||[]).forEach(g=>{
    const req=String(g.requirement||'').trim();
    if(req&&requirementMatchesStudent(req,student))set.add(req);
  }));
  return set;
}
function setScoreFilterFromStudent(student){
  const score=dbNumber(student?.score);
  if(score===null)return false;
  const down=Number($('#downInput')?.value||20)||20;
  const up=Number($('#upInput')?.value||30)||30;
  state.scoreRange={target:score,down,up,min:score-down,max:score+up};
  ['targetScoreRange','targetScoreInput'].forEach(id=>{const el=$('#'+id); if(el)el.value=score;});
  ['downRange','downInput'].forEach(id=>{const el=$('#'+id); if(el)el.value=down;});
  ['upRange','upInput'].forEach(id=>{const el=$('#'+id); if(el)el.value=up;});
  const btn=$('#scoreBtn');
  if(btn)btn.textContent=`分数 ${score-down}—${score+up}`;
  updateRangeSummary();
  return true;
}
function applyCurrentStudentProfileToFilters(options={}){
  if(!currentStudent){renderStudentContextBar();return false;}
  let changed=false;
  const subjectValue=subjectOptionForStudent(currentStudent);
  if(subjectValue&&state.subject!==subjectValue){state.subject=subjectValue;changed=true;}
  const subjectSelect=$('#subjectFilter');
  if(subjectSelect&&subjectValue)subjectSelect.value=subjectValue;
  const compatible=compatibleRequirementSetForStudent(currentStudent);
  state.selectedRequirements.clear();
  compatible.forEach(v=>state.selectedRequirements.add(v));
  state.requirementAutoFromStudent=true;
  updateRequirementButton();
  if(setScoreFilterFromStudent(currentStudent))changed=true;
  state.medicalCodes=new Set(studentMedicalCodes(currentStudent));
  saveMedicalRestrictionCodes();
  updateMedicalButton();
  cleanupVolunteerForMedicalRestrictions();
  cleanupVolunteerForSubjectRequirements();
  renderStudentContextBar();
  if(!options.noFilter)applyFilters();
  return changed;
}
function renderStudentContextBar(){
  const el=$('#studentContextBar');
  if(!el)return;
  if(!currentStudent){el.hidden=true;el.innerHTML='';return;}
  const codes=studentMedicalCodes(currentStudent);
  const cities=Array.isArray(currentStudent.target_cities)?currentStudent.target_cities:[];
  el.hidden=false;
  el.innerHTML=`<div class="student-context-main"><b>当前学生：${esc(currentStudent.name||'未命名')}</b><span>${esc(stageLabel(currentStudent.stage))}</span><span>${esc(studentSubjectSummary(currentStudent))}</span><span>${esc(currentStudent.score??'—')}分</span><span>位次 ${esc(currentStudent.rank??'—')}</span><span>${codes.length?'体检 '+esc(codes.join('/')):'体检未填'}</span>${cities.length?`<span>目标城市 ${esc(cities.join('、'))}</span>`:''}</div><div class="student-context-note">已自动同步：科类筛选、选科要求、目标分区间、体检受限。选科或体检不符合的专业/专业组将被限制选择。</div>`;
}

function requirementSubjects(req){
  const t=String(req||'').replace(/\s+/g,'');
  if(!t||/不限|无要求|任意/.test(t))return [];
  const out=[];
  if(/化学|化/.test(t))out.push('化学');
  if(/生物|生/.test(t))out.push('生物');
  if(/思想政治|政治|政/.test(t))out.push('政治');
  if(/地理|地/.test(t))out.push('地理');
  return [...new Set(out)];
}
function schoolSubjectType(s){
  const t=String(s?.subject||'');
  if(t.includes('历史'))return 'history';
  if(t.includes('物理'))return 'physics';
  return '';
}
function subjectRequirementBlockReason(s,g,student=currentStudent){
  if(!student)return '';
  const studentType=subjectTypeValue(student.subject_type);
  const groupType=schoolSubjectType(s);
  if(groupType&&studentType!==groupType)return '当前学生首选科目是'+subjectLabel(studentType)+'，不能选择'+subjectLabel(groupType)+'类专业组。';
  const required=requirementSubjects(g?.requirement);
  if(!required.length)return '';
  const choices=studentSubjectChoices(student);
  if(!choices.length)return '请先在学生档案填写再选科目：'+required.join('、')+'。';
  const either=/或|任选|任一/.test(String(g?.requirement||''));
  if(either&&required.some(function(x){return choices.includes(x);}))return '';
  const missing=either?required:required.filter(function(x){return !choices.includes(x);});
  if(either)return '当前学生选科为'+studentSubjectSummary(student)+'，不满足“'+g.requirement+'”要求，需包含'+required.join('或')+'之一。';
  return missing.length?'当前学生选科为'+studentSubjectSummary(student)+'，不满足“'+g.requirement+'”要求，缺少'+missing.join('、')+'。':'';
}
function volunteerStorageSuffix(){
  const userId=auth.user?.id||'guest';
  const studentId=currentStudent?.id||'no-student';
  return `${VOLUNTEER_STAGE_STORAGE_SCOPE}:${userId}:${studentId}`;
}
function scopedVolunteerKey(base){return `${base}:${volunteerStorageSuffix()}`;}
function currentStudentStorageKey(){return auth.user?.id?`${CURRENT_STUDENT_STORAGE_KEY}:${auth.user.id}`:CURRENT_STUDENT_STORAGE_KEY;}
function loadVolunteerKeys(){const arr=storageJSON(scopedVolunteerKey(VOLUNTEER_STORAGE_KEY),[]); return Array.isArray(arr)?arr.filter(x=>typeof x==='string').slice(0,VOLUNTEER_LIMIT):[];}
function saveVolunteerKeys(){try{localStorage.setItem(scopedVolunteerKey(VOLUNTEER_STORAGE_KEY),JSON.stringify(volunteerKeys));}catch(e){}}
function loadVolunteerMajorKeys(){const data=storageJSON(scopedVolunteerKey(VOLUNTEER_MAJOR_STORAGE_KEY),{}); return data&&typeof data==='object'&&!Array.isArray(data)?data:{};}
function saveVolunteerMajorKeys(){try{localStorage.setItem(scopedVolunteerKey(VOLUNTEER_MAJOR_STORAGE_KEY),JSON.stringify(volunteerMajorKeys));}catch(e){}}
function loadVolunteerMeta(){const data=storageJSON(scopedVolunteerKey(VOLUNTEER_META_STORAGE_KEY),{}); return data&&typeof data==='object'&&!Array.isArray(data)?data:{};}
function saveVolunteerMeta(){try{localStorage.setItem(scopedVolunteerKey(VOLUNTEER_META_STORAGE_KEY),JSON.stringify(volunteerMeta));}catch(e){}}
function consumeVolunteerEditFormRef(){
  const key=scopedVolunteerKey(VOLUNTEER_EDIT_FORM_STORAGE_KEY);
  const data=storageJSON(key,null);
  try{localStorage.removeItem(key);}catch(e){}
  return data?.id?data:null;
}
function saveCurrentVolunteerDraft(){saveVolunteerKeys();saveVolunteerMajorKeys();saveVolunteerMeta();}
function loadCurrentVolunteerDraft(){
  volunteerKeys=loadVolunteerKeys();
  volunteerMajorKeys=loadVolunteerMajorKeys();
  volunteerMeta=loadVolunteerMeta();
  currentVolunteerForm=consumeVolunteerEditFormRef();
  if(groupIndex.size)normalizeCurrentVolunteerDraft();
}
function normalizeCurrentVolunteerDraft(){
  volunteerKeys=[...new Set(volunteerKeys)].filter(k=>groupIndex.has(k)).slice(0,VOLUNTEER_LIMIT);
  volunteerKeys.forEach(ensureVolunteerSelection);
  Object.keys(volunteerMajorKeys).forEach(k=>{if(!volunteerKeys.includes(k))delete volunteerMajorKeys[k];});
  Object.keys(volunteerMeta).forEach(k=>{if(!volunteerKeys.includes(k))delete volunteerMeta[k];});
  saveCurrentVolunteerDraft();
}
function dbNumber(v){
  if(v===null||v===undefined||v==='')return null;
  const raw=typeof v==='number'?v:String(v).replace(/,/g,'').trim();
  const n=Number(raw);
  return Number.isFinite(n)?n:null;
}
function dbInteger(v){
  const n=dbNumber(v);
  return n===null?null:Math.round(n);
}
function parseMedicalCodes(raw){
  const valid=new Set(Object.keys(MEDICAL_CODE_META));
  return String(raw||'').split(/[^0-9]+/).map(x=>x.trim()).filter(Boolean).filter(x=>valid.has(x));
}
function loadMedicalRestrictionCodes(){try{return parseMedicalCodes(JSON.parse(localStorage.getItem(MEDICAL_RESTRICTION_STORAGE_KEY)||'[]').join(','));}catch(e){return [];}}
function saveMedicalRestrictionCodes(){try{localStorage.setItem(MEDICAL_RESTRICTION_STORAGE_KEY,JSON.stringify([...state.medicalCodes]));}catch(e){}}
function loadSavedAuth(){try{const data=JSON.parse(localStorage.getItem(AUTH_STORAGE_KEY)||'{}'); if(data&&data.accessToken&&data.user)auth={accessToken:data.accessToken,refreshToken:data.refreshToken||'',user:data.user};}catch(e){}}
function saveAuth(){try{localStorage.setItem(AUTH_STORAGE_KEY,JSON.stringify({accessToken:auth.accessToken||'',refreshToken:auth.refreshToken||'',user:auth.user||null}));}catch(e){}}
function clearSavedAuth(){try{localStorage.removeItem(AUTH_STORAGE_KEY);}catch(e){}}
function loadCurrentStudent(){
  try{
    const userId=auth.user?.id;
    if(!userId){currentStudent=null;return;}
    let data=storageJSON(currentStudentStorageKey(),null);
    const belongsToCurrentUser=row=>row&&row.id&&row.owner_id===userId;
    if(!belongsToCurrentUser(data)){
      data=null;
      const legacy=storageJSON(CURRENT_STUDENT_STORAGE_KEY,null);
      if(belongsToCurrentUser(legacy)){
        data=legacy;
        localStorage.setItem(currentStudentStorageKey(),JSON.stringify(legacy));
        localStorage.removeItem(CURRENT_STUDENT_STORAGE_KEY);
      }
    }
    currentStudent=data||null;
  }catch(e){currentStudent=null;}
}
function saveCurrentStudent(){try{currentStudent?localStorage.setItem(currentStudentStorageKey(),JSON.stringify(currentStudent)):localStorage.removeItem(currentStudentStorageKey());}catch(e){}}
function medicalCodesActive(){return state.medicalCodes&&state.medicalCodes.size>0;}
const coldMajorPattern=/材料|化工|化学类|应用化学|环境|生态|生物|食品|地质|地球物理|测绘|遥感|地理空间|土木|建筑|交通运输|安全|消防|矿|采矿|资源|海洋|农业|农学|林学|水产|动物|植物|草学|轻工|纺织|服装|旅游管理|酒店管理|外国语言|翻译|俄语|日语|法语|西班牙语|朝鲜语|印地语|哲学|历史学|考古|图书馆|档案|社会学|公共管理|行政管理|戏剧影视|广播电视编导/;
const hotMajorPattern=/计算机|软件|人工智能|智能科学|数据科学|网络空间|电子信息|通信工程|微电子|集成电路|电气工程|自动化|临床医学|口腔医学|法学|会计学|金融学|数学|统计/;
function normalize(s){return String(s??'').toLowerCase().replace(/\s+/g,'');}
function formatSigned(v){if(v===null||v===undefined||v==='')return '—'; return `${v>0?'+':''}${v}`;}
function signedClass(v){return v>0?'change-pos':v<0?'change-neg':'';}
function planChangeInline(v){if(v===null||v===undefined||v==='')return '—'; return `<span class="${signedClass(v)}">${formatSigned(v)}</span>`;}
function planDeltaBadge(v){if(v===null||v===undefined||v==='')return ''; const cls=signedClass(v); const label=v>0?'计划增加':v<0?'计划减少':'计划持平'; return `<span class="badge ${v>0?'green':v<0?'red':''} ${cls}">${label} ${formatSigned(v)}</span>`;}
function groupNamingMeta(s,g){
  const meta=GROUP_NAMING[keyGroup(s,g)]||null;
  return meta&&meta.sourceYear===2026?meta:null;
}
function classBucket(c){
  const t=String(c||'');
  if(/计算机|软件|网络空间|数据科学|智能科学/.test(t))return '计算机';
  if(/电子信息|通信|微电子|集成电路|光电|电子科学/.test(t))return '电子信息';
  if(/电气|自动化|机器人工程|仪器|测控/.test(t))return '电气自动化';
  if(/临床医学|口腔|医学技术|基础医学|中医学|药学|护理/.test(t))return '医药';
  if(/数学|统计|物理|天文|力学/.test(t))return '数理基础';
  if(/金融|经济|财政|经贸|工商管理|管理科学|会计|财务|电子商务|物流|工业工程/.test(t))return '经管';
  if(/法学|公安|马克思|政治|社会学/.test(t))return '法政公安';
  if(/中国语言|外国语言|新闻传播|历史|哲学|图书|戏剧|艺术/.test(t))return '文史语言新闻';
  if(/材料/.test(t))return '材料';
  if(/化学|化工|制药/.test(t))return '化工';
  if(/生物|食品|环境|生态|农学|林学|水产|动物|植物/.test(t))return '生物食品环境';
  if(/土木|建筑|交通|测绘|地理|地质|地球|海洋|矿业|安全/.test(t))return '土木建筑交通';
  if(/能源|核工程/.test(t))return '能源动力';
  if(/机械|车辆|航空航天|兵器/.test(t))return '机械车辆';
  if(/大类|试验|交叉/.test(t))return '试验班未细分';
  return t.replace(/类$/,'')||'其他未细分';
}
function groupBucketStats(g){
  const map=new Map();
  const add=(bucket,plan)=>{
    if(!bucket)return;
    const old=map.get(bucket)||{bucket,plan:0,count:0};
    old.plan+=Number(plan)||0;
    old.count+=1;
    map.set(bucket,old);
  };
  (g.majors||[]).forEach(m=>add(classBucket(m.majorClass||m.name),m.plan26||1));
  if(!map.size)(g.majorClasses||[]).forEach(c=>add(classBucket(c),1));
  return [...map.values()].sort((a,b)=>(b.plan-a.plan)||(b.count-a.count)||a.bucket.localeCompare(b.bucket,'zh-Hans-CN'));
}
function cooperationSuffix(g){
  const text=`${(g.tags||[]).join(' ')} ${g.remark||''} ${(g.majors||[]).map(m=>m.name).join(' ')}`;
  if(/中外合作|合作办学/.test(text))return '（中外合作）';
  if(/联合培养|双学位/.test(text))return '（联合培养）';
  return '';
}
function inferGroupName(g){
  const stats=groupBucketStats(g);
  const suffix=cooperationSuffix(g);
  if(!stats.length)return suffix.replace(/[（）]/g,'');
  const buckets=stats.map(x=>x.bucket);
  if(buckets.length===1)return `${buckets[0]}组${suffix}`;
  if(buckets.length<=4)return `${buckets.join('、')}复合组${suffix}`;
  return `${buckets.slice(0,4).join('、')}等混合组${suffix}`;
}
function groupDisplayName(s,g){return groupNamingMeta(s,g)?.name||inferGroupName(g);}
function groupDisplayTitleText(s,g){const name=groupDisplayName(s,g); return name?`${g.groupName} ${name}`:g.groupName;}
function groupTitleHTML(s,g){const name=groupDisplayName(s,g); return `${esc(g.groupName)}${name?` <span class="group-name-label">${esc(name)}</span>`:''}`;}
function normalizeAssassinRisk(raw,type){
  if(!raw)return null;
  if(Array.isArray(raw)){
    if(type==='group')return {tone:raw[0]||'green',label:raw[1]||'',level:raw[2]||'',reason:raw[3]||'',core:raw[4]||'',weak:raw[5]||'',edge:raw[6]||'',breakdown:raw[7]||'',clean:raw[8]||'',classes:raw[9]||''};
    return {tone:raw[0]||'green',label:raw[1]||'',level:raw[2]||'',reason:raw[3]||'',majorClass:raw[4]||'',normClass:raw[5]||'',core:raw[6]||'',distance:raw[7],heatDrop:raw[8],heatLevel:raw[9]};
  }
  return raw;
}
function assassinGroupMeta(s,g){
  const key=String(g?.groupCode||g?.schoolGroupCode||'');
  return normalizeAssassinRisk(ASSASSIN_GROUP_RISKS[key],'group');
}
function assassinMajorMeta(m){
  const keys=[m?.identityKey,`${m?.groupCode||''}+${m?.code||''}`].filter(Boolean).map(String);
  for(const k of keys){if(ASSASSIN_MAJOR_RISKS[k])return normalizeAssassinRisk(ASSASSIN_MAJOR_RISKS[k],'major');}
  return null;
}
function isRiskTone(t){return ['red','orange','yellow','blue','gray'].includes(String(t||''));}
function riskToneRank(t){return ({green:0,gray:1,blue:2,yellow:3,orange:4,red:5})[String(t||'green')]??0;}
function strongerRisk(a,b){
  if(!a)return b;
  if(!b)return a;
  if(Boolean(a.risk)!==Boolean(b.risk))return a.risk?a:b;
  return riskToneRank(b.tone)>riskToneRank(a.tone)?b:a;
}
function majorText(m){
  const d=DETAILS?.[m?.key]||{};
  return `${m?.baseName||''} ${m?.name||''} ${m?.majorClass||''} ${m?.discipline||''} ${d.name||''} ${d.undergraduateName||''} ${d.subjectMajor||''} ${d.majorClass||''} ${d.discipline||''}`;
}

function lectureTierMeta(m){
  const t=majorText(m);
  // 讲座口径：先区分“出口宽度/热度梯队”，再决定在信息类/新工科组里是否构成刺客风险。
  // 机械、光电、医工、航空航天、统计等属于二梯队宽口径，不能按土木/测绘/地质/食品等同级标红。
  if(/光电|光信息|光电子/.test(t))return {rank:2,label:'二梯队宽口径',bucket:'光电'};
  if(/生物医学工程|智能医学工程|医学信息工程|医工|医疗器械/.test(t))return {rank:2,label:'二梯队宽口径',bucket:'医工交叉'};
  if(/计算机|软件|网络空间|数据科学|人工智能|智能科学|信息安全|物联网|大数据/.test(t))return {rank:1,label:'一梯队宽口径',bucket:'计算机/AI'};
  if(/电子信息|通信|微电子|集成电路|电子科学|电气|自动化|机器人工程|智能制造|仪器|测控|智能感知/.test(t))return {rank:1,label:'一梯队宽口径',bucket:'电子电气自动化'};
  if(/机械|车辆|航空航天|飞行器|航天|航空/.test(t))return {rank:2,label:'二梯队宽口径',bucket:/机械|车辆/.test(t)?'机械':'航空航天'};
  if(/数学|信息与计算科学|物理|应用物理|统计/.test(t))return {rank:2,label:'二梯队理学基础',bucket:/统计/.test(t)?'统计':'数学/物理'};
  if(/临床医学|口腔医学|基础医学|医学影像|麻醉学|儿科学|眼视光医学|精神医学|放射医学/.test(t))return {rank:2,label:'二梯队医学',bucket:'医学'};
  if(/能源动力|能源与动力|新能源|储能|核工程|动力工程|船舶|海洋工程|兵器|武器|弹药|力学|工程力学|材料|冶金|高分子|无机非金属|管理科学与工程|信息管理与信息系统|石油|油气|交通运输|车辆工程|大气科学|化工|制药/.test(t))return {rank:3,label:'三梯队行业/窄口径',bucket:'三梯队行业方向'};
  if(/环境|生态|安全工程|消防|海洋科学|药学|测绘|遥感|地理信息|地理空间|地质|资源勘查|地球物理|食品|化学|应用化学|生物科学|生物技术|生物工程|土木|建筑|城乡规划|风景园林|矿业|采矿|农业|农学|林学|水产|动物|植物|轻工|纺织/.test(t))return {rank:4,label:'低热度/强行业限制',bucket:'低热度远缘方向'};
  if(/法学|汉语言|中国语言文学/.test(t))return {rank:1,label:'考公一梯队',bucket:'法汉'};
  if(/会计|财务管理|新闻传播|财政|税收|工商管理|经济|金融/.test(t))return {rank:2,label:'考公二梯队',bucket:'经管考公'};
  return {rank:0,label:'未归类',bucket:'其他'};
}
function isLectureTier1Major(m){return lectureTierMeta(m).rank===1&&/计算机|电子|电气|自动化|通信|集成电路|人工智能|软件|仪器|测控|智能/.test(majorText(m));}
function hasTier1InfoEngineeringCore(g){
  const majors=g?.majors||[];
  let corePlan=0,totalPlan=0,coreCount=0;
  majors.forEach(m=>{
    const w=num(m.plan26)||num(m.plan25)||1;
    totalPlan+=w;
    if(isLectureTier1Major(m)){corePlan+=w;coreCount+=1;}
  });
  const gt=groupText(g);
  return coreCount>=2||corePlan>=Math.max(8,totalPlan*0.28)||(/计算机|电子信息|电气|自动化|人工智能|机器人|通信|集成电路|新工科|智能|仪器|测控/.test(gt)&&coreCount>=1);
}

function isLectureTier2BroadCoreMajor(m){
  const tier=lectureTierMeta(m);
  return tier.rank===2&&/机械|光电|医工|航空航天|统计|医学/.test(tier.bucket||'');
}
function hasTier2BroadEngineeringCore(g){
  const majors=g?.majors||[];
  let corePlan=0,totalPlan=0,coreCount=0;
  majors.forEach(m=>{
    const w=num(m.plan26)||num(m.plan25)||1;
    totalPlan+=w;
    if(isLectureTier2BroadCoreMajor(m)){corePlan+=w;coreCount+=1;}
  });
  const gt=groupText(g);
  return coreCount>=1&&(corePlan>=Math.max(6,totalPlan*0.25)||/机械|光电|医工|航空航天|统计|医学/.test(gt));
}
function lowAcceptanceRiskCategory(m){
  const t=majorText(m);
  if(/土木|建筑|城乡规划|风景园林/.test(t))return {cat:'土木建筑类',tone:'red',label:'刺客'};
  if(/测绘|遥感|地理信息|地理空间|地质|资源勘查|地球物理|地球信息|矿业|采矿/.test(t))return {cat:'测绘地质类',tone:'red',label:'刺客'};
  if(/环境|生态|安全工程|消防|水利|水文|海洋科学|农业|农学|林学|植物|动物|水产|食品|轻工|纺织/.test(t))return {cat:'低接受度远缘方向',tone:'red',label:'刺客'};
  if(/材料|冶金|高分子|无机非金属|金属材料|化工|制药|化学|应用化学|生物科学|生物技术|生物工程/.test(t))return {cat:'材料化工生化类',tone:'orange',label:'异类刺客'};
  return null;
}
function lectureTierSoftensSourceRisk(m){
  const tier=lectureTierMeta(m);
  if(tier.rank!==2)return false;
  // 明确保留用户口径：机械/光电/医工/航空航天/统计/医学是二梯队宽口径或高难度专业，不能和土木、测绘、地质、食品等同级处理。
  return /机械|光电|医工|航空航天|统计|医学/.test(tier.bucket);
}
function groupText(g){
  return `${g?.groupName||''} ${g?.majorSummary||''} ${(g?.majorClasses||[]).join(' ')} ${(g?.tags||[]).join(' ')} ${(g?.majors||[]).map(m=>`${m.name||''} ${m.majorClass||''}`).join(' ')}`;
}
function isInfoNewEngineeringMajorText(t){
  return /计算机|软件|网络空间|数据科学|人工智能|智能科学|电子信息|通信|微电子|集成电路|光电|电子科学|电气|自动化|机器人工程|智能制造|信息安全|物联网|大数据/.test(t);
}
function hasInfoNewEngineeringCore(g){
  const majors=g?.majors||[];
  let corePlan=0,totalPlan=0,coreCount=0;
  majors.forEach(m=>{
    const w=num(m.plan26)||num(m.plan25)||1;
    const t=majorText(m);
    totalPlan+=w;
    if(isInfoNewEngineeringMajorText(t)){corePlan+=w;coreCount+=1;}
  });
  const gt=groupText(g);
  return coreCount>=2||corePlan>=Math.max(8,totalPlan*0.28)||(/计算机|电子信息|电气|自动化|人工智能|机器人|通信|集成电路|新工科|智能/.test(gt)&&coreCount>=1);
}
function strictRiskCategory(m){
  const t=majorText(m);
  const tier=lectureTierMeta(m);
  if(tier.rank===1)return null;
  // 二梯队内部要分开：机械/光电/医工/航空航天/统计不按刺客标红；数学/物理等理学基础放在信息类工科组里需要提示。
  if(tier.rank===2){
    if(/数学|物理/.test(tier.bucket))return {cat:'理学基础类',tone:'orange',label:'理学调剂'};
    return null;
  }
  if(/材料|冶金|高分子|无机非金属|金属材料/.test(t))return {cat:'材料类',tone:'orange',label:'异类刺客'};
  if(/能源动力|能源与动力|新能源|储能|核工程|动力工程|建筑环境与能源应用/.test(t))return {cat:'能源动力类',tone:'orange',label:'异类刺客'};
  if(/化学|应用化学|生物科学|地理科学|地理信息|地球物理|大气科学|海洋科学|心理学|力学/.test(t))return {cat:'理学/基础类',tone:'orange',label:'理学调剂'};
  if(tier.rank===3)return {cat:tier.bucket||'三梯队行业方向',tone:'orange',label:'异类刺客'};
  if(/测绘|遥感|地理空间|土木|建筑|城乡规划|地质|资源勘查|地球信息|矿业|采矿|安全工程|水利|水文|环境|生态|生物工程|食品|轻工|纺织|农业|林学|植物|动物|水产|化工|制药/.test(t))return {cat:'远缘低接受度方向',tone:'red',label:'刺客'};
  if(tier.rank===4)return {cat:tier.bucket||'低热度远缘方向',tone:'red',label:'刺客'};
  return null;
}
function strictContextRiskMeta(s,g,m){
  if(!g||!m)return null;
  if((g.majors||[]).length<=1)return null;
  const t=majorText(m);
  const detailHint='';
  if(hasTier1InfoEngineeringCore(g)){
    if(isInfoNewEngineeringMajorText(t))return null;
    const cat=strictRiskCategory(m);
    if(!cat)return null;
    return {risk:true,label:cat.label||(cat.tone==='red'?'刺客':'异类刺客'),type:'strict-assassin',tone:cat.tone,reason:`一梯队信息类/新工科主体专业组中夹入${cat.cat}。按讲座梯队口径，该方向与计算机、电子信息、电气、自动化等一梯队出口不一致，需要单独标注；机械、光电、医工、航空航天、统计等二梯队宽口径本身不按土木类同级标红，但组内远缘专业仍必须提示。${detailHint}`};
  }
  // V1.1.45：二梯队宽口径主体组也要做“组内最差专业”风控。机械不是土木，但机械组里夹土木/建筑/测绘/地质/环境/食品等，必须把这些远缘专业标出来。
  if(hasTier2BroadEngineeringCore(g)){
    if(isLectureTier2BroadCoreMajor(m))return null;
    const cat=lowAcceptanceRiskCategory(m);
    if(!cat)return null;
    return {risk:true,label:cat.label,type:'strict-assassin',tone:cat.tone,reason:`二梯队宽口径主体专业组中夹入${cat.cat}。机械、光电、医工、航空航天、统计、医学不等于土木/测绘/地质/食品等低接受度方向；本专业需要单独标注，不能被“整体偏冷组”或“机械土木复合组”掩盖。${detailHint}`};
  }
  return null;
}
function isColdMajor(m){
  const text=`${m.baseName||m.name||''} ${m.majorClass||''} ${m.discipline||''}`;
  if(hotMajorPattern.test(text)&&!/中外合作|地质|地球物理|测绘|地理空间|环境|化工|材料|生物|食品|土木|建筑/.test(text))return false;
  return coldMajorPattern.test(text);
}
function groupHotColdProfile(g){
  let hotPlan=0,coldPlan=0,totalPlan=0,hotCount=0,coldCount=0;
  (g.majors||[]).forEach(m=>{
    const w=num(m.plan26)||num(m.plan25)||1;
    const text=`${m.baseName||m.name||''} ${m.majorClass||''} ${m.discipline||''}`;
    const hot=hotMajorPattern.test(text)&&!isColdMajor(m);
    const cold=isColdMajor(m);
    totalPlan+=w;
    if(hot){hotPlan+=w;hotCount+=1;}
    if(cold){coldPlan+=w;coldCount+=1;}
  });
  const groupText=`${g.groupName||''} ${g.majorSummary||''} ${(g.majorClasses||[]).join(' ')} ${(g.tags||[]).join(' ')}`;
  const hasHotCore=hotCount>=2||hotPlan>=Math.max(8,totalPlan*0.3)||(/计算机|电子信息|电气|自动化|人工智能|机器人|通信|集成电路|医学|法学/.test(groupText)&&hotCount>0);
  return {hotPlan,coldPlan,totalPlan,hotCount,coldCount,total:(g.majors||[]).length,hasHotCore};
}
function majorRiskMeta(s,g,m){
  const meta=assassinMajorMeta(m);
  let base=null;
  if(meta){
    if(!isRiskTone(meta.tone))base={risk:false,label:'',type:'assassin-source',tone:meta.tone,reason:meta.reason||meta.level||''};
    else{
      const basis=[meta.reason,meta.core?`主体专业类：${meta.core}`:'',meta.normClass?`风险专业类：${meta.normClass}`:'',meta.distance?`距主体距离：${meta.distance}`:'',meta.heatDrop?`热度落差：${meta.heatDrop}`:''].filter(Boolean).join('；');
      base={risk:true,label:meta.label||'风险',type:'assassin-source',tone:meta.tone,reason:basis||meta.level||'刺客专业识别表标记'};
    }
  }else if(m?.risk){
    base={risk:true,label:'风险',type:'source',tone:'red',reason:'原始数据已标记为风险专业'};
  }else if(!ASSASSIN_RISK_AUTHORITATIVE&&isColdMajor(m)){
    const p=groupHotColdProfile(g);
    const total=p.total||0;
    const mixedHotCold=p.hasHotCore&&p.hotCount>0&&p.coldCount>0&&p.coldCount<total;
    if(mixedHotCold)base={risk:true,label:'刺客',type:'assassin',tone:'red',reason:'热门/强工科专业组内夹入相对冷门或接受度较低方向，填报时需按最差专业兜底'};
  }
  if(ASSASSIN_RISK_STRICT_V03&&meta){
    return base||{risk:false,label:'',type:'assassin-source',tone:'green',reason:'严格版 v0.3 未标为风险'};
  }
  if(base&&base.risk&&s&&g&&hasTier1InfoEngineeringCore(g)&&lectureTierSoftensSourceRisk(m)){
    const tier=lectureTierMeta(m);
    base={risk:false,label:'',type:'lecture-tier-calibrated',tone:'green',reason:`讲座梯队校正：${tier.bucket}属于${tier.label}，不能与土木、测绘、地质、食品等低热度远缘方向同级标红。`};
  }
  const strict=strictContextRiskMeta(s,g,m);
  const merged=strongerRisk(base||{risk:false,label:'',type:'',tone:'green',reason:''},strict);
  return merged||{risk:false,label:'',type:'',tone:'green',reason:''};
}
function majorRiskLabelHTML(meta){
  if(!meta||!meta.risk)return '';
  const toneCls=meta.tone?` risk-tone-${meta.tone}`:'';
  const cls=`risk-label${meta.type==='assassin'||meta.type==='assassin-source'||meta.type==='strict-assassin'?' assassin':''}${toneCls}`;
  return `<span class="${cls}" title="${esc(meta.reason||meta.label)}">${esc(meta.label||'风险')}</span>`;
}
function groupQuality(s,g){
  const mapped=assassinGroupMeta(s,g);
  const majors=g.majors||[];
  const riskMetas=majors.map(m=>majorRiskMeta(s,g,m)).filter(x=>x.risk);
  const strictCount=riskMetas.filter(x=>x.type==='strict-assassin').length;
  const strictRed=riskMetas.filter(x=>x.type==='strict-assassin'&&x.tone==='red').length;
  if(mapped){
    const title=[mapped.level,mapped.reason,mapped.core?`主体：${mapped.core}`:'',mapped.weak?`高危/中危：${mapped.weak}`:'',mapped.edge?`边缘：${mapped.edge}`:'',mapped.breakdown?`待拆解：${mapped.breakdown}`:'',mapped.classes?`构成：${mapped.classes}`:'',strictCount?`严格补充标注：按讲座梯队口径，信息类/新工科或二梯队宽口径主体中另有 ${strictCount} 个材料、能动、理学、土木测绘等远缘方向需要核对`:'' ].filter(Boolean).join('；');
    if(strictRed&&riskToneRank(mapped.tone)<5)return {tone:'red',label:`含刺客专业 ${strictRed} 个`,title};
    if(strictCount&&riskToneRank(mapped.tone)<4)return {tone:'orange',label:`含异类刺客 ${strictCount} 个`,title};
    if(riskToneRank(mapped.tone)>0&&riskMetas.length===0){
      const tier2=(majors||[]).map(lectureTierMeta).filter(x=>x.rank===2).map(x=>x.bucket).filter(Boolean);
      return {tone:'green',label:'梯队校正',title:`刺客表原有提示已按讲座梯队校正：${Array.from(new Set(tier2)).join('、')||'二梯队宽口径'}不与土木、测绘、地质、食品等低热度远缘方向同级标红。专业硕博点、学科评估等可在专业信息里查看。`};
    }
    return {tone:mapped.tone||'green',label:mapped.label||mapped.level||'专业组结构',title:title||'来自刺客专业识别表 v0.2'};
  }
  const riskCount=riskMetas.length;
  const assassinCount=riskMetas.filter(x=>x.type==='assassin'||x.type==='strict-assassin').length;
  const sourceRiskCount=riskMetas.filter(x=>x.type==='source').length;
  const coldCount=majors.filter(isColdMajor).length;
  const total=majors.length||0;
  const allCold=total>0&&(coldCount===total||(coldCount/total>=0.75&&assassinCount===0));
  if(allCold)return {tone:'yellow',label:'整体冷门',title:`整组以冷门/风险专业为主：${coldCount}/${total} 个冷门，${sourceRiskCount}/${total} 个原始风险`};
  if(assassinCount>0)return {tone:strictRed?'red':'orange',label:`含刺客专业 ${assassinCount} 个`,title:`组内有一梯队信息类/新工科或二梯队宽口径主体，也夹有材料、能动、理学、土木测绘等远缘低接受度专业：${assassinCount}/${total} 个。必须按最差专业兜底。`};
  if(riskCount>0)return {tone:'red',label:`含风险专业 ${riskCount} 个`,title:`组内夹有相对风险专业：${riskCount}/${total} 个`};
  return {tone:'green',label:ASSASSIN_RISK_AUTHORITATIVE?'未标风险':'干净组',title:ASSASSIN_RISK_AUTHORITATIVE?'刺客专业识别表与严格补充规则均未标记为风险组':'组内未发现风险或刺客专业，结构相对清爽'};
}
function groupQualityBadge(status){return `<span class="group-quality-badge ${status.tone}" title="${esc(status.title)}">${esc(status.label)}</span>`;}
function groupChangeKey(s,g){return keyGroup(s,g);}
function groupChangeData(s,g){return GROUP_CHANGES[groupChangeKey(s,g)]||null;}
function pushMapList(map,key,value){
  if(!map.has(key))map.set(key,[]);
  map.get(key).push(value);
}
function detailOf(m){return DETAILS[m.key]||{};}
function medicalMajorText(m){
  const d=detailOf(m)||{};
  return `${m?.name||''} ${m?.majorClass||''} ${m?.discipline||''} ${d.name||''} ${d.majorFullName||''} ${d.undergraduateName||''} ${d.subjectMajor||''} ${d.majorClass||''} ${d.discipline||''} ${d.majorRemark||''}`;
}
function medicalTextHas(m,pattern){return pattern.test(medicalMajorText(m));}
const COLOR_VISION_STRICT_BASE_21=/(化学|应用化学|化学生物学|分子科学|能源化学|化工|制药|药学|临床药学|中药学|生物科学|生物技术|生物信息|生物工程|生物制药|合成生物|生物医学工程|生物医学科学|医学|临床医学|口腔医学|基础医学|预防医学|法医学|医学技术|护理学|公安技术|地质|动物医学|动物科学|野生动物|心理学|应用心理|生态学|侦察|侦查|特种能源|烟火|考古|海洋科学|海洋技术|轮机工程|食品科学|食品质量|食品安全|轻化工程|林产化工|农学|园艺|植物保护|茶学|林学|园林|蚕学|农业资源|水产养殖|海洋渔业|材料类|材料科学|材料工程|材料化学|材料物理|高分子|复合材料|功能材料|新能源材料|储能材料|金属材料|无机非金属|冶金|矿物加工|环境工程|环境科学|过程装备|学前教育|特殊教育|体育教育|运动训练|运动人体科学|民族传统体育)/;
const COLOR_VISION_STRICT_EXTENSION_21=/(建筑类|建筑学|城乡规划|风景园林|城市设计|历史建筑保护|智慧建筑|人居环境|建筑环境|景观|土木工程|给排水科学与工程|建筑电气|城市地下空间|智能建造|道路桥梁|铁道工程|纺织|服装设计|服装与服饰|非织造|丝绸|轻工类|包装工程|印刷工程|工业设计|产品设计|视觉传达|环境设计|数字媒体艺术|工艺美术|艺术设计|美术学|绘画|雕塑|摄影|动画|戏剧影视美术|陶瓷艺术设计|珠宝首饰设计)/;
function colorVisionStrict21(m,t,d){
  const majorClass=String(m?.majorClass||d.majorClass||'');
  const name=String(m?.name||d.name||d.majorFullName||'');
  const discipline=String(m?.discipline||d.discipline||'');
  // 计算机、电子信息、普通机械不按大类一刀切；机械类中按原文与严格口径主要抓“过程装备与控制工程”。
  if(/机械类/.test(majorClass)&&!/(过程装备与控制工程|过程装备)/.test(t)&&!/(服装|纺织|材料类|高分子|复合材料|功能材料|金属材料|无机非金属|冶金|化工|制药|食品|环境|建筑|土木|景观|园林)/.test(name))return false;
  if(/计算机类|电子信息类/.test(majorClass)&&!/(生物医学工程|医学信息工程|材料|化学|化工|制药|食品|环境|建筑|景观|园林|纺织|服装)/.test(name))return false;
  return COLOR_VISION_STRICT_BASE_21.test(t)||COLOR_VISION_STRICT_EXTENSION_21.test(t)||/^(化学|生物学|医学|农学|材料科学与工程|环境科学与工程|食品科学与工程|建筑学|城乡规划学|风景园林学|纺织科学与工程|设计学|美术学)$/.test(discipline);
}
function medicalRuleMatched(code,m){
  const t=medicalMajorText(m);
  const d=detailOf(m)||{};
  const discipline=String(m?.discipline||d.discipline||'');
  if(/^1[1-6]$/.test(code))return true;
  if(code==='21')return colorVisionStrict21(m,t,d);
  if(code==='22')return medicalRuleMatched('21',m)||/(美术|绘画|艺术设计|视觉传达|环境设计|产品设计|服装与服饰设计|摄影|动画|博物馆|应用物理|天文学|地理科学|应用气象|材料物理|矿物加工|资源勘查|资源勘探|冶金|无机非金属材料|交通运输|油气储运)/.test(t);
  if(code==='23')return medicalRuleMatched('22',m)||/(经济学|财政|税收|金融|经贸|管理科学|信息管理|工程管理|工商管理|会计|财务管理|公共管理|行政管理|农业经济管理|图书|档案|计算机科学与技术|计算机类|软件工程|网络工程|信息安全|数据科学|人工智能|智能科学)/.test(t);
  if(code==='24')return /(飞行技术|航海技术|消防工程|刑事科学技术|侦察|侦查|海洋船舶驾驶|空中交通管制)/.test(t);
  if(code==='25')return /(轮机工程|运动训练|民族传统体育|武术与民族传统体育|烹饪与营养|烹饪工艺)/.test(t);
  if(code==='26')return /(公安学|公安技术|侦察|侦查|刑事科学|治安学|警务|警犬|禁毒|经济犯罪侦查|涉外警务|交通管理工程|网络安全与执法|安全防范工程|消防工程)/.test(t);
  if(['31','32','33'].includes(code))return /(地矿|矿业|采矿|资源勘查|地质|水利|水文|交通运输|交通工程|能源动力|公安学|体育学|海洋科学|大气科学|水产|测绘|遥感|海洋工程|林业工程|武器|兵器|森林资源|环境科学|环境生态|生态学|旅游管理|草业科学|土木工程|消防工程|农业水利工程|农学|法医学|水土保持|荒漠化防治|动物科学)/.test(t);
  if(code==='34')return /(海洋技术|海洋科学|测控技术与仪器|核工程与核技术|生物医学工程|服装设计与工程|飞行器制造工程)/.test(t);
  if(code==='35')return /(地矿|矿业|采矿|资源勘查|水利|土建|土木|建筑|动物生产|动物科学|动物医学|水产|材料|能源动力|化工|制药|武器|兵器|农业工程|林业工程|植物生产|农学|园艺|植物保护|森林资源|环境生态|环境科学|环境工程|医学|心理学|环境与安全|安全工程|电子信息科学|材料科学|地质学|大气科学|地理科学|测绘工程|遥感|交通工程|交通运输|油气储运|船舶与海洋工程|生物工程|草业科学)/.test(t);
  if(code==='36')return /^(工学|农学|医学|法学)$/.test(discipline)||/(应用物理|应用化学|生物技术|地质学|生态学|环境科学|海洋科学|海洋技术|生物科学|应用心理)/.test(t);
  if(code==='37')return /(法学|外国语言|英语|日语|俄语|法语|德语|西班牙语|外交学|新闻学|侦察|侦查|学前教育|音乐学|录音艺术|土木工程|交通运输|动物科学|动物医学|医学)/.test(t);
  if(code==='38')return /(教育学|学前教育|特殊教育|公安学|外交学|法学|新闻学|音乐表演|表演)/.test(t);
  if(code==='39')return /(医学|临床医学|口腔医学|中医学|基础医学|法医学|医学技术|护理|药学)/.test(t);
  return false;
}
function medicalRestrictionForMajor(m){
  if(!medicalCodesActive())return {blocked:false,codes:[],reason:''};
  const hits=[...state.medicalCodes].filter(code=>medicalRuleMatched(code,m));
  if(!hits.length)return {blocked:false,codes:[],reason:''};
  const severe=hits.some(c=>/^1[1-6]$/.test(c));
  const reason=hits.map(c=>`${c}：${MEDICAL_CODE_META[c]||'体检受限'}`).join('；');
  return {blocked:true,codes:hits,reason,level:severe?'severe':'restricted'};
}
function medicalRestrictionLabelHTML(meta){
  return meta&&meta.blocked?`<span class="medical-risk-label" title="${esc(meta.reason)}">体检限报 ${esc(meta.codes.join('/'))}</span>`:'';
}
function groupMedicalRestrictionSummary(g){
  if(!medicalCodesActive())return null;
  const majors=g?.majors||[];
  const blocked=majors.filter(m=>medicalRestrictionForMajor(m).blocked);
  if(!blocked.length)return null;
  return {count:blocked.length,total:majors.length,all:blocked.length===majors.length};
}
function groupMedicalBadge(g){
  const x=groupMedicalRestrictionSummary(g);
  if(!x)return '';
  return `<span class="badge red medical-group-badge" title="当前体检代码下，本专业组有 ${x.count}/${x.total} 个专业受限，受限专业禁止勾选。">${x.all?'体检全限报':'体检限报'} ${x.count}/${x.total}</span>`;
}
function cleanupVolunteerForMedicalRestrictions(){
  let changed=false;
  Object.keys(volunteerMajorKeys).forEach(key=>{
    const rec=getGroupRecord(key);
    if(!rec)return;
    const old=Array.isArray(volunteerMajorKeys[key])?volunteerMajorKeys[key]:[];
    const next=uniqueValidMajorKeys(old,rec.g);
    if(next.length!==old.length||next.some((v,i)=>v!==old[i])){volunteerMajorKeys[key]=next;changed=true;}
  });
  if(changed)saveVolunteerMajorKeys();
  return changed;
}
function updateMedicalButton(){
  const btn=$('#medicalBtn');
  if(!btn)return;
  const arr=[...state.medicalCodes];
  btn.textContent=arr.length?`体检 ${arr.join('/')}`:'体检受限';
  btn.classList.toggle('medical-active',arr.length>0);
}
function updateMedicalPanelSummary(){
  const input=$('#medicalCodeInput');
  const summary=$('#medicalCodeSummary');
  if(!input||!summary)return;
  const codes=parseMedicalCodes(input.value);
  if(!codes.length){summary.innerHTML='<div class="medical-empty">未输入体检代码。格式示例：21、22、34 或 21 35。</div>';return;}
  summary.innerHTML=`<div class="medical-code-list">${codes.map(c=>`<div class="medical-code-card"><b>代码${esc(c)}</b><span>${esc(MEDICAL_CODE_META[c]||'体检受限')}</span></div>`).join('')}</div>`;
}
function renderMedicalVolunteerNotice(){
  const el=$('#medicalVolunteerNotice');
  if(!el)return;
  const arr=[...state.medicalCodes];
  if(!arr.length){el.innerHTML='';el.style.display='none';return;}
  el.style.display='block';
  el.innerHTML=`<b>体检受限已启用：</b>代码 ${esc(arr.join('、'))}。受限专业在主表和志愿表中禁止勾选；已选受限专业会自动移出专业志愿。`;
}
function cleanMajorText(v){
  return normalize(String(v||'')
    .replace(/（[^）]*）|\([^)]*\)|\[[^\]]*\]|【[^】]*】/g,'')
    .replace(/专业|大类|类$/g,''));
}
function majorInfo(m){
  const d=detailOf(m);
  const majorClass=m.majorClass||d.majorClass||'';
  return {
    name:m.name||d.name||'',
    majorClass,
    discipline:m.discipline||d.discipline||'',
    undergraduateName:d.undergraduateName||'',
    subjectMajor:d.subjectMajor||'',
    bucket:classBucket(majorClass||m.name||d.undergraduateName),
    base:cleanMajorText(d.undergraduateName||m.name||d.name)
  };
}
function buildPredictionIndexes(){
  majorRefs=[];
  majorRefsBySchool=new Map();
  majorRefsByBucket=new Map();
  rankRefsBySubjectBatch=new Map();
  predictionCache=new Map();
  DB.forEach(s=>(s.groups||[]).forEach(g=>(g.majors||[]).forEach(m=>{
    const score=num(m.score25);
    if(score===null)return;
    const rank=num(m.rank25);
    const info=majorInfo(m);
    const ref={s,g,m,score,rank,school:s.name,subject:s.subject,batch:s.batch,level:String(s.level||''),groupName:g.groupName,...info};
    majorRefs.push(ref);
    pushMapList(majorRefsBySchool,`${s.subject}|${s.batch}|${s.name}`,ref);
    pushMapList(majorRefsByBucket,`${s.subject}|${s.batch}|${String(s.level||'')}|${info.bucket}`,ref);
    pushMapList(majorRefsByBucket,`${s.subject}|${s.batch}|*|${info.bucket}`,ref);
    if(rank!==null)pushMapList(rankRefsBySubjectBatch,`${s.subject}|${s.batch}`,{score,rank});
  })));
}
function splitGroupNames(v){
  return String(v||'').split(/[；;、,，/]+/).map(x=>x.trim()).filter(Boolean);
}
function changeSourceGroups(s,g){
  const d=groupChangeData(s,g);
  const names=new Set();
  if(!d)return names;
  splitGroupNames(d.group25).forEach(x=>names.add(x));
  ['add','in','remove','out'].forEach(k=>(d.details?.[k]||[]).forEach(item=>{
    splitGroupNames(item.from).forEach(x=>names.add(x));
    splitGroupNames(item.to).forEach(x=>names.add(x));
  }));
  return names;
}
function majorSimilarity(m,ref,sourceGroups){
  const info=majorInfo(m);
  let score=0;
  if(sourceGroups.has(ref.groupName))score+=70;
  if(info.base&&ref.base){
    if(info.base===ref.base)score+=90;
    else if(info.base.includes(ref.base)||ref.base.includes(info.base))score+=55;
  }
  const text=normalize(info.name);
  if(ref.base&&text.includes(ref.base))score+=30;
  if(info.majorClass&&info.majorClass===ref.majorClass)score+=25;
  if(info.bucket&&info.bucket===ref.bucket)score+=18;
  if(info.discipline&&info.discipline===ref.discipline)score+=8;
  const sm=normalize(info.subjectMajor), rm=normalize(ref.subjectMajor);
  if(sm&&rm&&(sm.includes(rm)||rm.includes(sm)))score+=15;
  return score;
}
function bestMajorReference(s,g,m){
  const sourceGroups=changeSourceGroups(s,g);
  const schoolRefs=majorRefsBySchool.get(`${s.subject}|${s.batch}|${s.name}`)||[];
  const info=majorInfo(m);
  const bucketRefs=majorRefsByBucket.get(`${s.subject}|${s.batch}|${String(s.level||'')}|${info.bucket}`)
    ||majorRefsByBucket.get(`${s.subject}|${s.batch}|*|${info.bucket}`)||[];
  const pick=(refs,minScore)=>{
    let best=null;
    refs.forEach(ref=>{
      const match=majorSimilarity(m,ref,sourceGroups);
      if(!best||match>best.match)best={ref,match};
    });
    return best&&best.match>=minScore?best:null;
  };
  const sourceRefs=schoolRefs.filter(ref=>sourceGroups.has(ref.groupName));
  return pick(sourceRefs,50)||pick(schoolRefs,72)||pick(bucketRefs,98);
}
function predictionAdjustment(m,g){
  const text=`${m.name||''} ${m.majorClass||''} ${(g.tags||[]).join(' ')} ${g.remark||''}`;
  const size=(g.majors||[]).length;
  let adj=0;
  const reasons=[];
  if(hotMajorPattern.test(text)&&!isColdMajor(m)){adj+=3; reasons.push('热门方向 +3');}
  if(/人工智能|计算机科学与技术|软件工程|集成电路|微电子|口腔医学|临床医学|法学/.test(text)){adj+=2; reasons.push('强需求专业 +2');}
  if(/至诚|拔尖|卓越|实验|试验|本博|八年|双学士|未来技术|创新班|书院/.test(text)){adj+=3; reasons.push('培养模式 +3');}
  if(size===1){adj+=2; reasons.push('专业单列 +2');}
  else if(size===2){adj+=1; reasons.push('小组单列 +1');}
  const plan=num(m.plan26)||num(g.plan26);
  if(plan!==null&&plan<=2){adj+=2; reasons.push('计划少 +2');}
  else if(plan!==null&&plan<=5){adj+=1; reasons.push('计划偏少 +1');}
  else if(plan!==null&&plan>=80){adj-=2; reasons.push('计划多 -2');}
  else if(plan!==null&&plan>=30){adj-=1; reasons.push('计划偏多 -1');}
  if(/中外合作|合作办学|学分互认|中澳|中美|中英|国际|境外|出国/.test(text)){adj-=8; reasons.push('合作/出国成本 -8');}
  if(isColdMajor(m)){adj-=4; reasons.push('冷门或风险方向 -4');}
  const dynRisk=majorRiskMeta(null,g,m);
  if(dynRisk.risk){adj-=2; reasons.push(`${dynRisk.label||'风险'} -2`);}
  return {adj:Math.max(-15,Math.min(12,adj)),reasons};
}
function estimateRankForScore(subject,batch,score,fallbackRank){
  const fallback=num(fallbackRank);
  const target=num(score);
  const arr=rankRefsBySubjectBatch.get(`${subject}|${batch}`)||[];
  if(target===null||!arr.length)return fallback;
  let best=null;
  arr.forEach(x=>{
    const sx=num(x.score), rx=num(x.rank);
    if(sx===null||rx===null)return;
    const dist=Math.abs(sx-target);
    if(!best||dist<best.dist)best={score:sx,rank:rx,dist};
  });
  return best?Math.round(best.rank):fallback;
}
function estimateScoreForRank(subject,batch,rank,fallbackScore){
  const fallback=num(fallbackScore);
  const target=num(rank);
  const arr=rankRefsBySubjectBatch.get(`${subject}|${batch}`)||[];
  if(target===null||!arr.length)return fallback;
  let best=null;
  arr.forEach(x=>{
    const sx=num(x.score), rx=num(x.rank);
    if(sx===null||rx===null)return;
    const dist=Math.abs(rx-target);
    if(!best||dist<best.dist)best={score:sx,rank:rx,dist};
  });
  return best?Math.round(best.score):fallback;
}
function groupPredictedRankAnchor(g){
  const gr=num(g.rank26Eq);
  if(gr!==null)return gr;
  const ranks=(g.majors||[]).map(m=>num(m.predictedRank26)).filter(x=>x!==null);
  return ranks.length?Math.max(...ranks):null;
}
function predictMajorScore(s,g,m){
  const predictedRank=num(m.predictedRank26);
  if(predictedRank!==null){
    const scoreByRank=estimateScoreForRank(s.subject,s.batch,predictedRank,null);
    if(scoreByRank!==null){
      return {score:scoreByRank,rank:predictedRank,confidence:'中',source:`当前行26预估位次 ${fmtNum(predictedRank)} 折算`,adjustment:'按位次折算，不再用同校最低组兜底'};
    }
  }
  const avg=num(m.avgScore3);
  if(avg!==null&&(m.avgYears||0)>=2){
    const adj=predictionAdjustment(m,g);
    const score=Math.round(avg+adj.adj);
    return {score,rank:estimateRankForScore(s.subject,s.batch,score,m.avgRank3),confidence:'中',source:`本专业三年均分 ${fmtNum(avg)}`,adjustment:adj.reasons.join('；')};
  }
  const best=bestMajorReference(s,g,m);
  if(!best)return null;
  const adj=predictionAdjustment(m,g);
  const score=Math.round(best.ref.score+adj.adj);
  const confidence=best.match>=145?'高':best.match>=95?'中':'低';
  return {
    score,
    rank:estimateRankForScore(s.subject,s.batch,score,best.ref.rank),
    confidence,
    source:`参考 ${best.ref.groupName}｜${best.ref.name} ${fmtNum(best.ref.score)}分`,
    adjustment:adj.reasons.join('；')
  };
}
function predictGroupScore(s,g){
  if(num(g.score25)!==null)return null;
  const cacheKey=keyGroup(s,g);
  if(predictionCache.has(cacheKey))return predictionCache.get(cacheKey);
  const scores=[];
  (g.majors||[]).forEach(m=>{
    const actual=num(m.score25);
    if(actual!==null){
      scores.push({score:actual,rank:num(m.rank25),confidence:'高',source:`${m.name} 25年真实分`,adjustment:''});
      return;
    }
    const pred=predictMajorScore(s,g,m);
    if(pred)scores.push(pred);
  });
  let result=null;
  if(scores.length){
    scores.sort((a,b)=>a.score-b.score);
    const floor=scores[0];
    const eq=num(g.score26Eq);
    let score=floor.score;
    if(eq!==null){
      score=Math.round((eq*0.7)+(floor.score*0.3));
      if(Math.abs(eq-floor.score)>18)score=Math.max(eq-12,Math.min(eq+8,score));
    }
    const rank=estimateRankForScore(s.subject,s.batch,score,floor.rank||g.rank26Eq);
    const confidence=scores.some(x=>x.confidence==='高')?'中高':scores.some(x=>x.confidence==='中')?'中':'低';
    const eqNote=eq!==null?`；26等效分参考 ${fmtNum(eq)}`:'';
    result={score,rank,confidence,reason:`按组内最低参考专业估算：${floor.source}${floor.adjustment?`；修正：${floor.adjustment}`:''}${eqNote}`};
  }else if(num(g.score26Eq)!==null){
    const score=Math.round(num(g.score26Eq));
    result={score,rank:num(g.rank26Eq),confidence:'中',reason:`使用现有 26 等效分参考 ${fmtNum(score)}`};
  }else{
    const rankAnchor=groupPredictedRankAnchor(g);
    const rankScore=estimateScoreForRank(s.subject,s.batch,rankAnchor,null);
    if(rankAnchor!==null&&rankScore!==null){
      result={score:rankScore,rank:rankAnchor,confidence:'中',reason:`使用当前行26预估位次 ${fmtNum(rankAnchor)} 折算分数；不再采用同校最低专业组兜底`};
    }else{
      const peerScores=(s.groups||[]).filter(x=>x!==g&&num(x.score25)!==null&&!/(中外合作|高收费)/.test(`${(x.tags||[]).join(' ')} ${x.majorSummary||''} ${x.remark||''}`)).map(x=>num(x.score25)).sort((a,b)=>a-b);
      if(peerScores.length){
        const idx=Math.max(0,Math.floor(peerScores.length*0.25));
        const score=Math.round(peerScores[idx]);
        result={score,rank:estimateRankForScore(s.subject,s.batch,score,null),confidence:'低',reason:`缺少直接专业锚点，使用同校普通专业组低位分参考 ${fmtNum(score)}；已排除中外合作/高收费组`};
      }
    }
  }
  predictionCache.set(cacheKey,result);
  return result;
}
function groupScoreEstimate(s,g){return num(g.score25)===null?predictGroupScore(s,g):null;}
function predictionBadgeHTML(s,g){
  const p=groupScoreEstimate(s,g);
  return p?`<span class="badge green" title="${esc(p.reason)}">预测分 ${esc(fmtNum(p.score))}｜${esc(p.confidence)}</span>`:'';
}
function groupScoreMiniHTML(s,g){
  const p=groupScoreEstimate(s,g);
  if(p)return `<div class="mini" title="${esc(p.reason)}"><b>${esc(fmtNum(p.score))}</b><span>预测分</span></div><div class="mini" title="${esc(p.reason)}"><b>${esc(fmtNum(p.rank))}</b><span>预测位次</span></div>`;
  return `<div class="mini"><b>${fmtNum(g.score25)}</b><span>25分</span></div><div class="mini"><b>${fmtNum(g.rank25)}</b><span>25位次</span></div>`;
}
function groupScoreLineHTML(s,g){
  const p=groupScoreEstimate(s,g);
  if(p)return `预测分 ${esc(fmtNum(p.score))}｜预测位次 ${esc(fmtNum(p.rank))} <span class="note-badge" title="${esc(p.reason)}">估</span>`;
  return `25分 ${fmtNum(g.score25)}｜25位次 ${fmtNum(g.rank25)}`;
}
function groupChangeButtonHTML(s,g,variant){
  const data=groupChangeData(s,g);
  const cls=`change-btn ${variant||''} ${data?'':'muted'}`.trim();
  const label=data&&data.advice==='重点核对'?'变迁*':'变迁';
  return `<button class="${cls}" type="button" data-change-key="${esc(groupChangeKey(s,g))}" data-change-title="${esc(`${s.name} ${groupDisplayTitleText(s,g)}`)}" title="${data?'查看 2025-2026 专业组变迁':'暂无普通批变迁数据'}">${label}</button>`;
}
function volunteerButtonHTML(s,g){
  const key=keyGroup(s,g);
  const selected=volunteerKeys.includes(key);
  const med=groupMedicalRestrictionSummary(g);
  const allMedicalBlocked=Boolean(med&&med.all);
  const subjectBlock=subjectRequirementBlockReason(s,g);
  const disabled=!selected&&(volunteerKeys.length>=VOLUNTEER_LIMIT||allMedicalBlocked||Boolean(subjectBlock));
  const label=selected?'已加入志愿表':subjectBlock?'选科不符':allMedicalBlocked?'体检全限报':disabled?'志愿表已满':'加入志愿表';
  const title=selected?'再次点击：从志愿表移出该专业组，并清空本组已选专业':subjectBlock?subjectBlock:allMedicalBlocked?'当前体检代码下该专业组全部专业受限，不建议加入':'点击：加入志愿表';
  const cls=`volunteer-add-btn ${selected?'selected':''}`.trim();
  return `<button class="${cls}" type="button" data-volunteer-key="${esc(key)}" title="${esc(title)}" ${disabled?'disabled':''}>${label}</button>`;
}
function clearMajorButtonHTML(s,g){
  const key=keyGroup(s,g);
  const count=selectedMajorOrder(key).length;
  return `<button class="anno-btn danger clear-major-btn" type="button" data-clear-major-group="${esc(key)}" ${count?'':'disabled'} title="只清空本专业组已选专业，不删除专业组">清空已选${count?` ${count}`:''}</button>`;
}
function percent(v){return typeof v==='number'?`${Math.round(v*1000)/10}%`:fmt(v);}
function diffText(a,b){return typeof a==='number'&&typeof b==='number'?formatSigned(a-b):'—';}
function createLayout(){
  document.body.className=[document.body.dataset.admin==='1'?'admin-page':'',state.compact?'compact-mode':''].filter(Boolean).join(' ');
  document.body.innerHTML=`
  <div class="app-shell">
    <header class="topbar">
      <div class="hero"><div class="brand"><h1>江苏专科招生计划变化知识库</h1><p>基于 2026 高职专科行级数据生成；院校与专业组均按专业加权均分排序，支持志愿表、特殊类型、体检受限与风险提示。</p></div><div class="top-actions"><div class="stage-switch"><a href="../index.html">本科</a><a class="active" href="./index.html">专科</a></div><a id="contentCenterBtn" class="header-toggle content-toggle" href="../content/index.html">升学资讯</a><div class="version">${VERSION}</div><button id="studentPanelBtn" class="header-toggle student-toggle" type="button">学生档案</button><button id="accountBtn" class="header-toggle account-toggle" type="button">登录/注册</button><button id="logoutHeaderBtn" class="header-toggle logout-toggle" type="button" hidden>退出登录</button><button id="volunteerPanelBtn" class="header-toggle volunteer-toggle" type="button">专科志愿表 0/40</button><button id="compactBtn" class="header-toggle" type="button">${state.compact?'标准显示':'紧凑显示'}</button><button id="toggleHeaderBtn" class="header-toggle" type="button">收起头部</button></div></div>
      <div class="filters">
        <select id="batchFilter"><option value="">全部批次</option></select>
        <select id="subjectFilter"><option value="">全部科类</option></select>
        <button id="requirementBtn" class="filter-btn">选科要求</button>
        <button id="provinceBtn" class="filter-btn">全部省份</button>
        <button id="levelBtn" class="filter-btn">院校层次</button>
        <button id="specialBtn" class="filter-btn">特殊类型/标签</button>
        <button id="classBtn" class="filter-btn">全部专业大类</button>
        <button id="scoreBtn" class="filter-btn">目标分区间</button>
        <button id="medicalBtn" class="filter-btn">体检受限</button>
        <input id="searchInput" placeholder="搜索院校、专业组、专业、专业大类，例如：计算机类 / 南京邮电 / 中外合作" />
      </div>
      <div id="studentContextBar" class="student-context-bar" hidden></div>
    </header>
    <div class="layout"><aside class="sidebar"><div class="side-head"><strong>院校索引</strong><span id="resultMeta">正在加载数据</span></div><div id="schoolList" class="school-list"></div></aside><main id="main" class="main"></main></div>
    <div id="provincePanel" class="panel facet-panel"><div class="panel-head"><h3>地区筛选</h3><button class="close-btn" data-close="provincePanel">×</button></div><div class="panel-body"><div id="provincePanelBody"></div></div></div>
    <div id="levelPanel" class="panel facet-panel"><div class="panel-head"><h3>院校层次筛选</h3><button class="close-btn" data-close="levelPanel">×</button></div><div class="panel-body"><div id="levelPanelBody"></div></div></div>
    <div id="specialPanel" class="panel facet-panel"><div class="panel-head"><h3>特殊类型/标签筛选</h3><button class="close-btn" data-close="specialPanel">×</button></div><div class="panel-body"><div id="specialPanelBody"></div></div></div>
    <div id="requirementPanel" class="panel facet-panel"><div class="panel-head"><h3>选科要求筛选</h3><button class="close-btn" data-close="requirementPanel">×</button></div><div class="panel-body"><div id="requirementPanelBody"></div></div></div>
    <div id="classPanel" class="panel facet-panel"><div class="panel-head"><h3>专业大类筛选</h3><button class="close-btn" data-close="classPanel">×</button></div><div class="panel-body"><div id="classPanelBody"></div></div></div>
    <div id="scorePanel" class="panel"><div class="panel-head"><h3>目标分区间筛选</h3><button class="close-btn" data-close="scorePanel">×</button></div><div class="panel-body"><div id="rangeSummary" class="range-summary"></div><div class="score-row"><label>目标分</label><input id="targetScoreRange" type="range" min="350" max="710" value="550"><input id="targetScoreInput" type="number" value="550"></div><div class="score-row"><label>下浮</label><input id="downRange" type="range" min="0" max="80" value="20"><input id="downInput" type="number" value="20"></div><div class="score-row"><label>上浮</label><input id="upRange" type="range" min="0" max="80" value="30"><input id="upInput" type="number" value="30"></div><div class="modal-actions"><button id="clearScoreBtn">清空分数筛选</button><button id="applyScoreBtn" class="save">应用区间</button></div></div></div>
    <div id="studentPanel" class="panel student-panel"><div class="panel-head"><div><h3>学生档案</h3><p id="studentPanelSubtitle" class="panel-subtitle">登录后可新增学生、保存和加载志愿表。</p></div><button class="close-btn" data-close="studentPanel">×</button></div><div class="panel-body"><div id="studentPanelBody"></div></div></div>
    <div id="medicalPanel" class="panel medical-panel"><div class="panel-head"><h3>体检受限</h3><button class="close-btn" data-close="medicalPanel">×</button></div><div class="panel-body"><p class="medical-help">输入体检结论代码，例如：21、22、23、34、35。系统会在主表和志愿表中提示，并禁止受限专业被勾选。色弱/色盲按严格口径处理：化学、生物、医学、药学、食品、农林、水产、环境、材料类、建筑/风景园林、纺织服装、设计类等限报；计算机、电子信息、普通机械不按大类一刀切。</p><input id="medicalCodeInput" class="medical-code-input" placeholder="输入体检代码，如：21 35 或 23,34"><div class="medical-quick-codes">${Object.keys(MEDICAL_CODE_META).map(c=>`<button type="button" data-medical-code="${c}">${c}</button>`).join('')}</div><div id="medicalCodeSummary" class="medical-code-summary"></div><div class="modal-actions"><button id="clearMedicalBtn">清空体检代码</button><button id="applyMedicalBtn" class="save">应用体检限制</button></div></div></div>
    <div id="changePanel" class="panel change-panel"><div class="panel-head"><div><h3>专业组变迁</h3><p id="changePanelTitle" class="panel-subtitle"></p></div><button class="close-btn" data-close="changePanel">×</button></div><div id="changePanelBody" class="panel-body"></div></div>
    <div id="volunteerPanel" class="panel volunteer-panel"><div class="panel-head volunteer-panel-head"><div><h3>专业组专业表</h3><p id="volunteerPanelCount" class="panel-subtitle">已选 0 / 40 个专业组</p></div><div class="volunteer-head-actions"><button id="saveVolunteerBtn" class="save" type="button">保存到学生</button><button id="exportVolunteerBtn" class="save" type="button">导出 Excel</button><button class="close-btn" data-close="volunteerPanel">×</button></div></div><div class="panel-body volunteer-workbench"><div class="volunteer-sticky-shell"><div class="volunteer-toolbar volunteer-workbench-toolbar"><input id="volunteerSearchInput" type="search" placeholder="搜索院校、专业组、专业、专业类"><select id="volunteerFilterSelect"><option value="">全部专业组</option><option value="冲">只看冲</option><option value="稳">只看稳</option><option value="保">只看保</option><option value="垫">只看垫</option><option value="pending">只看待定</option><option value="emptyMajor">未选具体专业</option><option value="notFullMajor">专业未满 6 个</option><option value="fullMajor">已满 6 个专业</option></select><button id="resetVolunteerFilterBtn" type="button">清除筛选</button><button id="expandVolunteerBtn" type="button">一键展开</button><button id="fillVolunteerBtn" type="button">当前筛选补满</button><button id="clearVolunteerBtn" type="button">清空</button></div><div class="volunteer-table-head"><div>排序</div><div>院校专业组</div><div>已选专业</div><div>基础信息</div><div>操作</div></div></div><div id="medicalVolunteerNotice" class="medical-active-notice" style="display:none"></div><div id="volunteerList" class="volunteer-list volunteer-table-list"></div></div></div>
    <div id="annotationDrawer" class="annotation-drawer">
      <div class="annotation-head"><div><h3>批注</h3><p id="annotationObject">未选择批注对象</p></div><button id="closeAnnotationBtn" class="close-btn" type="button">×</button></div>
      <div class="annotation-body"><div id="giscusMount" class="giscus-mount"></div></div>
    </div>
    <div id="notePanel" class="note-panel"><h4>备注</h4><div id="notePanelText"></div></div>
    <div id="authCover" class="auth-cover" hidden>
      <iframe id="authLandingFrame" class="auth-cover-frame" src="../haoshengya_login_landing.html" title="好生涯早规划登录页"></iframe>
    </div>
    <div id="modalMask" class="modal-mask"><div id="modal" class="modal"></div></div>
    <div class="admin-dock"><button id="adminDockBtn">管理员备注</button></div><div id="adminMenu" class="admin-menu"><button id="loginBtn">登录数据库</button><button id="reloadNotesBtn">读取备注</button><button id="addSchoolNoteBtn">新增当前学校备注</button><button id="logoutBtn">退出登录</button><div class="context-hint">右键学校、专业组或专业行可编辑备注。</div></div>
    <button id="backTopBtn" class="back-top" type="button" title="" aria-label="向上">↑</button>
    <div class="footer">GitHub Pages 静态部署版 · 数据分片加载 · 公开页只读 / 管理员页可写备注</div>
  </div>`;
}
function unique(arr){return Array.from(new Set(arr.filter(v=>v!==undefined&&v!==null&&String(v).trim()!=='')));}
function fillSelect(sel,vals){const el=$(sel); if(!el)return; const first=el.options[0].outerHTML; el.innerHTML=first+vals.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join('');}
function initFilters(){
  const batches=unique(DB.map(s=>s.batch)).sort();
  const subjects=unique(DB.map(s=>s.subject)).sort();
  fillSelect('#batchFilter',batches);
  fillSelect('#subjectFilter',subjects);
}
function schoolCountBy(field){const m=new Map(); DB.forEach(s=>{const key=String(s[field]??'').trim(); if(!isValidFacetValue(key))return; m.set(key,(m.get(key)||0)+1);}); return m;}
function schoolCityCountByProvince(province){const m=new Map(); DB.forEach(s=>{if(String(s.province||'').trim()!==province)return; const key=String(s.city??'').trim(); if(!isValidFacetValue(key))return; m.set(key,(m.get(key)||0)+1);}); return m;}
function displayRegionLabel(s){const province=String(s?.province||'').trim(); const city=String(s?.city||'').trim(); return province==='江苏'&&isValidFacetValue(city)?city:province;}

function collectSchoolAdmissionRules(s){
  const rules=[];
  const seen=new Set();
  (s?.groups||[]).forEach(g=>(g.majors||[]).forEach(m=>{
    const d=detailOf(m);
    const rule=String(d.admissionRule||'').trim();
    if(rule&&!seen.has(rule)){seen.add(rule);rules.push(rule);}
  }));
  if(!rules.length){
    const d=representativeDetailForSchool(s);
    const rule=String(d.admissionRule||'').trim();
    if(rule)rules.push(rule);
  }
  return rules;
}
function manualAdmissionPriorityHint(s){
  const name=String(s?.name||'');
  return MANUAL_ADMISSION_PRIORITY_SCHOOL_HINTS.find(x=>x.pattern.test(name))||null;
}
function admissionPriorityInfo(s){
  const cacheKey=keySchool(s);
  if(admissionPriorityCache.has(cacheKey))return admissionPriorityCache.get(cacheKey);
  const rules=collectSchoolAdmissionRules(s);
  const hits=[];
  const manual=manualAdmissionPriorityHint(s);
  if(manual)hits.push({rule:manual.rule,severity:manual.severity||'high',manual:true});
  rules.forEach(rule=>{
    const t=String(rule||'').replace(/\s+/g,'');
    if(!t)return;
    const hasPriority=/专业优先|专业志愿优先|专业志愿清|专业清|志愿优先|志愿清|先志愿[，,、]?后分数/.test(t);
    if(!hasPriority)return;
    const oldGaokaoOnly=/(未实行高考综合改革|非高考综合改革|传统高考|老高考|非平行志愿|非平行投档).{0,28}(专业优先|专业志愿清|志愿优先|志愿清)/.test(t)
      && /(高考综合改革|新高考|平行志愿|江苏).{0,36}分数优先/.test(t);
    const artOnly=/(普通类|普通专业).{0,16}分数优先.{0,36}(艺术|体育|艺体|广播电视编导).{0,36}(专业优先|专业志愿优先|志愿优先)/.test(t);
    const partial=/(中外合作|艺术|体育|艺体|第一专业志愿|部分专业|广播电视编导|特殊专业|单列专业)/.test(t) || oldGaokaoOnly || artOnly;
    hits.push({rule,severity:partial?'partial':'high'});
  });
  const high=hits.some(x=>x.severity==='high');
  const info=hits.length?{
    severity:high?'high':'partial',
    label:high?'专业优先':'部分专业优先',
    rules:[...new Set(hits.map(x=>x.rule))],
    title:`录取规则提示：${high?'该校存在专业优先/专业清类规则，专业顺序风险高':'该校存在部分专业或特定情形专业优先规则，需核对章程'}。${hits[0]?.rule||''}`
  }:null;
  admissionPriorityCache.set(cacheKey,info);
  return info;
}
function admissionPriorityBadge(s,compact=false){
  const info=admissionPriorityInfo(s);
  if(!info)return '';
  return `<span class="admission-priority-badge ${info.severity}" title="${esc(info.title)}">⚠ ${esc(compact?info.label:info.label+'录取')}</span>`;
}
function admissionPriorityAlertHTML(s){
  const info=admissionPriorityInfo(s);
  if(!info)return '';
  const sample=info.rules[0]||'';
  return `<div class="admission-rule-alert ${info.severity}"><b>录取规则红色提示：${esc(info.label)}</b><span>${esc(sample)}</span></div>`;
}

function schoolFacetValues(s){
  const cacheKey=keySchool(s);
  if(schoolFacetCache.has(cacheKey))return schoolFacetCache.get(cacheKey);
  const d=representativeDetailForSchool(s);
  const values=new Set();
  const add=v=>{const t=String(v??'').trim(); if(isValidFacetValue(t))values.add(t);};
  add(s.level);
  const text=`${s.level||''} ${d.schoolTags||''} ${d.firstClass||''} ${d.schoolLevel||''} ${d.schoolType||''} ${d.publicPrivate||''} ${d.administration||''}`;
  const is985=/985/.test(text);
  const is211=/211/.test(text);
  const isDoubleFirst=/双一流/.test(text);
  const hasBaoyan=/保研资格|推免资格|推荐免试|免试研究生|保研/.test(text)||Number(d.baoyanRate)>0;
  const isPublic=/公办/.test(text);
  const isPrivate=/民办/.test(text);
  if(is985)add('985');
  if(is211)add('211');
  if(isDoubleFirst)add('双一流');
  if(hasBaoyan&&!is985&&!is211&&!isDoubleFirst)add('保研双非');
  if(isPublic)add('公办');
  if(isPrivate)add('民办');
  if(isPublic&&!is985&&!is211&&!isDoubleFirst&&!hasBaoyan)add('普通公办');
  if(/中外合作办学机构|中外合作大学|港中深|昆山杜克|西交利物浦|宁波诺丁汉|上海纽约/.test(text))add('中外合作办学机构');
  const priorityInfo=admissionPriorityInfo(s);
  if(priorityInfo){add('专业优先'); if(priorityInfo.severity==='partial')add('部分专业优先');}
  const st=String(d.schoolType||'').trim();
  if(st){add(st.endsWith('类')?st:`${st}类`);}
  ['综合类','理工类','师范类','医药类','财经类','政法类','农林类','军事类'].forEach(v=>{if(text.includes(v.replace('类',''))||text.includes(v))add(v);});
  ['电力','邮电','交通','水利','航空航天','兵器','石油'].forEach(v=>{if(text.includes(v))add(v);});
  schoolFacetCache.set(cacheKey,values);
  return values;
}
function schoolFacetCounts(){const m=new Map(); DB.forEach(s=>schoolFacetValues(s).forEach(v=>m.set(v,(m.get(v)||0)+1))); return m;}
function schoolMatchesLevelFacet(s){if(!state.selectedLevels.size)return true; const vals=schoolFacetValues(s); return [...state.selectedLevels].some(v=>vals.has(v));}
function groupCountBy(field){const m=new Map(); DB.forEach(s=>s.groups.forEach(g=>{const key=String(g[field]??'').trim(); if(!isValidFacetValue(key))return; m.set(key,(m.get(key)||0)+1);})); return m;}
function openStudentDirectory(){window.location.href='../students/index.html?from=specialty';}
function bindEvents(){
  window.addEventListener('message',handleLandingAuthMessage);
  ['batchFilter','subjectFilter'].forEach(id=>$('#'+id).addEventListener('change',e=>{state[id.replace('Filter','')]=e.target.value; applyFilters();}));
  $('#searchInput').addEventListener('input',e=>{state.q=e.target.value; applyFilters();});
  $('#provinceBtn').addEventListener('click',()=>{buildProvincePanel();openPanel('provincePanel')});
  $('#levelBtn').addEventListener('click',()=>{buildLevelPanel();openPanel('levelPanel')});
  $('#specialBtn').addEventListener('click',()=>{buildSpecialPanel();openPanel('specialPanel')});
  $('#requirementBtn').addEventListener('click',()=>{buildRequirementPanel();openPanel('requirementPanel')});
  $('#classBtn').addEventListener('click',()=>{buildClassPanel();openPanel('classPanel')});
  $('#scoreBtn').addEventListener('click',()=>{updateRangeSummary();openPanel('scorePanel')});
  $('#medicalBtn').addEventListener('click',()=>{const input=$('#medicalCodeInput'); if(input)input.value=[...state.medicalCodes].join(' '); updateMedicalPanelSummary(); openPanel('medicalPanel')});
  $('#studentPanelBtn')?.addEventListener('click',openStudentDirectory);
  $('#accountBtn')?.addEventListener('click',()=>showAccountModal('login'));
  $('#logoutHeaderBtn')?.addEventListener('click',()=>logoutSupabase());
  $('#volunteerPanelBtn').addEventListener('click',()=>{renderVolunteerPanel();openPanel('volunteerPanel')});
  $('#fillVolunteerBtn').addEventListener('click',fillVolunteerFromCurrentFilters);
  $('#saveVolunteerBtn').addEventListener('click',saveCurrentVolunteerForm);
  $('#exportVolunteerBtn').addEventListener('click',exportVolunteerXlsx);
  $('#clearVolunteerBtn').addEventListener('click',clearVolunteers);
  $('#volunteerSearchInput')?.addEventListener('input',e=>{volunteerSearchQuery=e.target.value;renderVolunteerPanel();});
  $('#volunteerFilterSelect')?.addEventListener('change',e=>{volunteerFilterMode=e.target.value;renderVolunteerPanel();});
  $('#resetVolunteerFilterBtn')?.addEventListener('click',()=>{volunteerSearchQuery='';volunteerFilterMode='';const q=$('#volunteerSearchInput');if(q)q.value='';const f=$('#volunteerFilterSelect');if(f)f.value='';renderVolunteerPanel();});
  $('#expandVolunteerBtn')?.addEventListener('click',()=>{
    volunteerAllExpanded=!volunteerAllExpanded;
    if(volunteerAllExpanded){
      volunteerVisibleEntries().forEach(x=>volunteerExpandedKeys.add(x.key));
    }else{
      volunteerExpandedKeys.clear();
    }
    renderVolunteerPanel({skipCapture:true});
  });
  $('#compactBtn').addEventListener('click',toggleCompact);
  $('#toggleHeaderBtn').addEventListener('click',toggleHeader);
  $('#backTopBtn').addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));
  $('#closeAnnotationBtn').addEventListener('click',closeAnnotationDrawer);
  $$('[data-close]').forEach(b=>b.addEventListener('click',()=>closePanel(b.dataset.close)));
  bindScoreInputs();
  bindMedicalInputs();
  $('#modalMask').addEventListener('click',e=>{if(e.target.id==='modalMask')closeModal();});
  $('#adminDockBtn')?.addEventListener('click',()=>$('#adminMenu').classList.toggle('open'));
  $('#loginBtn')?.addEventListener('click',showLoginModal);
  $('#reloadNotesBtn')?.addEventListener('click',fetchNotes);
  $('#logoutBtn')?.addEventListener('click',logoutSupabase);
  $('#addSchoolNoteBtn')?.addEventListener('click',()=>{const s=getActiveSchool(); if(s)showNoteEditor('schools',keySchool(s),`${s.name}｜学校备注`);});
}
function bindScoreInputs(){
  const pairs=[['targetScoreRange','targetScoreInput'],['downRange','downInput'],['upRange','upInput']];
  pairs.forEach(([r,i])=>{const rr=$('#'+r), ii=$('#'+i); rr.addEventListener('input',()=>{ii.value=rr.value;updateRangeSummary()}); ii.addEventListener('input',()=>{rr.value=ii.value;updateRangeSummary()});});
  $('#applyScoreBtn').addEventListener('click',()=>{const target=+$('#targetScoreInput').value, down=+$('#downInput').value, up=+$('#upInput').value;state.scoreRange={target,down,up,min:target-down,max:target+up};$('#scoreBtn').textContent=`分数 ${target-down}—${target+up}`;closePanel('scorePanel');applyFilters();});
  $('#clearScoreBtn').addEventListener('click',()=>{state.scoreRange=null;$('#scoreBtn').textContent='目标分区间';closePanel('scorePanel');applyFilters();});
}
function updateRangeSummary(){const t=+$('#targetScoreInput').value||0,d=+$('#downInput').value||0,u=+$('#upInput').value||0;$('#rangeSummary').textContent=`目标分：${t}｜下浮${d}｜上浮${u}｜区间${t-d}—${t+u}｜含新增组预测分`;}
function bindMedicalInputs(){
  const input=$('#medicalCodeInput');
  if(!input)return;
  input.addEventListener('input',updateMedicalPanelSummary);
  $$('[data-medical-code]').forEach(btn=>btn.addEventListener('click',()=>{
    const codes=new Set(parseMedicalCodes(input.value));
    const c=btn.dataset.medicalCode;
    if(codes.has(c))codes.delete(c); else codes.add(c);
    input.value=[...codes].sort((a,b)=>Number(a)-Number(b)).join(' ');
    updateMedicalPanelSummary();
  }));
  $('#applyMedicalBtn')?.addEventListener('click',()=>{
    state.medicalCodes=new Set(parseMedicalCodes(input.value));
    saveMedicalRestrictionCodes();
    const changed=cleanupVolunteerForMedicalRestrictions();
    updateMedicalButton();
    closePanel('medicalPanel');
    applyFilters();
    if($('#volunteerPanel')?.classList.contains('open'))renderVolunteerPanel({skipCapture:true});
    if(changed)alert('已自动移除志愿表中与当前体检代码冲突的专业。');
  });
  $('#clearMedicalBtn')?.addEventListener('click',()=>{
    input.value='';
    state.medicalCodes=new Set();
    saveMedicalRestrictionCodes();
    updateMedicalPanelSummary();
    updateMedicalButton();
    closePanel('medicalPanel');
    applyFilters();
    if($('#volunteerPanel')?.classList.contains('open'))renderVolunteerPanel({skipCapture:true});
  });
}
function openPanel(id){const panel=$('#'+id);if(panel)panel.classList.add('open');if(id==='volunteerPanel')document.body.classList.add('volunteer-workbench-open');}
function closePanel(id){const panel=$('#'+id);if(panel)panel.classList.remove('open');if(id==='volunteerPanel')document.body.classList.remove('volunteer-workbench-open');}
function toggleHeader(){
  const collapsed=document.body.classList.toggle('header-collapsed');
  $('#toggleHeaderBtn').textContent=collapsed?'展开头部':'收起头部';
}
function toggleCompact(){
  state.compact=!state.compact;
  document.body.classList.toggle('compact-mode',state.compact);
  $('#compactBtn').textContent=state.compact?'标准显示':'紧凑显示';
}
function isValidFacetValue(v){
  const t=String(v??'').trim();
  if(!t)return false;
  if(t.includes('#REF'))return false;
  if(/^#(VALUE|N\/A|DIV\/0|NAME|NULL|NUM)!?$/i.test(t))return false;
  return true;
}
function countGet(counterMap,key){return counterMap&&typeof counterMap.get==='function'?(counterMap.get(key)||0):0;}
function selectedSummary(defaultText,setRef,unit){
  const arr=[...setRef];
  if(!arr.length)return defaultText;
  return arr.length===1?arr[0]:`${arr[0]} +${arr.length-1}`;
}
function groupsFromOrderedItems(items,counts,groupDefs,otherTitle='其他'){
  const itemSet=new Set(items);
  const used=new Set();
  const out=[];
  groupDefs.forEach(def=>{
    const arr=(def.items||[]).filter(x=>itemSet.has(x)&&countGet(counts,x)>0);
    arr.forEach(x=>used.add(x));
    if(arr.length)out.push({title:def.title,items:arr});
  });
  const other=items.filter(x=>!used.has(x));
  if(other.length)out.push({title:otherTitle,items:other});
  return out;
}
function renderFacetPanel(opts){
  const {panelId,bodyId,title,searchPlaceholder,groups,counts,setRef,buttonUpdater,clearLabel,helpText}=opts;
  const body=document.getElementById(bodyId);
  if(!body){console.error('筛选面板容器不存在：',bodyId);return;}
  const draft=new Set([...setRef]);
  const groupPayloads=groups.map(g=>g.items||[]);
  body.innerHTML=`
    <div class="facet-top">
      <div class="facet-help">${esc(helpText||'先在面板内勾选，最后点“应用筛选”；支持搜索、分组全选和单项取消。')}</div>
      <div class="facet-selected" data-facet-selected></div>
      <input class="facet-search" type="search" placeholder="${esc(searchPlaceholder||'搜索选项')}">
    </div>
    <div class="facet-section-list">
      ${groups.map((g,idx)=>`<section class="facet-section" data-facet-section>
        <div class="facet-section-head"><h4>${esc(g.title)} <span>${(g.items||[]).length}</span></h4><div><button type="button" data-facet-group-select="${idx}">全选</button><button type="button" data-facet-group-clear="${idx}">清空</button></div></div>
        <div class="facet-grid">${(g.items||[]).map(v=>`<label class="facet-option" data-facet-item data-search="${esc(v)}"><input type="checkbox" data-facet-value value="${esc(v)}" ${draft.has(v)?'checked':''}><span>${esc(v)}</span><em>${countGet(counts,v)}</em></label>`).join('')}</div>
      </section>`).join('')}
    </div>
    <div class="facet-footer"><button type="button" data-facet-clear>${esc(clearLabel||'清空全部')}</button><button type="button" data-facet-cancel>取消</button><button type="button" class="save" data-facet-apply>应用筛选</button></div>`;
  const cbs=()=>Array.from(body.querySelectorAll('input[data-facet-value]'));
  function syncChecks(){
    cbs().forEach(cb=>{cb.checked=draft.has(cb.value); cb.closest('.facet-option')?.classList.toggle('checked',cb.checked);});
    const selected=body.querySelector('[data-facet-selected]');
    const arr=[...draft];
    selected.innerHTML=arr.length?`<div class="facet-selected-title">已选 ${arr.length} 项</div><div class="facet-selected-chips">${arr.map(v=>`<button type="button" data-facet-remove="${esc(v)}">${esc(v)} ×</button>`).join('')}</div>`:`<div class="facet-selected-empty">尚未选择，默认不过滤。</div>`;
    selected.querySelectorAll('[data-facet-remove]').forEach(btn=>btn.addEventListener('click',()=>{draft.delete(btn.dataset.facetRemove);syncChecks();}));
  }
  function filterOptions(){
    const q=normalize(body.querySelector('.facet-search')?.value||'');
    body.querySelectorAll('[data-facet-item]').forEach(el=>{
      const show=!q||normalize(el.dataset.search||el.textContent).includes(q);
      el.style.display=show?'':'none';
    });
    body.querySelectorAll('[data-facet-section]').forEach(sec=>{
      const any=Array.from(sec.querySelectorAll('[data-facet-item]')).some(el=>el.style.display!=='none');
      sec.style.display=any?'':'none';
    });
  }
  cbs().forEach(cb=>cb.addEventListener('change',()=>{if(cb.checked)draft.add(cb.value);else draft.delete(cb.value);syncChecks();}));
  body.querySelectorAll('[data-facet-group-select]').forEach(btn=>btn.addEventListener('click',()=>{(groupPayloads[+btn.dataset.facetGroupSelect]||[]).forEach(v=>draft.add(v));syncChecks();filterOptions();}));
  body.querySelectorAll('[data-facet-group-clear]').forEach(btn=>btn.addEventListener('click',()=>{(groupPayloads[+btn.dataset.facetGroupClear]||[]).forEach(v=>draft.delete(v));syncChecks();filterOptions();}));
  body.querySelector('[data-facet-clear]').addEventListener('click',()=>{draft.clear();syncChecks();filterOptions();});
  body.querySelector('[data-facet-cancel]').addEventListener('click',()=>closePanel(panelId));
  body.querySelector('[data-facet-apply]').addEventListener('click',()=>{
    if(panelId==='requirementPanel')state.requirementAutoFromStudent=false;
    setRef.clear();
    draft.forEach(v=>setRef.add(v));
    buttonUpdater();
    closePanel(panelId);
    applyFilters();
  });
  body.querySelector('.facet-search').addEventListener('input',filterOptions);
  syncChecks();
}
function buildProvincePanel(){
  const provinceCounts=schoolCountBy('province');
  const provinceItems=Array.from(provinceCounts.keys()).sort((a,b)=>(provinceCounts.get(b)-provinceCounts.get(a))||a.localeCompare(b,'zh-Hans-CN'));
  const provinceGroups=groupsFromOrderedItems(provinceItems,provinceCounts,provinceRegionGroups,'其他地区');
  const cityCounts=schoolCityCountByProvince('江苏');
  const jiangsuCityGroups=JIANGSU_CITY_GROUPS.map(g=>({title:g.title,items:(g.items||[]).filter(c=>cityCounts.has(c)||true)}));
  const jiangsuCityCount=jiangsuCityGroups.reduce((sum,g)=>sum+(g.items||[]).length,0);
  const body=document.getElementById('provincePanelBody');
  if(!body)return;
  const draftP=new Set([...state.selectedProvinces]);
  const draftC=new Set([...state.selectedCities]);
  const provincePayloads=provinceGroups.map(g=>g.items||[]);
  body.innerHTML=`
    <div class="facet-top">
      <div class="facet-help">地区支持两级筛选：省份可以多选；江苏省内城市放在最上方，按苏南、苏中、苏北分组。常见需求如只看南京、苏州，可直接勾选城市后应用筛选。</div>
      <div class="facet-selected" data-facet-selected></div>
      <input class="facet-search" type="search" placeholder="搜索省份或城市，如 江苏 / 南京 / 苏州">
    </div>
    <div class="facet-section-list">
      <section class="facet-section city-facet-section" data-facet-section data-section-type="city" data-province-city-section="江苏">
        <div class="facet-section-head"><h4>江苏省内的城市 <span>${jiangsuCityCount}</span></h4><div><button type="button" data-city-select-all>全选江苏城市</button><button type="button" data-city-clear>清空城市</button></div></div>
        ${jiangsuCityGroups.map((g,idx)=>`<div class="city-group-block" data-city-group-block="${idx}"><div class="city-group-title">${esc(g.title)} <span>${(g.items||[]).length}</span><div><button type="button" data-city-group-select="${idx}">全选</button><button type="button" data-city-group-clear="${idx}">清空</button></div></div><div class="facet-grid city-grid">${(g.items||[]).map(v=>`<label class="facet-option city-option" data-facet-item data-search="${esc('江苏 '+g.title+' '+v)}"><input type="checkbox" data-city-value value="${esc(v)}" ${draftC.has(v)?'checked':''}><span>${esc(v)}</span><em>${countGet(cityCounts,v)}</em></label>`).join('')}</div></div>`).join('')}
      </section>
      ${provinceGroups.map((g,idx)=>`<section class="facet-section" data-facet-section data-section-type="province">
        <div class="facet-section-head"><h4>${esc(g.title)} <span>${(g.items||[]).length}</span></h4><div><button type="button" data-province-group-select="${idx}">全选</button><button type="button" data-province-group-clear="${idx}">清空</button></div></div>
        <div class="facet-grid">${(g.items||[]).map(v=>`<label class="facet-option" data-facet-item data-search="${esc(v)}"><input type="checkbox" data-province-value value="${esc(v)}" ${draftP.has(v)?'checked':''}><span>${esc(v)}</span><em>${countGet(provinceCounts,v)}</em></label>`).join('')}</div>
      </section>`).join('')}
    </div>
    <div class="facet-footer"><button type="button" data-facet-clear>清空全部地区</button><button type="button" data-facet-cancel>取消</button><button type="button" class="save" data-facet-apply>应用筛选</button></div>`;
  const provinceCbs=()=>Array.from(body.querySelectorAll('input[data-province-value]'));
  const cityCbs=()=>Array.from(body.querySelectorAll('input[data-city-value]'));
  function syncChecks(){
    if(draftC.size)draftP.add('江苏');
    if(!draftP.has('江苏'))draftC.clear();
    provinceCbs().forEach(cb=>{cb.checked=draftP.has(cb.value); cb.closest('.facet-option')?.classList.toggle('checked',cb.checked);});
    cityCbs().forEach(cb=>{cb.checked=draftC.has(cb.value); cb.closest('.facet-option')?.classList.toggle('checked',cb.checked);});
    const citySection=body.querySelector('[data-province-city-section="江苏"]');
    if(citySection)citySection.classList.toggle('city-section-active',draftP.has('江苏'));
    const selected=body.querySelector('[data-facet-selected]');
    const chips=[];
    [...draftP].sort((a,b)=>a.localeCompare(b,'zh-Hans-CN')).forEach(v=>chips.push({type:'province',value:v,label:v}));
    [...draftC].forEach(v=>chips.push({type:'city',value:v,label:`${v}市`}));
    selected.innerHTML=chips.length?`<div class="facet-selected-title">已选 ${draftP.size} 省 / ${draftC.size} 市</div><div class="facet-selected-chips">${chips.map(x=>`<button type="button" data-region-remove-type="${x.type}" data-region-remove="${esc(x.value)}">${esc(x.label)} ×</button>`).join('')}</div>`:`<div class="facet-selected-empty">尚未选择，默认不过滤地区。</div>`;
    selected.querySelectorAll('[data-region-remove]').forEach(btn=>btn.addEventListener('click',()=>{if(btn.dataset.regionRemoveType==='city')draftC.delete(btn.dataset.regionRemove);else{draftP.delete(btn.dataset.regionRemove);if(btn.dataset.regionRemove==='江苏')draftC.clear();}syncChecks();filterOptions();}));
  }
  function filterOptions(){
    const q=normalize(body.querySelector('.facet-search')?.value||'');
    body.querySelectorAll('[data-facet-item]').forEach(el=>{const show=!q||normalize(el.dataset.search||el.textContent).includes(q);el.style.display=show?'':'none';});
    body.querySelectorAll('[data-facet-section], [data-city-group-block]').forEach(sec=>{const any=Array.from(sec.querySelectorAll('[data-facet-item]')).some(el=>el.style.display!=='none');sec.style.display=any?'':'none';});
  }
  provinceCbs().forEach(cb=>cb.addEventListener('change',()=>{if(cb.checked)draftP.add(cb.value);else{draftP.delete(cb.value);if(cb.value==='江苏')draftC.clear();}syncChecks();filterOptions();}));
  cityCbs().forEach(cb=>cb.addEventListener('change',()=>{if(cb.checked){draftC.add(cb.value);draftP.add('江苏');}else draftC.delete(cb.value);syncChecks();filterOptions();}));
  body.querySelectorAll('[data-province-group-select]').forEach(btn=>btn.addEventListener('click',()=>{(provincePayloads[+btn.dataset.provinceGroupSelect]||[]).forEach(v=>draftP.add(v));syncChecks();filterOptions();}));
  body.querySelectorAll('[data-province-group-clear]').forEach(btn=>btn.addEventListener('click',()=>{(provincePayloads[+btn.dataset.provinceGroupClear]||[]).forEach(v=>{draftP.delete(v);if(v==='江苏')draftC.clear();});syncChecks();filterOptions();}));
  body.querySelector('[data-city-select-all]').addEventListener('click',()=>{JIANGSU_CITIES.forEach(v=>draftC.add(v));draftP.add('江苏');syncChecks();filterOptions();});
  body.querySelector('[data-city-clear]').addEventListener('click',()=>{draftC.clear();syncChecks();filterOptions();});
  body.querySelectorAll('[data-city-group-select]').forEach(btn=>btn.addEventListener('click',()=>{const group=JIANGSU_CITY_GROUPS[+btn.dataset.cityGroupSelect];(group?.items||[]).forEach(v=>draftC.add(v));draftP.add('江苏');syncChecks();filterOptions();}));
  body.querySelectorAll('[data-city-group-clear]').forEach(btn=>btn.addEventListener('click',()=>{const group=JIANGSU_CITY_GROUPS[+btn.dataset.cityGroupClear];(group?.items||[]).forEach(v=>draftC.delete(v));syncChecks();filterOptions();}));
  body.querySelector('[data-facet-clear]').addEventListener('click',()=>{draftP.clear();draftC.clear();syncChecks();filterOptions();});
  body.querySelector('[data-facet-cancel]').addEventListener('click',()=>closePanel('provincePanel'));
  body.querySelector('[data-facet-apply]').addEventListener('click',()=>{state.selectedProvinces.clear();state.selectedCities.clear();draftP.forEach(v=>state.selectedProvinces.add(v));draftC.forEach(v=>state.selectedCities.add(v));updateProvinceButton();closePanel('provincePanel');applyFilters();});
  body.querySelector('.facet-search').addEventListener('input',filterOptions);
  syncChecks();
}
function buildLevelPanel(){
  const counts=schoolFacetCounts();
  const items=Array.from(counts.keys()).sort((a,b)=>{
    const order=levelFacetGroups.flatMap(g=>g.items);
    const ai=order.indexOf(a), bi=order.indexOf(b);
    if(ai>=0&&bi>=0)return ai-bi;
    if(ai>=0)return -1; if(bi>=0)return 1;
    return (counts.get(b)-counts.get(a))||String(a).localeCompare(String(b),'zh-Hans-CN');
  });
  const groups=groupsFromOrderedItems(items,counts,levelFacetGroups,'其他层次');
  renderFacetPanel({panelId:'levelPanel',bodyId:'levelPanelBody',title:'院校层次筛选',searchPlaceholder:'搜索层次，如 985 / 211 / 双一流 / 保研双非 / 普通公办',groups,counts,setRef:state.selectedLevels,buttonUpdater:updateLevelButton,clearLabel:'清空院校层次'});
}

function groupSpecialTypeValues(s,g){
  const vals=new Set();
  const parts=[s?.name,s?.level,s?.batch,s?.subject,g?.groupName,g?.displayCode,g?.rawGroupName,g?.majorSummary,g?.remark,(g?.tags||[]).join(' '),(g?.majorClasses||[]).join(' ')];
  (g?.majors||[]).forEach(m=>{
    const d=DETAILS[m.key]||{};
    parts.push(m.name,m.baseName,m.remark,m.majorClass,m.discipline,m.tuition,d.majorFullName,d.majorRemark,d.tuition,d.schoolTags,d.schoolLevel,d.recruitChapter,d.admissionRule);
  });
  const text=String(parts.filter(Boolean).join(' '));
  const add=x=>{if(isValidFacetValue(x))vals.add(x);};
  (g?.tags||[]).forEach(t=>add(t));
  if(/定向军士男/.test(text))add('定向军士男');
  if(/定向军士女/.test(text))add('定向军士女');
  if(/3\+2|3＋2/.test(text))add('3+2');
  if(/5\+0|5＋0/.test(text))add('5+0');
  if(/定向医学/.test(text))add('定向医学');
  if(/司法警察男|只招男生/.test(g?.remark||''))add('司法警察男');
  if(/司法警察女|只招女生/.test(g?.remark||''))add('司法警察女');
  ['连云港','扬州','淮安','镇江','南通','宿迁'].forEach(city=>{if(new RegExp(`石邮${city}|${city}地区就业`).test(text)&&/石家庄邮电职业技术学院/.test(text))add(`石邮${city}`);});
  if(/中外合作|合作办学|中外合办|国际合作|4\+0|3\+1|2\+2|外方|双校园|中英|中澳|中美|中法|中德|中俄|中韩|中日/.test(text))add('中外合作');
  if(/联合培养|高职院校联合|本科与高职|分段培养|贯通培养|协同培养|联合办学|联合学院/.test(text))add('联合培养');
  const hasHighTuition=(g?.majors||[]).some(m=>{const d=DETAILS[m.key]||{}; const t=num(m.tuition)||num(d.tuition); return t!==null&&t>=25000;});
  if(/高收费|较高收费|收费较高|学费较高/.test(text)||hasHighTuition)add('高收费');
  if(/境外|国外|海外|国际校区|马来西亚|香港|澳门|全英文|都柏林|奥塔哥|蒙纳士|昆士兰|诺森比亚|诺丁汉|杜克|纽约大学|利物浦/.test(text))add('境外/国际培养');
  if(/校企合作|产教融合|现代产业学院|产业学院|企业联合|行业联合|订单班|卓越工程师学院|未来技术学院/.test(text))add('校企合作/产教融合');
  if(/定向|公费师范|免费师范|优师|免费医学|委托培养|订单定向/.test(text))add('定向/公费/优师');
  if(/定向军士|军士/.test(text))add('定向/军士');
  if(/地方专项|高校专项|国家专项|农村专项|专项计划|综合评价|强基/.test(text))add('专项计划');
  if(/民族班|预科|少数民族/.test(text))add('民族班/预科');
  if(/军校|公安|警校|航海|轮机|飞行技术|民航|空中交通管制|司法警官|消防/.test(text))add('军警航海');
  if(/实验班|试验班|拔尖|强基|钱学森|英才|菁英|创新班|卓越班|领军|尖班|书院/.test(text))add('实验班/拔尖班');
  if(/双学士|双学位|本博|本硕|硕博|直博|长学制|八年制|九年制/.test(text))add('双学位/本博硕博');
  return vals;
}
function specialTypeCounts(){
  const m=new Map();
  DB.forEach(s=>(s.groups||[]).forEach(g=>groupSpecialTypeValues(s,g).forEach(v=>m.set(v,(m.get(v)||0)+1))));
  return m;
}
function specialTagItems(){
  return unique(DB.flatMap(s=>(s.groups||[]).flatMap(g=>g.tags||[]))).filter(isValidFacetValue).sort((a,b)=>String(a).localeCompare(String(b),'zh-Hans-CN'));
}
function buildSpecialPanel(){
  const counts=specialTypeCounts();
  const roleItems=specialTagItems().filter(v=>countGet(counts,v)>0);
  const items=Array.from(counts.keys()).sort((a,b)=>{
    const order=[...specialTypeFacetGroups.flatMap(g=>g.items),...roleItems];
    const ai=order.indexOf(a), bi=order.indexOf(b);
    if(ai>=0&&bi>=0)return ai-bi;
    if(ai>=0)return -1;
    if(bi>=0)return 1;
    return (counts.get(b)-counts.get(a))||String(a).localeCompare(String(b),'zh-Hans-CN');
  });
  const groupDefs=[...specialTypeFacetGroups,{title:'客观标签',items:roleItems}];
  const groups=groupsFromOrderedItems(items,counts,groupDefs,'其他特殊类型/标签');
  renderSpecialPanel(groups,counts);
}
function renderSpecialPanel(groups,counts){
  const panelId='specialPanel', bodyId='specialPanelBody';
  const body=document.getElementById(bodyId);
  if(!body){console.error('筛选面板容器不存在：',bodyId);return;}
  const draft=new Set([...state.selectedSpecialTypes]);
  let draftMode=state.specialTypeMode||'exclude';
  const groupPayloads=groups.map(g=>g.items||[]);
  body.innerHTML=`
    <div class="facet-top">
      <div class="facet-help">先选择筛选方式：<b>只看已选类型</b> 用来只看定向军士、3+2、5+0、中外合作、定向医学、司法警察、石邮地区就业等特殊组；<b>排除已选类型</b> 用来不看这些特殊组。</div>
      <div class="special-mode-toggle" data-special-mode>
        <label class="${draftMode==='include'?'checked':''}"><input type="radio" name="specialModeDraft" value="include" ${draftMode==='include'?'checked':''}>只看已选类型</label>
        <label class="${draftMode!=='include'?'checked':''}"><input type="radio" name="specialModeDraft" value="exclude" ${draftMode!=='include'?'checked':''}>排除已选类型</label>
      </div>
      <div class="facet-selected" data-facet-selected></div>
      <input class="facet-search" type="search" placeholder="搜索特殊类型，如 定向军士男 / 3+2 / 5+0 / 中外合作 / 石邮扬州">
    </div>
    <div class="facet-section-list">
      ${groups.map((g,idx)=>`<section class="facet-section" data-facet-section>
        <div class="facet-section-head"><h4>${esc(g.title)} <span>${(g.items||[]).length}</span></h4><div><button type="button" data-facet-group-select="${idx}">全选</button><button type="button" data-facet-group-clear="${idx}">清空</button></div></div>
        <div class="facet-grid">${(g.items||[]).map(v=>`<label class="facet-option" data-facet-item data-search="${esc(v)}"><input type="checkbox" data-facet-value value="${esc(v)}" ${draft.has(v)?'checked':''}><span>${esc(v)}</span><em>${countGet(counts,v)}</em></label>`).join('')}</div>
      </section>`).join('')}
    </div>
    <div class="facet-footer"><button type="button" data-facet-clear>清空全部</button><button type="button" data-facet-cancel>取消</button><button type="button" class="save" data-facet-apply>应用筛选</button></div>`;
  const cbs=()=>Array.from(body.querySelectorAll('input[data-facet-value]'));
  function syncMode(){
    body.querySelectorAll('[data-special-mode] label').forEach(label=>{
      const input=label.querySelector('input');
      label.classList.toggle('checked',input&&input.checked);
    });
  }
  function syncChecks(){
    cbs().forEach(cb=>{cb.checked=draft.has(cb.value); cb.closest('.facet-option')?.classList.toggle('checked',cb.checked);});
    const selected=body.querySelector('[data-facet-selected]');
    const arr=[...draft];
    const modeLabel=draftMode==='include'?'只看':'排除';
    selected.innerHTML=arr.length?`<div class="facet-selected-title">${modeLabel} ${arr.length} 项</div><div class="facet-selected-chips">${arr.map(v=>`<button type="button" data-facet-remove="${esc(v)}">${esc(v)} ×</button>`).join('')}</div>`:`<div class="facet-selected-empty">尚未选择，默认不过滤。</div>`;
    selected.querySelectorAll('[data-facet-remove]').forEach(btn=>btn.addEventListener('click',()=>{draft.delete(btn.dataset.facetRemove);syncChecks();}));
    syncMode();
  }
  function filterOptions(){
    const q=normalize(body.querySelector('.facet-search')?.value||'');
    body.querySelectorAll('[data-facet-item]').forEach(el=>{
      const show=!q||normalize(el.dataset.search||el.textContent).includes(q);
      el.style.display=show?'':'none';
    });
    body.querySelectorAll('[data-facet-section]').forEach(sec=>{
      const any=Array.from(sec.querySelectorAll('[data-facet-item]')).some(el=>el.style.display!=='none');
      sec.style.display=any?'':'none';
    });
  }
  body.querySelectorAll('input[name="specialModeDraft"]').forEach(r=>r.addEventListener('change',()=>{draftMode=r.value;syncChecks();}));
  cbs().forEach(cb=>cb.addEventListener('change',()=>{if(cb.checked)draft.add(cb.value);else draft.delete(cb.value);syncChecks();}));
  body.querySelectorAll('[data-facet-group-select]').forEach(btn=>btn.addEventListener('click',()=>{(groupPayloads[+btn.dataset.facetGroupSelect]||[]).forEach(v=>draft.add(v));syncChecks();filterOptions();}));
  body.querySelectorAll('[data-facet-group-clear]').forEach(btn=>btn.addEventListener('click',()=>{(groupPayloads[+btn.dataset.facetGroupClear]||[]).forEach(v=>draft.delete(v));syncChecks();filterOptions();}));
  body.querySelector('[data-facet-clear]').addEventListener('click',()=>{draft.clear();syncChecks();filterOptions();});
  body.querySelector('[data-facet-cancel]').addEventListener('click',()=>closePanel(panelId));
  body.querySelector('[data-facet-apply]').addEventListener('click',()=>{state.selectedSpecialTypes.clear();draft.forEach(v=>state.selectedSpecialTypes.add(v));state.specialTypeMode=draftMode;updateSpecialButton();closePanel(panelId);applyFilters();});
  body.querySelector('.facet-search').addEventListener('input',filterOptions);
  syncChecks();
}
function updateSpecialButton(){
  const arr=[...state.selectedSpecialTypes];
  const btn=$('#specialBtn');
  if(!btn)return;
  if(!arr.length){btn.textContent='特殊类型/标签';btn.classList.remove('special-active');return;}
  const prefix=state.specialTypeMode==='include'?'只看':'排除';
  btn.textContent=arr.length===1?`${prefix}${arr[0]}`:`${prefix}${arr[0]} +${arr.length-1}`;
  btn.classList.add('special-active');
}
function groupMatchesSpecialSelection(s,g){
  if(!state.selectedSpecialTypes.size)return true;
  const vals=groupSpecialTypeValues(s,g);
  const hit=[...state.selectedSpecialTypes].some(v=>vals.has(v));
  return state.specialTypeMode==='include'?hit:!hit;
}

function buildRequirementPanel(){
  const counts=groupCountBy('requirement');
  const order=['不限','化学','生物','化和生','政治','地理','政和地','生和地'];
  const items=Array.from(counts.keys()).sort((a,b)=>{
    const ai=order.indexOf(a), bi=order.indexOf(b);
    if(ai>=0&&bi>=0)return ai-bi;
    if(ai>=0)return -1;
    if(bi>=0)return 1;
    return (counts.get(b)-counts.get(a))||String(a).localeCompare(String(b),'zh-Hans-CN');
  });
  const groups=groupsFromOrderedItems(items,counts,[{title:'常用要求',items:['不限','化学','生物']},{title:'组合要求',items:['化和生','政和地','生和地']},{title:'其他要求',items:['政治','地理']}],'其他选科');
  renderFacetPanel({panelId:'requirementPanel',bodyId:'requirementPanelBody',title:'选科要求筛选',searchPlaceholder:'搜索选科要求，如 化学 / 不限',groups,counts,setRef:state.selectedRequirements,buttonUpdater:updateRequirementButton,clearLabel:'清空选科要求'});
}
function CounterLike(){this.m=new Map();this.add=k=>this.m.set(k,(this.m.get(k)||0)+1);this.keys=()=>this.m.keys();this.get=k=>this.m.get(k)||0;}
function buildClassPanel(){
  const counts=new CounterLike();
  DB.forEach(s=>s.groups.forEach(g=>(g.majorClasses||[]).forEach(c=>counts.add(c))));
  const byDisc={};
  [...counts.keys()].forEach(c=>{let disc='其他'; DB.some(s=>s.groups.some(g=>g.majors.some(m=>{if(m.majorClass===c){disc=m.discipline||'其他';return true}return false;}))); (byDisc[disc]||(byDisc[disc]=[])).push(c);});
  const groups=disciplineOrder.map(d=>{let arr=byDisc[d]||[]; arr.sort((a,b)=>{let ai=hotOrder.indexOf(a),bi=hotOrder.indexOf(b); if(ai<0)ai=999;if(bi<0)bi=999; if(ai!==bi)return ai-bi; return (counts.get(b)-counts.get(a))||a.localeCompare(b,'zh-Hans-CN');}); return {title:d,items:arr};}).filter(g=>g.items.length);
  renderFacetPanel({panelId:'classPanel',bodyId:'classPanelBody',title:'专业大类筛选',searchPlaceholder:'搜索专业类，如 计算机 / 电子信息 / 土木',groups,counts,setRef:state.selectedClasses,buttonUpdater:updateClassButton,clearLabel:'清空专业大类'});
}
function updateProvinceButton(){const p=state.selectedProvinces.size,c=state.selectedCities.size; const btn=$('#provinceBtn'); if(!btn)return; if(!p&&!c){btn.textContent='全部省份';return;} if(c&&p===1&&state.selectedProvinces.has('江苏')){const arr=[...state.selectedCities]; btn.textContent=arr.length===1?`江苏：${arr[0]}`:`江苏：${arr[0]} +${arr.length-1}`;return;} btn.textContent=`地区 ${p}省${c?`/${c}市`:''}`;}
function updateLevelButton(){const n=state.selectedLevels.size; $('#levelBtn').textContent=selectedSummary('院校层次',state.selectedLevels,'院校层次');}
function updateRequirementButton(){
  const btn=$('#requirementBtn');
  if(!btn)return;
  if(state.requirementAutoFromStudent&&currentStudent){
    btn.textContent=`选科：${studentSubjectShortSummary(currentStudent)}`;
    btn.classList.add('student-sync-active');
    return;
  }
  btn.classList.remove('student-sync-active');
  btn.textContent=selectedSummary('选科要求',state.selectedRequirements,'选科要求');
}
function updateClassButton(){const n=state.selectedClasses.size; $('#classBtn').textContent=selectedSummary('全部专业大类',state.selectedClasses,'专业大类');}
function groupMatchesSearch(s,g,q){if(!q)return true; const nq=normalize(q); if(normalize(s.name+s.province+s.city+s.subject+s.batch).includes(nq))return true; if(normalize(g.groupName+groupDisplayName(s,g)+g.requirement+(g.tags||[]).join('')+(g.majorClasses||[]).join('')+g.majorSummary).includes(nq))return true; return g.majors.some(m=>normalize(m.name+m.majorClass+m.discipline+m.code).includes(nq));}
function groupMatchesScore(s,g){
  if(!state.scoreRange)return true;
  const scores=[];
  if(num(g.score25)!==null)scores.push(num(g.score25));
  g.majors.forEach(m=>{if(num(m.score25)!==null)scores.push(num(m.score25));});
  const p=groupScoreEstimate(s,g);
  if(p&&num(p.score)!==null)scores.push(num(p.score));
  return scores.some(sc=>sc>=state.scoreRange.min&&sc<=state.scoreRange.max);
}
function groupMatchesClass(g){if(!state.selectedClasses.size)return true; return (g.majorClasses||[]).some(c=>state.selectedClasses.has(c));}
function groupMatchesRequirement(g){
  const req=String(g.requirement||'').trim();
  if(state.requirementAutoFromStudent&&currentStudent)return requirementMatchesStudent(req,currentStudent);
  if(!state.selectedRequirements.size)return true;
  return state.selectedRequirements.has(req);
}

function groupWeightedMajorScore(g){
  let sum=0, weight=0, count=0;
  (g.majors||[]).forEach(m=>{
    const score=num(m.score25);
    if(score===null)return;
    let w=num(m.plan25);
    if(w===null||w<=0)w=num(m.admit25);
    if(w===null||w<=0)w=num(m.plan26);
    if(w===null||w<=0)w=1;
    sum+=score*w; weight+=w; count+=1;
  });
  if(weight>0)return {score:Math.round(sum/weight*10)/10,weight,count};
  const fallback=num(g.score25);
  return fallback!==null?{score:fallback,weight:0,count:0,fallback:true}:null;
}
function groupWeightedMajorScoreValue(g){
  const x=groupWeightedMajorScore(g);
  return x&&num(x.score)!==null?num(x.score):-1;
}
function groupWeightedMajorBadge(g){
  const x=groupWeightedMajorScore(g);
  if(!x)return '<span class="tag muted">组内加权均分 —</span>';
  const title=x.fallback?'专业分缺失时以专业组投档线兜底':'按组内各专业 25 年最低分 × 25 计划人数加权';
  return `<span class="tag group-weighted-score" title="${esc(title)}">组内加权均分 ${fmtNum(x.score)}</span>`;
}
function sortGroupsByWeightedMajorScore(groups){
  return [...groups].sort((a,b)=>{
    const aw=groupWeightedMajorScoreValue(a), bw=groupWeightedMajorScoreValue(b);
    if(bw!==aw)return bw-aw;
    const ar=num(a.rank25)??1e9, br=num(b.rank25)??1e9;
    if(ar!==br)return ar-br;
    const as=num(a.score25)??-1, bs=num(b.score25)??-1;
    if(bs!==as)return bs-as;
    return String(a.groupName||a.displayCode||'').localeCompare(String(b.groupName||b.displayCode||''),'zh-Hans-CN');
  });
}
function applyFilters(){
  const result=[]; const q=state.q;
  DB.forEach(s=>{
    if(state.batch&&s.batch!==state.batch)return;
    if(state.subject&&s.subject!==state.subject)return;
    if(state.selectedProvinces.size&&!state.selectedProvinces.has(s.province))return;
    if(state.selectedCities.size&&!state.selectedCities.has(s.city))return;
    if(!schoolMatchesLevelFacet(s))return;
    const groups=s.groups.filter(g=>{if(!groupMatchesSpecialSelection(s,g))return false; if(!groupMatchesRequirement(g))return false; if(!groupMatchesScore(s,g))return false; if(!groupMatchesClass(g))return false; if(!groupMatchesSearch(s,g,q))return false; return true;});
    const visibleGroups=sortGroupsByWeightedMajorScore(groups);
    if(visibleGroups.length){result.push({...s,visibleGroups});}
  });
  result.sort(schoolSort);
  state.filtered=result;
  if(!result.some(s=>s.id===state.activeSchoolId)) state.activeSchoolId=result[0]?.id||null;
  render();
}
function schoolSort(a,b){
  const aw=a.weightedScore??-1,bw=b.weightedScore??-1; if(bw!==aw)return bw-aw;
  const as=Math.max(...a.visibleGroups.map(g=>g.score25||-1)),bs=Math.max(...b.visibleGroups.map(g=>g.score25||-1)); if(bs!==as)return bs-as;
  const ar=Math.min(...a.visibleGroups.map(g=>g.rank25||1e9)),br=Math.min(...b.visibleGroups.map(g=>g.rank25||1e9)); if(ar!==br)return ar-br;
  return a.name.localeCompare(b.name,'zh-Hans-CN');
}
function majorSortByThreeYear(a,b){
  const as=a.avgScore3??-1, bs=b.avgScore3??-1;
  if(bs!==as)return bs-as;
  const ar=a.avgRank3??1e9, br=b.avgRank3??1e9;
  if(ar!==br)return ar-br;
  const s25a=a.score25??-1, s25b=b.score25??-1;
  if(s25b!==s25a)return s25b-s25a;
  const r25a=a.rank25??1e9, r25b=b.rank25??1e9;
  if(r25a!==r25b)return r25a-r25b;
  return String(a.code||'').localeCompare(String(b.code||''),'zh-Hans-CN');
}
function render(){renderSidebar(); if(state.mode==='groups')renderGroupMode(); else renderSchoolMode();}
function renderSidebar(){
  const totalGroups=state.filtered.reduce((a,s)=>a+s.visibleGroups.length,0);
  $('#resultMeta').textContent=`${state.filtered.length} 所院校｜${totalGroups} 个专业组`;
  $('#schoolList').innerHTML=state.filtered.map(s=>`<div class="school-item ${s.id===state.activeSchoolId?'active':''} ${admissionPriorityInfo(s)?'priority-admission-school':''}" data-school-id="${s.id}" data-note-scope="schools" data-note-key="${esc(keySchool(s))}"><div class="name">${esc(s.name)}${admissionPriorityBadge(s,true)}${noteBadge('schools',keySchool(s))}</div><div class="meta"><span>${esc(displayRegionLabel(s))}</span><span>${esc(s.subject)}</span><span>${esc(s.batch)}</span><span>${s.visibleGroups.length}组</span></div><div class="score-pill">加权均分 ${fmtNum(s.weightedScore)}</div></div>`).join('');
  $$('.school-item').forEach(el=>el.addEventListener('click',()=>{state.activeSchoolId=el.dataset.schoolId;render();}));
  bindNoteHoverAndContext();
}
function getActiveSchool(){return state.filtered.find(s=>s.id===state.activeSchoolId)||state.filtered[0]||null;}
function renderSchoolMode(){const s=getActiveSchool(); if(!s){$('#main').innerHTML='<div class="empty">没有匹配数据，请调整筛选条件。</div>';return;} $('#main').innerHTML=schoolHTML(s,s.visibleGroups,true); bindDynamic();}
function renderGroupMode(){
  const groups=[]; state.filtered.forEach(s=>s.visibleGroups.forEach(g=>groups.push([s,g])));
  const limit=120; const shown=groups.slice(0,limit);
  $('#main').innerHTML=`<div class="school-header"><div class="school-title"><h2>专业组视图</h2><span class="badge green">当前显示 ${shown.length} / ${groups.length} 组</span></div><div class="badges"><span class="badge">按院校加权均分排序</span><span class="badge">分数筛选含新增组预测分</span></div></div>`+shown.map(([s,g])=>groupSectionHTML(s,g)).join('')+(groups.length>limit?`<div class="empty">为保证浏览器性能，当前展示前 ${limit} 个专业组；可以继续缩小筛选条件。</div>`:'');
  bindDynamic();
}
function schoolHTML(s,groups,withCards){
  const plan26=groups.reduce((a,g)=>a+(g.plan26||0),0);
  const plan25=groups.reduce((a,g)=>a+(g.plan25||0),0);
  const planDiff=plan26-plan25;
  return `<section class="school-header" data-note-scope="schools" data-note-key="${esc(keySchool(s))}"><div class="school-title"><div class="school-title-main"><h2>${esc(s.name)} ${admissionPriorityBadge(s)}</h2><button class="school-info-link" type="button" data-school-info="${esc(keySchool(s))}">院校基础信息 ▾</button></div>${noteBadge('schools',keySchool(s))}<button class="anno-btn" data-annotation-scope="schools" data-annotation-key="${esc(keySchool(s))}" data-annotation-title="${esc(s.name)}｜院校批注">查看批注</button><button class="anno-btn primary" data-annotation-scope="schools" data-annotation-key="${esc(keySchool(s))}" data-annotation-title="${esc(s.name)}｜院校批注">新增批注</button></div><div class="badges"><span class="badge">${esc(displayRegionLabel(s))}</span><span class="badge">${esc(s.subject)}</span><span class="badge">${esc(s.batch)}</span><span class="badge green">当前显示 ${groups.length} 组</span></div>${admissionPriorityAlertHTML(s)}<div class="summary-grid"><div class="metric"><b>${fmtNum(s.weightedScore)}</b><span>院校加权平均分</span></div><div class="metric"><b>${fmtNum(s.weightedRank)}</b><span>加权平均位次</span></div><div class="metric"><b>${plan26}</b><span>2026 显示计划</span></div><div class="metric"><b class="${signedClass(planDiff)}">${formatSigned(planDiff)}</b><span>较 2025 计划变化</span></div></div></section>${withCards?`<div class="group-cards">${groups.map(g=>groupCardHTML(s,g)).join('')}</div>`:''}${groups.map(g=>groupSectionHTML(s,g)).join('')}`;
}
function groupCardHTML(s,g){
  const planDiff=(g.plan26||0)-(g.plan25||0);
  const topTags=[...(g.tags||[]).slice(0,3),...(g.majorClasses||[]).slice(0,3)];
  const quality=groupQuality(s,g);
  const title=groupDisplayTitleText(s,g);
  return `<article class="group-card group-quality-${quality.tone}" data-scroll="${g.id}" data-note-scope="groups" data-note-key="${esc(keyGroup(s,g))}" title="${esc(quality.title)}"><div class="group-card-head"><h3>${groupTitleHTML(s,g)}${noteBadge('groups',keyGroup(s,g))}</h3>${groupChangeButtonHTML(s,g,'card')}</div><div class="grid">${groupScoreMiniHTML(s,g)}<div class="mini"><b>${g.majors.length}</b><span>专业数</span></div></div><div class="tag-row">${groupQualityBadge(quality)}${groupMedicalBadge(g)}${groupWeightedMajorBadge(g)}${admissionPriorityBadge(s,true)}${predictionBadgeHTML(s,g)}${planDeltaBadge(planDiff)}${topTags.map(t=>`<span class="tag">${esc(t)}</span>`).join('')}</div><div class="anno-actions">${volunteerButtonHTML(s,g)}${clearMajorButtonHTML(s,g)}<button class="anno-btn" data-annotation-scope="groups" data-annotation-key="${esc(keyGroup(s,g))}" data-annotation-title="${esc(s.name)} ${esc(title)}｜专业组批注">查看批注</button><button class="anno-btn primary" data-annotation-scope="groups" data-annotation-key="${esc(keyGroup(s,g))}" data-annotation-title="${esc(s.name)} ${esc(title)}｜专业组批注">新增批注</button></div></article>`;
}
function groupSectionHTML(s,g){
  const planDiff=(g.plan26||0)-(g.plan25||0);
  const quality=groupQuality(s,g);
  const title=groupDisplayTitleText(s,g);
  return `<section id="${g.id}" class="group-section group-quality-${quality.tone}" data-note-scope="groups" data-note-key="${esc(keyGroup(s,g))}" title="${esc(quality.title)}"><div class="group-head"><div class="group-head-main"><h3>${groupTitleHTML(s,g)}${noteBadge('groups',keyGroup(s,g))}</h3><p>${esc(s.name)}｜再选：${esc(g.requirement||'—')}｜${groupScoreLineHTML(s,g)}｜26计划 ${fmt(g.plan26)}｜较25年 ${formatSigned(planDiff)} ${planDiff===0?'':`<span class="${signedClass(planDiff)}">(${formatSigned(planDiff)})</span>`}</p><div class="tag-row">${groupQualityBadge(quality)}${groupMedicalBadge(g)}${groupWeightedMajorBadge(g)}${admissionPriorityBadge(s,true)}${predictionBadgeHTML(s,g)}${(g.tags||[]).map(t=>`<span class="tag">${esc(t)}</span>`).join('')} ${(g.majorClasses||[]).slice(0,8).map(c=>`<span class="badge">${esc(c)}</span>`).join('')} ${planDeltaBadge(planDiff)}</div><div class="anno-actions">${volunteerButtonHTML(s,g)}${clearMajorButtonHTML(s,g)}<button class="anno-btn" data-annotation-scope="groups" data-annotation-key="${esc(keyGroup(s,g))}" data-annotation-title="${esc(s.name)} ${esc(title)}｜专业组批注">查看批注</button><button class="anno-btn primary" data-annotation-scope="groups" data-annotation-key="${esc(keyGroup(s,g))}" data-annotation-title="${esc(s.name)} ${esc(title)}｜专业组批注">新增批注</button></div></div>${groupChangeButtonHTML(s,g,'section')}</div><div class="table-wrap"><table><thead><tr><th>专业志愿</th><th>代码</th><th>专业名称</th><th>专业类</th><th>26计划/变化</th><th>25分/位次</th><th>三年均分/位次</th></tr></thead><tbody>${[...g.majors].sort(majorSortByThreeYear).map(m=>majorRowHTML(s,g,m)).join('')}</tbody></table></div></section>`;
}
function majorRowHTML(s,g,m){
  const avgYears=m.avgYears&&m.avgYears<3?`<br><span class="muted">${m.avgYears}年均值</span>`:'';
  const groupKey=keyGroup(s,g);
  const order=selectedMajorIndex(groupKey,m.key);
  const checked=order>=0;
  const riskMeta=majorRiskMeta(s,g,m);
  const physical=medicalRestrictionForMajor(m);
  const subjectBlock=subjectRequirementBlockReason(s,g);
  const riskToneClass=riskMeta.tone?`risk-tone-${riskMeta.tone}`:'';
  const disabled=(physical.blocked||subjectBlock)?' disabled':'';
  const physicalTitle=physical.blocked?`体检受限：${physical.reason}`:'';
  return `<tr class="${riskMeta.risk?'risk-row':''} ${riskToneClass} ${physical.blocked?'physical-blocked-row':''} ${subjectBlock?'subject-blocked-row':''} ${checked?'major-selected-row':''}" title="${esc(subjectBlock||physicalTitle||riskMeta.reason||'')}" data-note-scope="majors" data-note-key="${esc(keyMajor(m))}"><td class="major-select-cell"><label class="major-select-box" title="${esc(subjectBlock||physical.blocked?'当前学生档案不满足该专业组选科/体检要求，禁止选择':'勾选后会自动加入该专业组，并按勾选顺序生成专业 1-6')}"><input type="checkbox" data-main-major-check="${esc(groupKey)}" value="${esc(m.key)}" ${checked?'checked':''}${disabled}>${checked?`<span class="major-order-badge">${order+1}</span>`:'<span class="major-order-placeholder"></span>'}</label></td><td>${esc(m.code)}</td><td class="major-name"><span class="major-name-text">${esc(m.name)}</span>${medicalRestrictionLabelHTML(physical)}${subjectBlock?'<span class="risk-label">选科不符</span>':''}${majorRiskLabelHTML(riskMeta)}${noteBadge('majors',keyMajor(m))}<button class="anno-mini" data-annotation-scope="majors" data-annotation-key="${esc(keyMajor(m))}" data-annotation-title="${esc(s.name)} ${esc(groupDisplayTitleText(s,g))} ${esc(m.name)}｜专业批注">批注</button></td><td>${esc(m.majorClass||'其他')}<br><span class="muted">${esc(m.discipline||'其他')}</span></td><td>${fmt(m.plan26)} / ${planChangeInline(m.planChange)}</td><td>${fmtNum(m.score25)} / ${fmtNum(m.rank25)}</td><td>${fmtNum(m.avgScore3)} / ${fmtNum(m.avgRank3)}${avgYears}</td></tr>`;
}
function bindDynamic(){
  $$('[data-scroll]').forEach(el=>el.addEventListener('click',()=>document.getElementById(el.dataset.scroll)?.scrollIntoView({behavior:'smooth',block:'start'})));
  bindVolunteerButtons();
  bindClearMajorGroupButtons();
  bindMainMajorChecks();
  bindGroupChangeButtons();
  bindSchoolInfoButtons();
  bindAnnotationButtons();
  bindNoteHoverAndContext();
}
function noteBadge(scope,key){return notes[scope]&&notes[scope][key]?` <span class="note-badge">备注</span>`:'';}
function bindMajorDetailButtons(){/* V1.1.49：专业详情点击功能已取消 */}
function bindNoteHoverAndContext(){
  $$('[data-note-scope]').forEach(el=>{
    el.onmouseenter=()=>{const n=notes[el.dataset.noteScope]?.[el.dataset.noteKey]; if(n)showNotePanel(n);};
    el.onmouseleave=()=>hideNotePanel();
    if(document.body.dataset.admin==='1'){
      el.oncontextmenu=e=>{e.preventDefault(); showNoteEditor(el.dataset.noteScope,el.dataset.noteKey,`${labelScope(el.dataset.noteScope)}｜${el.dataset.noteKey}`);};
    }
  });
}
function labelScope(s){return s==='schools'?'学校备注':s==='groups'?'专业组备注':'专业备注';}
function showNotePanel(text){$('#notePanelText').textContent=text;$('#notePanel').classList.add('open');}
function hideNotePanel(){$('#notePanel').classList.remove('open');}
function validInfoValue(v){return !(v===undefined||v===null||v===''||v==='/'||v==='—');}
function infoPairHTML([k,v]){return validInfoValue(v)?`<dt>${esc(k)}</dt><dd>${esc(fmtNum(v))}</dd>`:'';}
function infoSectionHTML(title,pairs,extraClass=''){
  const body=pairs.map(infoPairHTML).join('');
  if(!body)return '';
  return `<section class="info-section ${extraClass}"><h4>${esc(title)}</h4><dl class="kv info-kv">${body}</dl></section>`;
}
function normSchoolName(name){return String(name||'').replace(/[（）()\s]/g,'').replace(/学院$/,'').replace(/大学$/,'').toLowerCase();}
function parentSchoolRows(){
  const rows=[];
  if(Array.isArray(window.SCHOOL_LIFE_INFO_DATA?.schools))rows.push(...window.SCHOOL_LIFE_INFO_DATA.schools);
  return rows;
}
function parentSchoolInfo(name){
  const target=normSchoolName(name);
  if(!target)return null;
  const rows=parentSchoolRows();
  return rows.find(x=>normSchoolName(x.name)===target||((x.aliases||[]).some(a=>normSchoolName(a)===target)))||rows.find(x=>{
    const n=normSchoolName(x.name);
    const aliases=(x.aliases||[]).map(normSchoolName);
    const candidates=[n,...aliases].filter(a=>a&&a.length>=6);
    return target.length>=6&&candidates.some(a=>a.includes(target)||target.includes(a));
  })||null;
}
function mapSearchUrls(name,address,city){
  const keyword=[name,address||city].filter(Boolean).join(' ');
  const q=encodeURIComponent(keyword);
  return {
    amap:`https://uri.amap.com/search?keyword=${q}`,
    baidu:`https://map.baidu.com/search/${q}`,
    tencent:`https://apis.map.qq.com/uri/v1/search?keyword=${q}`
  };
}
function linkActionsHTML(links){
  return `<div class="location-actions">${links.map(x=>`<a href="${esc(x.href)}" target="_blank" rel="noreferrer">${esc(x.label)}</a>`).join('')}</div>`;
}
function parentKV(title,pairs){
  return infoSectionHTML(title,pairs,'parent-info-section');
}
function parentSchoolInfoHTML(name,fallback={}){
  const info=parentSchoolInfo(name);
  const basic=info?.basicInfo||info?.basic||{};
  const address=basic.address||fallback.address||'';
  const urls=mapSearchUrls(name,address,fallback.city);
  const mapLinks=linkActionsHTML([
    {label:'高德地图',href:urls.amap},
    {label:'百度地图',href:urls.baidu},
    {label:'腾讯地图',href:urls.tencent}
  ]);
  if(!info){
    const fallbackPairs=[
      ['院校名称',name],
      ['所在城市',fallback.city],
      ['院校层次',fallback.level||fallback.schoolLevel],
      ['公私性质',fallback.publicPrivate],
      ['地址',address]
    ];
    return `<section class="info-section parent-info-section"><h4>位置与宿舍生活信息</h4><div class="parent-school-card"><p class="muted">宿舍生活信息表暂未匹配到该校，已保留招生库基础信息和地图检索入口。地图按“院校名 + 城市/地址”搜索，不使用未核验坐标。</p><dl class="kv info-kv">${fallbackPairs.map(infoPairHTML).join('')}</dl>${mapLinks}</div></section>`;
  }
  const evalInfo=info.evaluation||{};
  const dorm=info.dormitory||{};
  const net=info.networkAndElectricity||info.network||{};
  const daily=info.dailyManagement||info.management||{};
  const life=info.campusLife||{};
  const attentionNotes=evalInfo.attentionNotes||evalInfo.notes||[];
  const notes=Array.isArray(attentionNotes)&&attentionNotes.length?`<ul class="parent-note-list">${attentionNotes.map(n=>`<li>${esc(n)}</li>`).join('')}</ul>`:'';
  return `<section class="info-section parent-info-section"><h4>位置与宿舍生活信息</h4><div class="parent-school-card"><p>${esc(basic.overview||'')}</p><dl class="kv info-kv">${[
    ['地址',address],
    ['办学层次',info.educationLevel],
    ['办学性质',info.ownership],
    ['城市层级',info.cityLevel],
    ['学校方向',evalInfo.schoolOrientation||evalInfo.orientation],
    ['住宿判断',evalInfo.dormitoryLevel||evalInfo.dormitory],
    ['交通便利度',evalInfo.transportLevel||evalInfo.transport],
    ['管理强度',evalInfo.managementLevel||evalInfo.management]
  ].map(infoPairHTML).join('')}</dl>${mapLinks}</div></section>${parentKV('住宿条件',[
    ['床桌情况',dorm.bunkDesk],['宿舍人数',dorm.roomCapacity],['宿舍空调',dorm.dormAirConditioning],['教室空调',dorm.classroomAirConditioning],['独立卫浴',dorm.privateBathroom],['热水时间',dorm.hotWaterTime||dorm.hotWater],['洗衣机',dorm.washingMachine],['通宵自习室',dorm.studyRoomOvernight||dorm.overnightStudyRoom]
  ])}${parentKV('网络与用电',[
    ['功率限制',net.powerLimit],['夜间断电',net.nightPowerOff],['夜间断网',net.nightNetworkOff],['校园网速度',net.campusNetworkSpeed||net.speed],['校园网价格',net.campusNetworkPrice||net.price]
  ])}${parentKV('日常管理',[
    ['新生带电脑',daily.freshmanCanBringComputer||daily.freshmanComputer],['查寝',daily.dormCheck],['门禁时间',daily.curfewTime||daily.curfew],['早晚自习',daily.morningEveningStudy||daily.studyRequirement],['晨跑',daily.morningRun],['跑步打卡',daily.runningCheckIn]
  ])}${parentKV('交通与生活',[
    ['地铁',life.metro],['到市中心',life.distanceToDowntown||life.downtownDistance],['交通便利度',life.transportConvenience],['外卖',life.takeout],['食堂价格',life.canteenPrice],['超市价格',life.supermarketPrice],['快递',life.parcelService||life.parcel],['共享单车',life.sharedBike]
  ])}${parentKV('综合评价',[
    ['适合学生',evalInfo.suitableFor]
  ])}${notes?`<section class="info-section parent-info-section"><h4>注意事项</h4>${notes}</section>`:''}`;
}
function findSchoolByKey(key){return DB.find(s=>keySchool(s)===key)||state.filtered.find(s=>keySchool(s)===key)||null;}
function representativeDetailForSchool(s){
  for(const g of (s?.groups||[])){
    for(const m of (g.majors||[])){
      const d=DETAILS[m.key];
      if(d)return d;
    }
  }
  return {};
}
function schoolInfoPairs(s,d={}){const priority=admissionPriorityInfo(s); return [
  ['院校名称',d.school||s?.name],['录取规则风险',priority?`${priority.label}｜${priority.rules[0]||''}`:''],['所在省份',d.province||s?.province],['所在城市',d.city||s?.city],['城市层级',d.cityLevelTag],['院校代码',d.schoolCode],['院校标签',d.schoolTags||d.firstClass],['院校层次',d.schoolLevel||s?.level],['隶属单位',d.administration],['院校类型',d.schoolType],['公私性质',d.publicPrivate],['本科/专科',d.bachelorSpecialty],['保研率',d.baoyanRate],['学校软科排名',d.schoolRank],['转专业政策',d.transferPolicy],['硕士点数量',d.schoolMasterCount],['硕士点',d.masterPrograms],['博士点数量',d.schoolDoctorCount],['博士点',d.doctorPrograms],['录取规则',d.admissionRule],['招生章程',d.recruitChapter]
];}
function groupInfoPairs(d={}){return [
  ['专业组',d.group],['院校专业组代码',d.groupCode||d.schoolGroupCode],['专业组显示代码',d.displayCode||d.rawGroupCode],['科类',d.subject],['批次',d.batch],['计划类别',d.planCategory],['再选要求',d.subjectRequirement],['26专业组计划',d.groupPlan26],['组内专业数',d.groupMajorCount],['专业组干净度',d.groupCleanliness],['专业组25最低分',d.groupScore25],['专业组25最低位次',d.groupRank25],['专业组原始专业明细',d.rawGroupMajors]
];}
function majorBasePairs(d={}){return [
  ['专业代码',d.code],['专业全称',d.majorFullName||d.name],['本科专业名称',d.undergraduateName],['专业备注',d.majorRemark],['专业层次',d.majorLevel],['专业类',d.majorClass],['学科门类',d.discipline],['学科专业',d.subjectMajor],['选科要求',d.subjectRequirement],['学制',d.duration||d.degreeYears],['学费',d.tuition],['是否新增',d.isNew],['专业水平标签',d.majorLevelTags],['软科评级',d.softRating],['软科专业排名',d.softRank||d.majorRank],['学科评估',d.disciplineEvaluation||d.disciplineEval4||d.disciplineEval5],['专业硕士点',d.majorMasterPrograms],['专业博士点',d.majorDoctorPrograms],['相似度/来源说明',d.similarity||d.sourceRule]
];}
function admissionInfoPairs(d={}){return [
  ['2026计划',d.plan26],['26预估位次',d.predictedRank26],['2025计划',d.plan25],['2025录取人数',d.admit25],['2025最高分',d.max25],['2025最高位次',d.maxRank25],['2025最低分',d.score25],['2025最低位次',d.rank25],['2025旧批次',d.oldBatch25],['2024计划',d.plan24],['2024录取人数',d.admit24],['2024最高分',d.max24],['2024最高位次',d.maxRank24],['2024最低分',d.score24],['2024最低位次',d.rank24],['2024旧批次',d.oldBatch24],['2023计划',d.plan23],['2023录取人数',d.admit23],['2023最高分',d.max23],['2023最高位次',d.maxRank23],['2023最低分',d.score23],['2023最低位次',d.rank23],['2023旧批次',d.oldBatch23],['三年平均分',d.avgScore3],['三年平均位次',d.avgRank3],['均值年份数',d.avgYears]
];}
function findMajorContext(majorKey,groupKey){
  const rec=groupKey?getGroupRecord(groupKey):null;
  if(rec){
    const m=(rec.g.majors||[]).find(x=>x.key===majorKey);
    if(m)return {s:rec.s,g:rec.g,m};
  }
  for(const s of DB){
    for(const g of (s.groups||[])){
      const m=(g.majors||[]).find(x=>x.key===majorKey);
      if(m)return {s,g,m};
    }
  }
  return null;
}
function majorRiskDetailPairs(s,g,m){
  const meta=majorRiskMeta(s,g,m);
  const tier=lectureTierMeta(m);
  const quality=groupQuality(s,g);
  return [
    ['专业热度梯队',tier.label],
    ['梯队分类',tier.bucket],
    ['刺客/异类提示',meta.risk?`${meta.label||'风险专业'}｜${meta.tone||''}`:'未标注为刺客专业'],
    ['风险原因',meta.reason],
    ['专业组结构风险',quality?`${quality.label}｜${quality.title}`:''],
  ];
}
function bindSchoolInfoButtons(){
  $$('[data-school-info]').forEach(btn=>btn.addEventListener('click',e=>{
    e.preventDefault(); e.stopPropagation();
    const s=findSchoolByKey(btn.dataset.schoolInfo);
    if(s)showSchoolInfo(s);
  }));
}
function showSchoolInfo(s){
  const d=representativeDetailForSchool(s);
  const subtitle=[s.province,s.city,s.subject,s.batch].filter(Boolean).join('｜');
  $('#modal').innerHTML=`<h3>${esc(s.name)}｜院校基础信息</h3><div class="modal-body"><div class="info-subtitle">${esc(subtitle)}｜本弹层只放学校层面的信息。</div>${infoSectionHTML('院校基础信息',schoolInfoPairs(s,d),'school-info-section')}${parentSchoolInfoHTML(s.name,{city:s.city,address:d.address,level:s.level,schoolLevel:d.schoolLevel,publicPrivate:d.publicPrivate})}<div class="modal-actions"><button onclick="document.getElementById('modalMask').classList.remove('open')">关闭</button></div></div>`;
  openModal();
}
function fallbackMajorDetail(ctx,schoolKey,groupKey){
  if(!ctx)return {};
  const s=ctx.s||{};
  const g=ctx.g||{};
  const m=ctx.m||{};
  return {
    school:s.name, group:g.groupName, groupCode:g.groupCode, displayCode:g.displayCode,
    identityKey:m.identityKey||`${m.groupCode||g.groupCode||''}+${m.code||''}`,
    sourceExcelRow:m.sourceExcelRow, sourceRule:m.sourceRule,
    province:s.province||g.province, city:s.city||g.city, subject:s.subject||g.subject, batch:s.batch||g.batch,
    schoolTags:Array.isArray(g.tags)?g.tags.join('/'):(s.tags||''), schoolLevel:s.level, publicPrivate:s.publicPrivate,
    baoyanRate:s.baoyanRate, schoolRank:s.schoolRank,
    schoolCode:s.schoolCode, schoolGroupCode:g.groupCode, rawGroupCode:g.displayCode,
    name:m.name, code:m.code, majorFullName:m.name, undergraduateName:m.baseName,
    majorRemark:m.remark, majorClass:m.majorClass, discipline:m.discipline,
    subjectRequirement:m.subjectRequirement||g.requirement, duration:m.duration, tuition:m.tuition,
    isNew:m.isNew, predictedRank26:m.predictedRank26,
    plan26:m.plan26, plan25:m.plan25, admit25:m.admit25, max25:m.max25, maxRank25:m.maxRank25, score25:m.score25, rank25:m.rank25,
    plan24:m.plan24, admit24:m.admit24, max24:m.max24, maxRank24:m.maxRank24, score24:m.score24, rank24:m.rank24,
    plan23:m.plan23, admit23:m.admit23, max23:m.max23, maxRank23:m.maxRank23, score23:m.score23, rank23:m.rank23,
    avgScore3:m.avgScore3, avgRank3:m.avgRank3, avgYears:m.avgYears,
    groupPlan26:g.plan26, groupMajorCount:g.groupMajorCount, groupCleanliness:g.groupCleanliness,
    groupScore25:g.score25, groupRank25:g.rank25, rawGroupMajors:g.rawGroupMajors
  };
}
function mergedMajorDetail(key,ctx){
  DETAILS=window.MAJOR_DETAILS||DETAILS||{};
  return Object.assign({}, fallbackMajorDetail(ctx), DETAILS[key]||{});
}
function showDetail(key,schoolKey,groupKey){
  const ctx=findMajorContext(key,groupKey);
  const d=mergedMajorDetail(key,ctx);
  const schoolNote=notes.schools[schoolKey]||'';
  const groupNote=notes.groups[groupKey]||'';
  const majorNote=notes.majors[key]||'';
  const heading=d.name||ctx?.m?.name||'专业信息';
  const riskSection=ctx?infoSectionHTML('专业风险与梯队提示',majorRiskDetailPairs(ctx.s,ctx.g,ctx.m),'major-risk-info-section'):'';
  $('#modal').innerHTML=`<h3>${esc(heading)}</h3><div class="modal-body"><div class="info-subtitle">点击专业名称查看硕博点、学科评估、软科评级、招生录取数据与风险提示。<br>身份键：${esc(d.identityKey||key)}｜数据源行：${esc(d.sourceExcelRow||'')}</div>${riskSection}${infoSectionHTML('院校基础信息',schoolInfoPairs(null,d),'school-info-section')}${parentSchoolInfoHTML(d.school||ctx?.s?.name,{city:d.city||ctx?.s?.city,address:d.address,level:ctx?.s?.level,schoolLevel:d.schoolLevel,publicPrivate:d.publicPrivate})}${infoSectionHTML('专业组基础信息',groupInfoPairs(d),'group-info-section')}${infoSectionHTML('专业基础信息',majorBasePairs(d),'major-info-section')}${infoSectionHTML('招生录取数据',admissionInfoPairs(d),'admission-info-section')}<div class="badges">${schoolNote?`<span class="note-badge">学校备注</span>`:''}${groupNote?`<span class="note-badge">专业组备注</span>`:''}${majorNote?`<span class="note-badge">专业备注</span>`:''}</div>${noteBlock('学校备注',schoolNote)}${noteBlock('专业组备注',groupNote)}${noteBlock('专业备注',majorNote)}<div class="modal-actions"><button onclick="document.getElementById('modalMask').classList.remove('open')">关闭</button></div></div>`;
  openModal();
}
function noteBlock(title,text){return text?`<section class="metric" style="margin-top:12px"><b style="font-size:14px">${esc(title)}</b><span style="white-space:pre-wrap;color:#33443a">${esc(text)}</span></section>`:'';}
function openModal(){const mask=$('#modalMask'); if(mask)mask.classList.add('open');}
function closeModal(){const mask=$('#modalMask'); if(mask)mask.classList.remove('open');}

function buildGroupIndex(){
  groupIndex=new Map();
  DB.forEach(s=>(s.groups||[]).forEach(g=>groupIndex.set(keyGroup(s,g),{s,g})));
  buildPredictionIndexes();
  volunteerKeys=[...new Set(volunteerKeys)].filter(k=>groupIndex.has(k)).slice(0,VOLUNTEER_LIMIT);
  volunteerKeys.forEach(ensureVolunteerSelection);
  saveVolunteerKeys();
  saveVolunteerMajorKeys();
}
function getGroupRecord(key){return groupIndex.get(key)||null;}
function sortedMajors(g){return [...(g.majors||[])].sort((a,b)=>{const ar=majorRiskMeta(null,g,a).risk,br=majorRiskMeta(null,g,b).risk; if(Boolean(ar)!==Boolean(br))return ar?1:-1; return majorSortByThreeYear(a,b);});}
function defaultMajorKeys(g){return sortedMajors(g).slice(0,MAX_MAJOR_PER_GROUP).map(m=>m.key);}
function uniqueValidMajorKeys(keys,g){
  const valid=new Set((g.majors||[]).map(m=>m.key));
  const out=[];
  (Array.isArray(keys)?keys:[]).forEach(k=>{
    if(valid.has(k)&&!out.includes(k)&&out.length<MAX_MAJOR_PER_GROUP){const m=(g.majors||[]).find(x=>x.key===k); if(m&&!medicalRestrictionForMajor(m).blocked)out.push(k);}
  });
  return out;
}
function ensureVolunteerSelection(key){
  const rec=getGroupRecord(key);
  if(!rec)return;
  volunteerMajorKeys[key]=uniqueValidMajorKeys(volunteerMajorKeys[key],rec.g);
  if(!volunteerMeta[key])volunteerMeta[key]={strategy:'',obey:'是',note:''};
}
function ensureVolunteerGroupForMajor(key){
  if(!groupIndex.has(key))return false;
  const rec=getGroupRecord(key);
  const subjectBlock=rec?subjectRequirementBlockReason(rec.s,rec.g):'';
  if(!volunteerKeys.includes(key)&&subjectBlock){alert(subjectBlock);return false;}
  if(!volunteerKeys.includes(key)){
    if(volunteerKeys.length>=VOLUNTEER_LIMIT){alert(`志愿表最多 ${VOLUNTEER_LIMIT} 个专业组。`);return false;}
    volunteerKeys.push(key);
  }
  ensureVolunteerSelection(key);
  return true;
}
function selectedMajorOrder(key){
  const rec=getGroupRecord(key);
  return rec?uniqueValidMajorKeys(volunteerMajorKeys[key],rec.g):[];
}
function selectedMajorIndex(key,majorKey){return selectedMajorOrder(key).indexOf(majorKey);}
function setMajorSelection(key,majorKey,checked){
  const rec=getGroupRecord(key);
  if(!rec)return false;
  let arr=selectedMajorOrder(key);
  if(checked){
    const subjectBlock=subjectRequirementBlockReason(rec.s,rec.g);
    if(subjectBlock){alert(subjectBlock);return false;}
    const target=(rec.g.majors||[]).find(m=>m.key===majorKey);
    const physical=target?medicalRestrictionForMajor(target):null;
    if(physical&&physical.blocked){alert(`体检受限：该专业不能选择。\n${physical.reason}`);return false;}
    if(!ensureVolunteerGroupForMajor(key))return false;
    arr=selectedMajorOrder(key);
    if(!arr.includes(majorKey)){
      if(arr.length>=MAX_MAJOR_PER_GROUP){alert(`每个专业组最多只能选择 ${MAX_MAJOR_PER_GROUP} 个专业；请先取消一个已选专业，再选择新的专业。`);return false;}
      arr.push(majorKey);
    }
  }else{
    arr=arr.filter(k=>k!==majorKey);
  }
  volunteerMajorKeys[key]=arr;
  ensureVolunteerSelection(key);
  saveVolunteerKeys();
  saveVolunteerMajorKeys();
  saveVolunteerMeta();
  updateVolunteerUI();
  return true;
}
function setMajorSelectionBulk(key,majorKeys){
  const rec=getGroupRecord(key);
  if(!rec)return false;
  const subjectBlock=subjectRequirementBlockReason(rec.s,rec.g);
  if(subjectBlock){alert(subjectBlock);return false;}
  if(!ensureVolunteerGroupForMajor(key))return false;
  volunteerMajorKeys[key]=uniqueValidMajorKeys(majorKeys,rec.g);
  saveVolunteerKeys();
  saveVolunteerMajorKeys();
  saveVolunteerMeta();
  updateVolunteerUI();
  return true;
}
function clearMajorSelectionForGroup(key){
  const rec=getGroupRecord(key);
  if(!rec)return false;
  volunteerMajorKeys[key]=[];
  if(volunteerKeys.includes(key))ensureVolunteerSelection(key);
  saveVolunteerKeys();
  saveVolunteerMajorKeys();
  saveVolunteerMeta();
  updateVolunteerUI();
  return true;
}
function moveMajorSelection(key,majorKey,delta){
  const arr=selectedMajorOrder(key);
  const i=arr.indexOf(majorKey);
  const j=i+delta;
  if(i<0||j<0||j>=arr.length)return false;
  [arr[i],arr[j]]=[arr[j],arr[i]];
  volunteerMajorKeys[key]=arr;
  saveVolunteerMajorKeys();
  return true;
}
function updateVolunteerUI(){
  const count=volunteerKeys.length;
  const btn=$('#volunteerPanelBtn');
  if(btn)btn.textContent=`志愿表 ${count}/${VOLUNTEER_LIMIT}`;
  const countEl=$('#volunteerPanelCount');
  if(countEl)countEl.textContent=`已选 ${count} / ${VOLUNTEER_LIMIT} 个专业组`;
  $$('[data-volunteer-key]').forEach(btn=>{
    const selected=volunteerKeys.includes(btn.dataset.volunteerKey);
    const rec=getGroupRecord(btn.dataset.volunteerKey);
    const med=rec?groupMedicalRestrictionSummary(rec.g):null;
    const allMedicalBlocked=Boolean(med&&med.all);
    const subjectBlock=rec?subjectRequirementBlockReason(rec.s,rec.g):'';
    const disabled=!selected&&(volunteerKeys.length>=VOLUNTEER_LIMIT||allMedicalBlocked||Boolean(subjectBlock));
    btn.textContent=selected?'已加入志愿表':subjectBlock?'选科不符':allMedicalBlocked?'体检全限报':disabled?'志愿表已满':'加入志愿表';
    btn.title=selected?'再次点击：从志愿表移出该专业组，并清空本组已选专业':subjectBlock?subjectBlock:allMedicalBlocked?'当前体检代码下该专业组全部专业受限，不建议加入':'点击：加入志愿表';
    btn.classList.toggle('selected',selected);
    btn.disabled=disabled;
  });
}
function addVolunteerKey(key){
  if(!groupIndex.has(key))return;
  const rec=groupIndex.get(key);
  const med=rec?groupMedicalRestrictionSummary(rec.g):null;
  const subjectBlock=rec?subjectRequirementBlockReason(rec.s,rec.g):'';
  if(!volunteerKeys.includes(key)&&subjectBlock){alert(subjectBlock);return;}
  if(!volunteerKeys.includes(key)&&med&&med.all){alert('当前体检代码下，该专业组全部专业受限，不能加入志愿表。');return;}
  if(!volunteerKeys.includes(key)){
    if(volunteerKeys.length>=VOLUNTEER_LIMIT){alert(`志愿表最多 ${VOLUNTEER_LIMIT} 个专业组。`);return;}
    volunteerKeys.push(key);
  }
  ensureVolunteerSelection(key);
  saveVolunteerKeys();
  saveVolunteerMajorKeys();
  saveVolunteerMeta();
  updateVolunteerUI();
}
function cleanupVolunteerForSubjectRequirements(){
  if(!currentStudent||!volunteerKeys.length)return 0;
  const blocked=volunteerKeys.filter(function(key){
    const rec=getGroupRecord(key);
    return rec&&subjectRequirementBlockReason(rec.s,rec.g);
  });
  if(!blocked.length)return 0;
  blocked.forEach(function(key){delete volunteerMajorKeys[key];delete volunteerMeta[key];});
  volunteerKeys=volunteerKeys.filter(function(key){return !blocked.includes(key);});
  saveCurrentVolunteerDraft();
  return blocked.length;
}
function removeVolunteerKey(key){
  volunteerKeys=volunteerKeys.filter(k=>k!==key);
  delete volunteerMajorKeys[key];
  delete volunteerMeta[key];
  saveVolunteerKeys();
  saveVolunteerMajorKeys();
  saveVolunteerMeta();
  renderVolunteerPanel();
  updateVolunteerUI();
}
function toggleVolunteerKey(key){
  if(volunteerKeys.includes(key)){
    removeVolunteerKey(key);
    render();
    return;
  }
  addVolunteerKey(key);
}
function moveVolunteerKey(key,delta){
  const i=volunteerKeys.indexOf(key);
  const j=i+delta;
  if(i<0||j<0||j>=volunteerKeys.length)return;
  const arr=[...volunteerKeys];
  [arr[i],arr[j]]=[arr[j],arr[i]];
  volunteerKeys=arr;
  saveVolunteerKeys();
  renderVolunteerPanel();
  updateVolunteerUI();
}
function moveVolunteerKeyToPosition(key,rawPosition){
  const match=String(rawPosition||'').match(/\d+/);
  if(!match){alert('请输入目标序号，例如 10 或 第10。');return false;}
  const pos=Number(match[0]);
  if(!Number.isFinite(pos)||pos<1||pos>volunteerKeys.length){alert(`请输入 1-${volunteerKeys.length} 之间的序号。`);return false;}
  const i=volunteerKeys.indexOf(key);
  if(i<0)return false;
  const arr=[...volunteerKeys];
  const [item]=arr.splice(i,1);
  arr.splice(pos-1,0,item);
  volunteerKeys=arr;
  saveVolunteerKeys();
  renderVolunteerPanel();
  updateVolunteerUI();
  return true;
}
function moveVolunteerKeyByDrop(dragKey,targetKey,afterTarget){
  if(!dragKey||!targetKey||dragKey===targetKey)return false;
  if(!volunteerKeys.includes(dragKey)||!volunteerKeys.includes(targetKey))return false;
  const arr=volunteerKeys.filter(k=>k!==dragKey);
  const targetIndex=arr.indexOf(targetKey);
  if(targetIndex<0)return false;
  const insertIndex=targetIndex+(afterTarget?1:0);
  arr.splice(insertIndex,0,dragKey);
  volunteerKeys=arr;
  saveVolunteerKeys();
  renderVolunteerPanel();
  updateVolunteerUI();
  return true;
}
function bindVolunteerButtons(){
  $$('[data-volunteer-key]').forEach(btn=>{
    btn.onclick=e=>{
      e.stopPropagation();
      toggleVolunteerKey(btn.dataset.volunteerKey);
    };
  });
}
function bindClearMajorGroupButtons(){
  $$('[data-clear-major-group]').forEach(btn=>btn.addEventListener('click',e=>{
    e.preventDefault();
    e.stopPropagation();
    const key=btn.dataset.clearMajorGroup;
    const count=selectedMajorOrder(key).length;
    if(!count)return;
    if(!confirm(`确认清空本专业组已选的 ${count} 个专业？\n不会删除专业组，只会把专业志愿清空。`))return;
    clearMajorSelectionForGroup(key);
    render();
    if($('#volunteerPanel')?.classList.contains('open'))renderVolunteerPanel();
  }));
}
function bindMainMajorChecks(){
  $$('[data-main-major-check]').forEach(cb=>{
    cb.addEventListener('click',e=>e.stopPropagation());
    cb.addEventListener('change',()=>{
      const ok=setMajorSelection(cb.dataset.mainMajorCheck,cb.value,cb.checked);
      if(!ok)cb.checked=!cb.checked;
      render();
      renderVolunteerPanel();
    });
  });
}
function fillVolunteerFromCurrentFilters(){
  for(const s of state.filtered){
    for(const g of s.visibleGroups){
      if(volunteerKeys.length>=VOLUNTEER_LIMIT)break;
      const key=keyGroup(s,g);
      const med=groupMedicalRestrictionSummary(g);
      const subjectBlock=subjectRequirementBlockReason(s,g);
      if(!volunteerKeys.includes(key)&&!(med&&med.all)&&!subjectBlock)addVolunteerKey(key);
    }
    if(volunteerKeys.length>=VOLUNTEER_LIMIT)break;
  }
  renderVolunteerPanel();
  updateVolunteerUI();
}
function clearVolunteers(){
  if(!volunteerKeys.length)return;
  if(!confirm('确定清空当前志愿表吗？'))return;
  volunteerKeys=[];
  volunteerMajorKeys={};
  volunteerMeta={};
  saveVolunteerKeys();
  saveVolunteerMajorKeys();
  saveVolunteerMeta();
  renderVolunteerPanel();
  updateVolunteerUI();
}
function selectedMajorsForKey(key){
  const rec=getGroupRecord(key);
  if(!rec)return [];
  const byKey=new Map((rec.g.majors||[]).map(m=>[m.key,m]));
  return selectedMajorOrder(key).map(k=>byKey.get(k)).filter(Boolean);
}
function volunteerSearchText(key,rec){
  if(!rec)return '';
  const {s,g}=rec;
  const meta=volunteerMeta[key]||{};
  const majorText=(g.majors||[]).map(m=>`${m.name||''} ${m.code||''} ${m.majorClass||''} ${m.discipline||''}`).join(' ');
  const selectedText=selectedMajorsForKey(key).map(m=>m.name||'').join(' ');
  return `${s.name||''} ${s.province||''} ${s.subject||''} ${s.batch||''} ${g.groupName||''} ${g.groupCode||''} ${groupDisplayName(s,g)||''} ${g.requirement||''} ${(g.tags||[]).join(' ')} ${meta.strategy||''} ${meta.note||''} ${selectedText} ${majorText}`;
}
function volunteerEntryMatches(key,rec){
  if(!rec)return false;
  const q=normalize(volunteerSearchQuery);
  if(q&&!normalize(volunteerSearchText(key,rec)).includes(q))return false;
  const mode=volunteerFilterMode;
  if(!mode)return true;
  const meta=volunteerMeta[key]||{};
  const selectedCount=selectedMajorOrder(key).length;
  if(['冲','稳','保','垫'].includes(mode))return meta.strategy===mode;
  if(mode==='pending')return !meta.strategy;
  if(mode==='emptyMajor')return selectedCount===0;
  if(mode==='notFullMajor')return selectedCount<MAX_MAJOR_PER_GROUP;
  if(mode==='fullMajor')return selectedCount>=MAX_MAJOR_PER_GROUP;
  return true;
}
function volunteerVisibleEntries(){
  return volunteerKeys.map((key,index)=>({key,index,rec:getGroupRecord(key)})).filter(x=>volunteerEntryMatches(x.key,x.rec));
}
function captureVolunteerExpandedState(){
  const list=$('#volunteerList');
  if(!list)return;
  $$('[data-volunteer-item]').forEach(row=>{
    const key=row.dataset.volunteerItem;
    const drawer=row.querySelector('.volunteer-edit-drawer');
    if(!key||!drawer)return;
    if(drawer.open)volunteerExpandedKeys.add(key);
    else if(!volunteerAllExpanded)volunteerExpandedKeys.delete(key);
  });
}
function keepVolunteerDrawerOpen(key){
  if(key)volunteerExpandedKeys.add(key);
}
function renderVolunteerPanel(options={}){
  const list=$('#volunteerList');
  if(!list)return;
  if(!options.skipCapture)captureVolunteerExpandedState();
  cleanupVolunteerForMedicalRestrictions();
  cleanupVolunteerForSubjectRequirements();
  const visible=volunteerVisibleEntries();
  renderMedicalVolunteerNotice();
  const countEl=$('#volunteerPanelCount');
  if(countEl)countEl.textContent=`已选 ${volunteerKeys.length} / ${VOLUNTEER_LIMIT} 个专业组｜当前显示 ${visible.length} 个`;
  const expandBtn=$('#expandVolunteerBtn');
  if(expandBtn)expandBtn.textContent=volunteerAllExpanded?'一键收回':'一键展开';
  if(!volunteerKeys.length){
    list.innerHTML='<div class="change-empty">还没有加入专业组。先按院校、地区、专业大类、分数段筛选，再点“当前筛选补满”，或在专业组卡片上点“加入志愿表”。</div>';
    updateVolunteerUI();
    return;
  }
  if(!visible.length){
    list.innerHTML='<div class="change-empty">当前志愿表中没有符合筛选条件的专业组。可以清除筛选后再查看完整志愿表。</div>';
    updateVolunteerUI();
    return;
  }
  list.innerHTML=visible.map(({key,index})=>volunteerRowHTML(key,index)).join('');
  bindVolunteerPanelControls();
  updateVolunteerUI();
}
function volunteerRowHTML(key,index){
  const rec=getGroupRecord(key);
  if(!rec)return '';
  const {s,g}=rec;
  ensureVolunteerSelection(key);
  const meta=volunteerMeta[key]||{};
  const majors=sortedMajors(g);
  const selectedOrder=selectedMajorOrder(key);
  const selectedMajors=selectedMajorsForKey(key);
  const planDiff=(g.plan26||0)-(g.plan25||0);
  const detailsOpen=(volunteerAllExpanded||volunteerExpandedKeys.has(key))?' open':'';
  const groupAlias=groupDisplayName(s,g)||'未命名';
  const poolFilter=volunteerMajorPoolFilter[key]||'all';
  const subjectBlock=subjectRequirementBlockReason(s,g);
  const selectedList=selectedMajors.length?`<ol class="volunteer-major-strip">${selectedMajors.map((m,i)=>`<li class="volunteer-major-strip-item"><span class="major-order-badge">${i+1}</span><div class="volunteer-major-name"><b><span class="major-name-text">${esc(m.name)}</span>${majorRiskLabelHTML(majorRiskMeta(s,g,m))}</b><small>${esc(m.majorClass||'其他')}｜${fmt(m.plan26)}人｜${fmtNum(m.score25)}分</small></div><div class="volunteer-major-mini-actions"><button title="专业上移" data-major-move="${esc(key)}" data-major-key="${esc(m.key)}" data-delta="-1" ${i===0?'disabled':''}>↑</button><button title="专业下移" data-major-move="${esc(key)}" data-major-key="${esc(m.key)}" data-delta="1" ${i===selectedMajors.length-1?'disabled':''}>↓</button><button title="取消该专业" data-major-unselect="${esc(key)}" data-major-key="${esc(m.key)}">×</button></div></li>`).join('')}</ol>`:`<div class="volunteer-selected-empty-compact">尚未选择具体专业。展开专业池后勾选，系统会按勾选顺序生成第 1—6 专业。</div>`;
  const majorPicker=`<details class="major-picker volunteer-edit-drawer"${detailsOpen}><summary>专业池 ${majors.length} 个｜已选 ${selectedOrder.length} / ${MAX_MAJOR_PER_GROUP}</summary><div class="major-picker-actions compact"><select data-major-pool-filter="${esc(key)}"><option value="all" ${poolFilter==='all'?'selected':''}>全部专业</option><option value="selected" ${poolFilter==='selected'?'selected':''}>只看已选</option><option value="unselected" ${poolFilter==='unselected'?'selected':''}>只看未选</option></select><button data-major-preset="${esc(key)}" data-preset="none">清空专业</button></div><div class="major-picker-grid volunteer-major-grid compact-grid">${majors.map(m=>{const order=selectedOrder.indexOf(m.key);const isSelected=order>=0;const hidden=(poolFilter==='selected'&&!isSelected)||(poolFilter==='unselected'&&isSelected);const riskMeta=majorRiskMeta(s,g,m);const physical=medicalRestrictionForMajor(m);const blocked=physical.blocked||Boolean(subjectBlock);const blockTitle=subjectBlock||physical.reason;return `<label class="major-check ${riskMeta.risk?'risk':''} ${riskMeta.tone?`risk-tone-${riskMeta.tone}`:''} ${physical.blocked?'physical-blocked':''} ${subjectBlock?'subject-blocked':''} ${isSelected?'selected':'unselected'}" title="${esc(blocked?blockTitle:(riskMeta.risk?riskMeta.reason:''))}" data-major-pool-state="${isSelected?'selected':'unselected'}" ${hidden?'style="display:none"':''}><input type="checkbox" data-major-check="${esc(key)}" value="${esc(m.key)}" ${isSelected?'checked':''} ${blocked?'disabled':''}>${isSelected?`<span class="major-order-badge">${order+1}</span>`:'<span class="major-order-placeholder"></span>'}<b><span class="major-name-text">${esc(m.name)}</span></b>${medicalRestrictionLabelHTML(physical)}${subjectBlock?'<span class="risk-label">选科不符</span>':''}${majorRiskLabelHTML(riskMeta)}<small>${esc(m.majorClass||'其他')}｜${fmt(m.plan26)}人｜${fmtNum(m.score25)}分｜位次 ${fmtNum(m.rank25)}</small></label>`;}).join('')}</div></details>`;
  return `<article class="volunteer-item volunteer-table-row" data-volunteer-item="${esc(key)}">
    <div class="volunteer-order-col"><input class="volunteer-position-input" data-volunteer-position="${esc(key)}" value="${index+1}" title="输入目标序号，例如 10 或 第10" inputmode="numeric" aria-label="志愿序号"><span class="volunteer-drag-handle" data-volunteer-drag-handle="${esc(key)}" draggable="true" title="按住拖动调整专业组顺序">↕</span></div>
    <div class="volunteer-group-col"><div class="volunteer-group-title"><b>${esc(groupShortTitle(s,g))}</b></div><p>再选 ${esc(g.requirement||'—')}</p><p class="volunteer-group-alias">${esc(groupAlias)}</p></div>
    <div class="volunteer-major-col"><div class="volunteer-selected-summary"><div class="volunteer-col-caption">已选专业 <span>${selectedOrder.length}/${MAX_MAJOR_PER_GROUP}</span></div>${selectedList}</div>${majorPicker}</div>
    <div class="volunteer-data-col"><div class="volunteer-data-line emphasis">${groupScoreLineHTML(s,g)}</div><div class="volunteer-data-line">26计划 ${fmt(g.plan26)}｜较25 ${formatSigned(planDiff)}</div><div class="volunteer-mini-controls single"><label>定位<select data-volunteer-meta="${esc(key)}" data-field="strategy"><option value="">待定</option>${['冲','稳','保','垫'].map(v=>`<option value="${v}" ${meta.strategy===v?'selected':''}>${v}</option>`).join('')}</select></label></div><div class="volunteer-obey-fixed">默认服从专业组内调剂</div><input class="volunteer-note-compact" data-volunteer-meta="${esc(key)}" data-field="note" value="${esc(meta.note||'')}" placeholder="备注"></div>
    <div class="volunteer-actions volunteer-action-col"><button class="icon-btn" title="上移" aria-label="上移" data-volunteer-move="${esc(key)}" data-delta="-1" ${index===0?'disabled':''}>↑</button><button class="icon-btn" title="下移" aria-label="下移" data-volunteer-move="${esc(key)}" data-delta="1" ${index===volunteerKeys.length-1?'disabled':''}>↓</button><button class="icon-btn danger" title="删除" aria-label="删除" data-volunteer-remove="${esc(key)}">×</button></div>
  </article>`;
}
function bindVolunteerPanelControls(){
  $$('.volunteer-edit-drawer').forEach(drawer=>drawer.addEventListener('toggle',()=>{
    const row=drawer.closest('[data-volunteer-item]');
    const key=row?.dataset.volunteerItem;
    if(!key)return;
    if(drawer.open)volunteerExpandedKeys.add(key);
    else if(!volunteerAllExpanded)volunteerExpandedKeys.delete(key);
  }));
  $$('[data-volunteer-remove]').forEach(btn=>btn.addEventListener('click',()=>removeVolunteerKey(btn.dataset.volunteerRemove)));
  $$('[data-volunteer-move]').forEach(btn=>btn.addEventListener('click',()=>moveVolunteerKey(btn.dataset.volunteerMove,Number(btn.dataset.delta)||0)));
  $$('[data-volunteer-position]').forEach(input=>{
    input.addEventListener('focus',()=>input.select());
    input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();input.blur();}});
    input.addEventListener('change',()=>{if(!moveVolunteerKeyToPosition(input.dataset.volunteerPosition,input.value))renderVolunteerPanel();});
  });
  bindVolunteerDragControls();
  $$('[data-volunteer-meta]').forEach(el=>el.addEventListener('input',()=>{const key=el.dataset.volunteerMeta; volunteerMeta[key]={...(volunteerMeta[key]||{}),[el.dataset.field]:el.value}; saveVolunteerMeta();}));
  $$('[data-major-pool-filter]').forEach(sel=>sel.addEventListener('change',()=>{const key=sel.dataset.majorPoolFilter; volunteerMajorPoolFilter[key]=sel.value||'all'; keepVolunteerDrawerOpen(key); renderVolunteerPanel();}));
  $$('[data-major-check]').forEach(cb=>cb.addEventListener('change',()=>{
    keepVolunteerDrawerOpen(cb.dataset.majorCheck);
    const ok=setMajorSelection(cb.dataset.majorCheck,cb.value,cb.checked);
    if(!ok)cb.checked=!cb.checked;
    renderVolunteerPanel();
    render();
  }));
  $$('[data-major-preset]').forEach(btn=>btn.addEventListener('click',e=>{
    e.preventDefault();
    const key=btn.dataset.majorPreset;
    keepVolunteerDrawerOpen(key);
    const rec=getGroupRecord(key);
    if(!rec)return;
    if(btn.dataset.preset==='none')setMajorSelectionBulk(key,[]);
    renderVolunteerPanel();
    render();
  }));
  $$('[data-major-move]').forEach(btn=>btn.addEventListener('click',e=>{
    e.preventDefault();
    keepVolunteerDrawerOpen(btn.dataset.majorMove);
    moveMajorSelection(btn.dataset.majorMove,btn.dataset.majorKey,Number(btn.dataset.delta)||0);
    renderVolunteerPanel();
    render();
  }));
  $$('[data-major-unselect]').forEach(btn=>btn.addEventListener('click',e=>{
    e.preventDefault();
    keepVolunteerDrawerOpen(btn.dataset.majorUnselect);
    setMajorSelection(btn.dataset.majorUnselect,btn.dataset.majorKey,false);
    renderVolunteerPanel();
    render();
  }));
  bindMajorDetailButtons();
}
function clearVolunteerDragMarks(){
  $$('[data-volunteer-item]').forEach(item=>item.classList.remove('dragging','drag-over','drop-after','drop-before'));
}
function bindVolunteerDragControls(){
  $$('[data-volunteer-drag-handle]').forEach(handle=>{
    handle.addEventListener('dragstart',e=>{
      volunteerDragKey=handle.dataset.volunteerDragHandle||'';
      if(e.dataTransfer){
        e.dataTransfer.effectAllowed='move';
        e.dataTransfer.setData('text/plain',volunteerDragKey);
      }
      const item=handle.closest('[data-volunteer-item]');
      if(item)item.classList.add('dragging');
    });
    handle.addEventListener('dragend',()=>{volunteerDragKey='';clearVolunteerDragMarks();});
  });
  $$('[data-volunteer-item]').forEach(item=>{
    item.addEventListener('dragover',e=>{
      const targetKey=item.dataset.volunteerItem;
      if(!volunteerDragKey||!targetKey||volunteerDragKey===targetKey)return;
      e.preventDefault();
      const rect=item.getBoundingClientRect();
      const after=e.clientY>rect.top+rect.height/2;
      item.classList.add('drag-over');
      item.classList.toggle('drop-after',after);
      item.classList.toggle('drop-before',!after);
    });
    item.addEventListener('dragleave',()=>item.classList.remove('drag-over','drop-after','drop-before'));
    item.addEventListener('drop',e=>{
      const targetKey=item.dataset.volunteerItem;
      if(!volunteerDragKey||!targetKey||volunteerDragKey===targetKey)return;
      e.preventDefault();
      const after=item.classList.contains('drop-after');
      const dragKey=volunteerDragKey;
      volunteerDragKey='';
      clearVolunteerDragMarks();
      moveVolunteerKeyByDrop(dragKey,targetKey,after);
    });
  });
}

function xlsCell(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function localDateStamp(d=new Date()){
  const pad=n=>String(n).padStart(2,'0');
  return `${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}`;
}
function excelCell(v,style,opts={}){
  const isNum=typeof v==='number'&&Number.isFinite(v);
  const attrs=[];
  if(style)attrs.push(`ss:StyleID="${style}"`);
  if(opts.index)attrs.push(`ss:Index="${opts.index}"`);
  if(opts.mergeDown)attrs.push(`ss:MergeDown="${opts.mergeDown}"`);
  if(opts.mergeAcross)attrs.push(`ss:MergeAcross="${opts.mergeAcross}"`);
  return `<Cell${attrs.length?' '+attrs.join(' '):''}><Data ss:Type="${isNum?'Number':'String'}">${xlsCell(v)}</Data></Cell>`;
}
function excelCellSpec(spec,rowStyle){
  if(spec&&typeof spec==='object'&&!Array.isArray(spec)&&Object.prototype.hasOwnProperty.call(spec,'value')){
    return excelCell(spec.value,spec.style!==undefined?spec.style:rowStyle,spec);
  }
  return excelCell(spec,rowStyle);
}
function excelRow(row,style,opts={}){const attrs=[]; if(opts.height)attrs.push(`ss:Height="${opts.height}"`); return `<Row${attrs.length?' '+attrs.join(' '):''}>${row.map(v=>excelCellSpec(v,style)).join('')}</Row>`;}
function excelColumns(headers,widths=[]){return headers.map((h,i)=>`<Column ss:Index="${i+1}" ss:AutoFitWidth="0" ss:Width="${widths[i]||Math.min(Math.max(String(h).length*10,56),180)}"/>`).join('');}
function excelWorksheet(name,headers,rows,widths){
  return `<Worksheet ss:Name="${xlsCell(name)}"><Table>${excelColumns(headers,widths)}${excelRow(headers,'header')}${rows.map(r=>Array.isArray(r)?excelRow(r):excelRow(r.values,r.style)).join('')}</Table><WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><FreezePanes/><FrozenNoSplit/><SplitHorizontal>1</SplitHorizontal><TopRowBottomPane>1</TopRowBottomPane><ActivePane>2</ActivePane></WorksheetOptions></Worksheet>`;
}
function excelMetric(v){
  return v===null||v===undefined||v===''||Number.isNaN(v)?'':v;
}
function groupShortTitle(s,g){
  const school=String(s?.name||'').trim();
  const group=String(g?.groupName||'').trim();
  if(!group)return school;
  return group.includes(school)?group:`${school} ${group}`;
}
function groupExportInfo(s,g){
  const parts=[];
  const alias=groupDisplayName(s,g)||'';
  if(alias)parts.push(alias);
  if(g.requirement)parts.push(`再选 ${g.requirement}`);
  parts.push(`26计划 ${fmt(g.plan26)}`);
  parts.push(`25分 ${fmtNum(g.score25)}`);
  parts.push(`25位次 ${fmtNum(g.rank25)}`);
  return parts.filter(Boolean).join('｜');
}
function majorsForVolunteerExport(key,g){
  const selectedKeys=selectedMajorOrder(key);
  const selectedSet=new Set(selectedKeys);
  const byKey=new Map((g.majors||[]).map(m=>[m.key,m]));
  const selected=selectedKeys.map(k=>byKey.get(k)).filter(Boolean).map((m,i)=>({m,order:i+1,selected:true}));
  const unselected=sortedMajors(g).filter(m=>!selectedSet.has(m.key)).map(m=>({m,order:'',selected:false}));
  return selected.concat(unselected);
}
function exportVolunteerXlsx(){
  const invalid=[];
  for(let i=0;i<volunteerKeys.length;i++){
    const key=volunteerKeys[i];
    const rec=getGroupRecord(key);
    if(!rec)continue;
    const total=(rec.g.majors||[]).length;
    const required=Math.min(MAX_MAJOR_PER_GROUP,total);
    const selectedCount=selectedMajorOrder(key).length;
    if(required>0&&selectedCount!==required){
      invalid.push(`${i+1}. ${groupShortTitle(rec.s,rec.g)}：已选 ${selectedCount}/${required}`);
    }
  }
  if(invalid.length){
    alert(`导出前需要把每个专业组的专业填满：\n${invalid.slice(0,10).join('\n')}${invalid.length>10?'\n……':''}`);
    return;
  }
  const date=localDateStamp();
  const headers=['志愿序号','院校专业组代码','专业组','专业组信息','专业志愿序号','专业代码','专业名称','2026计划','25计划','25最低分','25最低位次','3年平均分','3年平均位次','定位','服从调剂','备注','选择状态'];
  const widths=[58,82,170,320,72,76,280,76,72,76,92,86,110,70,78,220,92];
  const valueOrBlank=v=>v===null||v===undefined||v===''||Number.isNaN(v)?'':v;
  const rows=[];
  for(let i=0;i<volunteerKeys.length;i++){
    const key=volunteerKeys[i];
    const rec=getGroupRecord(key);
    if(!rec)continue;
    const {s,g}=rec;
    const meta=volunteerMeta[key]||{};
    const majorItems=majorsForVolunteerExport(key,g);
    const items=majorItems.length?majorItems:[{m:null,order:'',selected:false}];
    const span=items.length;
    const merge=span>1?span-1:0;
    const selectedCount=selectedMajorOrder(key).length;
    const totalMajors=(g.majors||[]).length;
    const groupTitle=`${groupShortTitle(s,g)}（${selectedCount}/${totalMajors}）`;
    const groupInfo=groupExportInfo(s,g);
    items.forEach((item,idx)=>{
      const m=item.m;
      const selected=item.selected;
      const status=selected?`已选第${item.order}专业`:'未选';
      const majorSeqStyle=selected?'seq':'unselectedSeq';
      const majorTextStyle=selected?'body':'unselected';
      const majorNumStyle=selected?'num':'unselectedNum';
      const majorCells=[
        {value:m?item.order:'',style:majorSeqStyle,index:5},
        {value:m?(m.code||''):'',style:majorTextStyle},
        {value:m?(m.name||'未选择具体专业'):'未选择具体专业',style:majorTextStyle},
        {value:m?valueOrBlank(m.plan26):'',style:majorNumStyle},
        {value:m?valueOrBlank(m.plan25):'',style:majorNumStyle},
        {value:m?valueOrBlank(m.score25):'',style:majorNumStyle},
        {value:m?valueOrBlank(m.rank25):'',style:majorNumStyle},
        {value:m?valueOrBlank(m.avgScore3):'',style:majorNumStyle},
        {value:m?valueOrBlank(m.avgRank3):'',style:majorNumStyle}
      ];
      const statusCell={value:status,style:selected?'body':'unselectedStatus'};
      if(idx===0){
        rows.push([
          {value:i+1,style:'seq',mergeDown:merge},
          {value:g.groupCode||'',style:'body',mergeDown:merge},
          {value:groupTitle,style:'group',mergeDown:merge},
          {value:groupInfo,style:'groupInfo',mergeDown:merge},
          ...majorCells.map((c,n)=>n===0?{...c,index:undefined}:c),
          {value:meta.strategy||'待定',style:'seq',mergeDown:merge},
          {value:'是',style:'seq',mergeDown:merge},
          {value:meta.note||'',style:'note',mergeDown:merge},
          statusCell
        ]);
      }else{
        rows.push([...majorCells,{...statusCell,index:17}]);
      }
    });
  }
  if(!rows.length){
    alert('志愿表为空，暂无可导出的专业组。');
    return;
  }
  const thinBorder='<Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#C8D6CC"/><Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#C8D6CC"/><Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#C8D6CC"/><Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#C8D6CC"/></Borders>';
  const columns=excelColumns(headers,widths);
  const title=`江苏专科志愿表｜已选 ${volunteerKeys.length} / ${VOLUNTEER_LIMIT} 专业组｜导出日期 ${date}`;
  const topRows=[
    excelRow([{value:title,style:'title',mergeAcross:headers.length-1}],null,{height:32}),
    excelRow(headers.map(h=>({value:h,style:'subheader'})),null,{height:30})
  ].join('');
  const body=rows.map(r=>excelRow(r,'body')).join('');
  const lastRow=rows.length+2;
  const lastCol=headers.length;
  const workbook=`<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<DocumentProperties xmlns="urn:schemas-microsoft-com:office:office"><Created>${new Date().toISOString()}</Created><LastSaved>${new Date().toISOString()}</LastSaved></DocumentProperties>
<Styles>
<Style ss:ID="Default" ss:Name="Normal"><Alignment ss:Vertical="Center" ss:WrapText="1"/><Font ss:FontName="Microsoft YaHei" ss:Size="10"/>${thinBorder}</Style>
<Style ss:ID="title"><Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/><Font ss:FontName="Microsoft YaHei" ss:Size="15" ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#0A7C42" ss:Pattern="Solid"/>${thinBorder}</Style>
<Style ss:ID="subheader"><Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/><Font ss:FontName="Microsoft YaHei" ss:Size="10" ss:Bold="1"/><Interior ss:Color="#E8F1EC" ss:Pattern="Solid"/>${thinBorder}</Style>
<Style ss:ID="group"><Alignment ss:Vertical="Center" ss:WrapText="1"/><Font ss:FontName="Microsoft YaHei" ss:Size="10" ss:Bold="1" ss:Color="#173526"/><Interior ss:Color="#F3FBF6" ss:Pattern="Solid"/>${thinBorder}</Style>
<Style ss:ID="groupInfo"><Alignment ss:Vertical="Center" ss:WrapText="1"/><Font ss:FontName="Microsoft YaHei" ss:Size="10" ss:Color="#173526"/><Interior ss:Color="#F3FBF6" ss:Pattern="Solid"/>${thinBorder}</Style>
<Style ss:ID="body"><Alignment ss:Vertical="Center" ss:WrapText="1"/><Font ss:FontName="Microsoft YaHei" ss:Size="10"/>${thinBorder}</Style>
<Style ss:ID="seq"><Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/><Font ss:FontName="Microsoft YaHei" ss:Size="10" ss:Bold="1"/>${thinBorder}</Style>
<Style ss:ID="num"><Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/><Font ss:FontName="Microsoft YaHei" ss:Size="10"/>${thinBorder}</Style>
<Style ss:ID="note"><Alignment ss:Vertical="Center" ss:WrapText="1"/><Font ss:FontName="Microsoft YaHei" ss:Size="10" ss:Color="#374151"/><Interior ss:Color="#FAFAFA" ss:Pattern="Solid"/>${thinBorder}</Style>
<Style ss:ID="unselected"><Alignment ss:Vertical="Center" ss:WrapText="1"/><Font ss:FontName="Microsoft YaHei" ss:Size="10" ss:Color="#B91C1C"/>${thinBorder}</Style>
<Style ss:ID="unselectedSeq"><Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/><Font ss:FontName="Microsoft YaHei" ss:Size="10" ss:Bold="1" ss:Color="#B91C1C"/>${thinBorder}</Style>
<Style ss:ID="unselectedNum"><Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/><Font ss:FontName="Microsoft YaHei" ss:Size="10" ss:Color="#B91C1C"/>${thinBorder}</Style>
<Style ss:ID="unselectedStatus"><Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/><Font ss:FontName="Microsoft YaHei" ss:Size="10" ss:Bold="1" ss:Color="#B91C1C"/>${thinBorder}</Style>
</Styles>
<Worksheet ss:Name="志愿基础表"><Table>${columns}${topRows}${body}</Table><AutoFilter x:Range="R2C1:R${lastRow}C${lastCol}" xmlns="urn:schemas-microsoft-com:office:excel"/><WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><FreezePanes/><FrozenNoSplit/><SplitHorizontal>2</SplitHorizontal><TopRowBottomPane>2</TopRowBottomPane><ActivePane>2</ActivePane></WorksheetOptions></Worksheet>
</Workbook>`;
  const blob=new Blob(['\ufeff',workbook],{type:'application/vnd.ms-excel;charset=utf-8'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download=`江苏志愿基础表_${date}.xls`;
  document.body.appendChild(a);
  a.click();
  setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},0);
  recordVolunteerExportIfPossible(rows.length);
}

function bindGroupChangeButtons(){
  $$('[data-change-key]').forEach(btn=>{
    btn.onclick=e=>{
      e.stopPropagation();
      openGroupChange(btn.dataset.changeKey,btn.dataset.changeTitle);
    };
  });
}
function openGroupChange(key,title){
  $('#changePanelTitle').textContent=title||key;
  const data=GROUP_CHANGES[key];
  $('#changePanelBody').innerHTML=data?groupChangeHTML(data):`<div class="change-empty">暂无普通批 25-26 变迁数据。<br><span class="muted">当前专科首版暂未接入完整25-26专业组变迁表；不影响行级分数、计划与志愿表。</span></div>`;
  openPanel('changePanel');
}
function metricTile(label,value,sub){
  return `<div class="change-metric"><b>${esc(fmt(value))}</b><span>${esc(label)}${sub?`｜${esc(sub)}`:''}</span></div>`;
}
function changeDetailLine(item){
  const parts=[];
  if(item.plan!==null&&item.plan!==undefined&&item.plan!=='')parts.push(`${item.plan}人`);
  if(item.type)parts.push(item.type);
  if(item.from)parts.push(`来源：${item.from}`);
  if(item.to)parts.push(`去向：${item.to}`);
  if(item.basis)parts.push(`依据：${item.basis}`);
  if(item.note||item.reason)parts.push(item.note||item.reason);
  return `<li><b>${esc(item.name||'未命名专业')}</b>${parts.length?`<br><span>${esc(parts.join('｜'))}</span>`:''}</li>`;
}
function changeDetailBlock(title,items){
  const list=(items||[]).slice(0,80);
  return `<section class="change-section"><h4>${esc(title)} <span class="muted">${(items||[]).length}</span></h4>${list.length?`<ol class="change-list">${list.map(changeDetailLine).join('')}</ol>${(items||[]).length>80?'<p class="muted">仅显示前 80 条。</p>':''}`:'<p class="muted">无</p>'}</section>`;
}
function groupChangeHTML(d){
  const planDiff=diffText(d.plan26,d.plan25);
  const majorDiff=diffText(d.majorCount26,d.majorCount25);
  const adviceClass=d.advice==='重点核对'?'warn':'';
  return `<div class="change-status-row"><span class="change-pill">${esc(d.status||'未标注状态')}</span><span class="change-pill ${adviceClass}">${esc(d.advice||'常规核对')}</span><span class="change-pill">置信度：${esc(fmt(d.confidence))}</span></div>
  <section class="change-section"><h4>数据口径</h4><p class="muted">${esc(d.sourceNote||'变迁层只解释专业组结构变化，不覆盖行级权威表中的分数、计划和专业基础信息。')}</p></section>
  <div class="change-compare"><div class="change-side"><span>2026 当前组</span><b>${esc(d.group26||'—')}</b><p>再选：${esc(fmt(d.require26))}｜专业 ${esc(fmt(d.majorCount26))}｜计划 ${esc(fmt(d.plan26))}</p></div><div class="change-side"><span>2025 对应组</span><b>${esc(d.group25||'—')}</b><p>再选：${esc(fmt(d.require25))}｜专业 ${esc(fmt(d.majorCount25))}｜计划 ${esc(fmt(d.plan25))}</p></div></div>
  <div class="change-metrics">${metricTile('计划变化',planDiff)}${metricTile('专业数变化',majorDiff)}${metricTile('综合相似度',percent(d.similarity))}${metricTile('26/25覆盖率',`${percent(d.cover26)} / ${percent(d.cover25)}`)}${metricTile('新增专业',d.addCount)}${metricTile('减少专业',d.removeCount)}${metricTile('拆入专业',d.inCount)}${metricTile('拆出专业',d.outCount)}</div>
  <section class="change-section"><h4>变化摘要</h4><p class="change-summary-text">${esc(d.summary||'无明显变化')}</p></section>
  ${changeDetailBlock('新增专业',d.details?.add)}
  ${changeDetailBlock('减少专业',d.details?.remove)}
  ${changeDetailBlock('拆入专业',d.details?.in)}
  ${changeDetailBlock('拆出专业',d.details?.out)}`;
}

function stableTerm(scope,key){
  return `js-plan-annotation::${scope}::${key}`;
}
function openAnnotation(payload){
  window.__currentAnnotation=payload;
  const {scope,key,title}=payload;
  const term=stableTerm(scope,key);
  $('#annotationObject').textContent=title;
  $('#annotationDrawer').classList.add('open');
  loadGiscus(term,title);
}
function closeAnnotationDrawer(){
  $('#annotationDrawer').classList.remove('open');
}
function giscusConfigured(){
  return !!(GISCUS_CONFIG.repo&&GISCUS_CONFIG.repoId&&GISCUS_CONFIG.category&&GISCUS_CONFIG.categoryId);
}
function loadGiscus(term,title){
  const mount=$('#giscusMount');
  mount.innerHTML='';
  if(!giscusConfigured()){
    mount.innerHTML=`<div class="giscus-config-tip"><h4>giscus 尚未配置</h4><p>请先到 giscus.app 为你的 GitHub 仓库生成配置，然后把 <code>repo</code>、<code>repoId</code>、<code>category</code>、<code>categoryId</code> 填入 app.js 顶部的 <code>GISCUS_CONFIG</code>。</p><p><b>当前批注绑定 term：</b></p><code>${esc(term)}</code><p class="muted">配置完成后，同一个学校、专业组或专业会稳定绑定到同一个 GitHub Discussion。</p></div>`;
    return;
  }
  const script=document.createElement('script');
  script.src='https://giscus.app/client.js';
  script.setAttribute('data-repo',GISCUS_CONFIG.repo);
  script.setAttribute('data-repo-id',GISCUS_CONFIG.repoId);
  script.setAttribute('data-category',GISCUS_CONFIG.category);
  script.setAttribute('data-category-id',GISCUS_CONFIG.categoryId);
  script.setAttribute('data-mapping','specific');
  script.setAttribute('data-term',term);
  script.setAttribute('data-strict','1');
  script.setAttribute('data-reactions-enabled','1');
  script.setAttribute('data-emit-metadata','0');
  script.setAttribute('data-input-position','top');
  script.setAttribute('data-theme',GISCUS_CONFIG.theme||'light');
  script.setAttribute('data-lang',GISCUS_CONFIG.lang||'zh-CN');
  script.setAttribute('crossorigin','anonymous');
  script.async=true;
  mount.appendChild(script);
}
function bindAnnotationButtons(){
  $$('[data-annotation-scope]').forEach(btn=>{
    btn.onclick=e=>{
      e.stopPropagation();
      openAnnotation({scope:btn.dataset.annotationScope,key:btn.dataset.annotationKey,title:btn.dataset.annotationTitle});
    };
  });
}

async function fetchNotes(){
  if(!SUPABASE_URL||!SUPABASE_ANON_KEY){return;}
  try{const res=await fetch(`${SUPABASE_URL}/rest/v1/notes?select=scope,target_key,note`,{headers:{apikey:SUPABASE_ANON_KEY,Authorization:`Bearer ${auth.accessToken||SUPABASE_ANON_KEY}`}}); if(!res.ok)throw new Error(await res.text()); const rows=await res.json(); notes={schools:{},groups:{},majors:{}}; rows.forEach(r=>{if(notes[r.scope])notes[r.scope][r.target_key]=r.note;}); applyFilters();}
  catch(err){console.warn('读取备注失败',err);}
}
function showLoginModal(){
  $('#modal').innerHTML=`<h3>登录 Supabase 数据库</h3><div class="modal-body"><p class="muted">需要先在 app.js 中填写 Supabase URL 与 anon key，并在 Supabase 中配置 notes / admin_users 表与 RLS。</p><div class="score-row"><label>邮箱</label><input id="loginEmail" type="email" value="${esc(ADMIN_EMAIL)}" style="grid-column:span 2;height:38px;border:1px solid var(--line);border-radius:10px;padding:0 10px"></div><div class="score-row"><label>密码</label><input id="loginPwd" type="password" style="grid-column:span 2;height:38px;border:1px solid var(--line);border-radius:10px;padding:0 10px"></div><div class="modal-actions"><button onclick="document.getElementById('modalMask').classList.remove('open')">取消</button><button id="doLogin" class="save">登录</button></div></div>`;
  openModal(); $('#doLogin').addEventListener('click',loginSupabase);
}
async function loginSupabase(){
  if(!SUPABASE_URL||!SUPABASE_ANON_KEY){alert('请先在 app.js 中填写 Supabase 配置。');return;}
  const email=$('#loginEmail').value, password=$('#loginPwd').value;
  try{const res=await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`,{method:'POST',headers:{apikey:SUPABASE_ANON_KEY,'Content-Type':'application/json'},body:JSON.stringify({email,password})}); if(!res.ok)throw new Error(await res.text()); const data=await res.json(); auth.accessToken=data.access_token; auth.user=data.user; closeModal(); alert('登录成功'); fetchNotes();}
  catch(err){alert('登录失败：'+err.message);}
}
function showNoteEditor(scope,key,title){
  if(document.body.dataset.admin!=='1')return;
  const old=notes[scope]?.[key]||'';
  $('#modal').innerHTML=`<h3>${esc(title)}</h3><div class="modal-body edit-area"><textarea id="noteText" placeholder="输入文字备注；不支持图片备注。">${esc(old)}</textarea><div class="modal-actions"><button onclick="document.getElementById('modalMask').classList.remove('open')">关闭</button><button class="delete" id="deleteNote">删除</button><button class="save" id="saveNote">保存</button></div><div class="context-hint">scope：${esc(scope)}｜target_key：${esc(key)}</div></div>`;
  openModal();
  $('#saveNote').addEventListener('click',()=>saveNote(scope,key,$('#noteText').value));
  $('#deleteNote').addEventListener('click',()=>deleteNote(scope,key));
}
async function saveNote(scope,key,text){
  if(!text.trim()){await deleteNote(scope,key);return;}
  notes[scope][key]=text.trim();
  closeModal(); applyFilters();
  if(SUPABASE_URL&&SUPABASE_ANON_KEY&&auth.accessToken){try{await fetch(`${SUPABASE_URL}/rest/v1/notes?on_conflict=scope,target_key`,{method:'POST',headers:{apikey:SUPABASE_ANON_KEY,Authorization:`Bearer ${auth.accessToken}`,'Content-Type':'application/json',Prefer:'resolution=merge-duplicates'},body:JSON.stringify({scope,target_key:key,note:text.trim(),created_by:auth.user?.id})});}catch(err){console.warn('保存备注失败',err);}}
}
async function deleteNote(scope,key){
  delete notes[scope][key];
  closeModal(); applyFilters();
  if(SUPABASE_URL&&SUPABASE_ANON_KEY&&auth.accessToken){try{await fetch(`${SUPABASE_URL}/rest/v1/notes?scope=eq.${encodeURIComponent(scope)}&target_key=eq.${encodeURIComponent(key)}`,{method:'DELETE',headers:{apikey:SUPABASE_ANON_KEY,Authorization:`Bearer ${auth.accessToken}`}});}catch(err){console.warn('删除备注失败',err);}}
}

function ensureAccountStyles(){
  const id='js-plan-account-styles';
  if(document.getElementById(id))return;
  const style=document.createElement('style');
  style.id=id;
  style.textContent=`
    body.auth-locked{overflow:hidden;background:#f6f8f7}
    body.auth-locked .topbar,body.auth-locked .layout,body.auth-locked .footer,body.auth-locked .admin-dock,body.auth-locked .admin-menu,body.auth-locked .back-top,body.auth-locked .panel,body.auth-locked .annotation-drawer,body.auth-locked .note-panel{display:none!important}
    .auth-cover{position:fixed;inset:0;z-index:1000;background:#f6f8f7;display:block;padding:0}
    .auth-cover[hidden]{display:none}
    .auth-cover-frame{width:100%;height:100%;border:0;display:block;background:#f6f8f7}
    body.auth-locked .modal-mask{z-index:1200}
    .student-toggle,.account-toggle,.logout-toggle{display:none}
    .student-toggle.logged-in,.account-toggle.logged-in{display:inline-flex}
    :not(.auth-locked) .student-toggle,:not(.auth-locked) .account-toggle{display:inline-flex}
    .logout-toggle:not([hidden]){display:inline-flex}
    .account-tabs{display:flex;gap:4px;border:1px solid #e5ebe7;border-radius:12px;padding:4px;background:#f6f8f7;margin-bottom:16px}
    .account-tabs button{flex:1;height:36px;border:0;border-radius:8px;background:transparent;font-weight:700}
    .account-tabs button.active{background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.06)}
    .account-form{display:grid;gap:12px}
    .account-form label{display:grid;gap:5px;font-size:12px;font-weight:800;color:#526058}
    .account-form input{height:40px;border:1px solid #e5ebe7;border-radius:10px;padding:0 12px;font-size:14px}
    .account-notice{border:1px solid #fed7aa;border-radius:12px;background:#fffcf5;padding:12px;margin-bottom:14px;font-size:13px;line-height:1.6;color:#92400e}
    .account-notice code{font-size:12px;background:#fef3c7;padding:2px 5px;border-radius:4px}
    .student-account-box{border:1px solid #e5ebe7;border-radius:12px;background:#fafcfa;padding:12px;margin-bottom:16px}
    .student-account-box b{display:block;font-size:14px}
    .student-account-box span{display:block;margin-top:4px;font-size:12px;color:#66756d}
    .student-empty{padding:20px;text-align:center;color:#66756d;font-size:14px;border:1px dashed #dce4df;border-radius:16px}
    .student-inline-actions{display:flex;gap:8px;flex-wrap:wrap}
    .student-sync-active{border-color:#8ed2aa!important;background:#f0faf4!important;color:var(--green)!important}

    .student-context-bar{border-top:1px solid rgba(10,124,66,.1);padding:10px 24px 12px;background:linear-gradient(90deg,#f2fbf6,#ffffff);display:grid;gap:5px}
    .student-context-bar[hidden]{display:none!important}
    .student-context-main{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:12px;color:#24352b;font-weight:900}
    .student-context-main b{color:var(--green);font-size:13px}
    .student-context-main span{display:inline-flex;align-items:center;border:1px solid #cbeed9;border-radius:999px;background:#fff;padding:5px 9px;line-height:1}
    .student-context-note{color:var(--muted);font-size:11px;line-height:1.45}
    .medical-picker-row{display:flex;gap:7px;flex-wrap:wrap;padding:8px;border:1px solid var(--line);border-radius:12px;background:#fbfdfc}
    .medical-picker-row label{display:inline-flex;align-items:center;gap:4px;border:1px solid #dbe7df;border-radius:999px;background:#fff;padding:6px 9px;color:#24352b;font-size:12px;font-weight:900}
    .medical-picker-row input{width:auto;height:auto;margin:0}
    .medical-picker-row label:has(input:checked){border-color:#8ed2aa;background:#eaf7ef;color:var(--green)}
    .medical-picker-summary{font-size:12px;color:var(--muted);line-height:1.55}
    .medical-picker-summary b{display:inline-flex;align-items:center;border:1px solid #cbeed9;border-radius:999px;background:#f0faf4;color:var(--green);padding:2px 7px;margin:0 3px;font-size:11px}
    .student-inline-actions button{height:38px;border:1px solid #e5ebe7;border-radius:10px;background:#fff;padding:0 14px;font-weight:700;font-size:13px}
    .student-inline-actions button.save{background:#0a7c42;color:#fff;border-color:#0a7c42}
    .student-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:12px 0}
    .student-form-grid .wide{grid-column:span 2}
    .student-form-grid label{display:grid;gap:5px;font-size:12px;font-weight:800;color:#526058}
    .student-choice-field{display:grid;gap:5px;font-size:12px;font-weight:800;color:#526058}
    .student-form-grid input,.student-form-grid select{height:38px;border:1px solid #e5ebe7;border-radius:10px;padding:0 10px}
    .subject-choice-row{display:flex;gap:8px;flex-wrap:wrap}
    .subject-choice-row label{display:inline-flex;align-items:center;gap:5px;border:1px solid #e5ebe7;border-radius:999px;background:#fff;padding:7px 10px;color:#24352b;font-size:12px;font-weight:900}
    .subject-choice-row input{width:auto;height:auto;margin:0}
    .subject-blocked-row td{background:#fff7ed}
    .major-check.subject-blocked{border-color:#fed7aa;background:#fff7ed;color:#9a3412}
    .student-card{border:1px solid #e5ebe7;border-radius:16px;padding:14px;margin-bottom:10px}
    .student-card.active{border-color:#0a7c42;background:#f5fcf8}
    .student-card-head{display:flex;justify-content:space-between;align-items:flex-start;gap:10px;margin-bottom:10px}
    .student-card h4{margin:0;font-size:15px}
    .student-card p{margin:5px 0 0;color:#66756d;font-size:12px}
    .student-card .badge{border:1px solid #cbeed9;border-radius:999px;background:#eaf7ef;color:#0a7c42;padding:3px 8px;font-size:11px;font-weight:700;white-space:nowrap}
    .student-actions{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px}
    .student-actions button{height:32px;border:1px solid #e5ebe7;border-radius:8px;background:#fff;padding:0 10px;font-size:12px;font-weight:700}
    .student-actions button.save{background:#0a7c42;color:#fff;border-color:#0a7c42}
    .student-form-list{border-top:1px solid #edf1ee;padding-top:10px;margin-top:8px}
    .student-form-list-title{display:flex;justify-content:space-between;color:#66756d;font-size:12px;margin-bottom:8px}
    .student-form-row{display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid #f0f3f1}
    .student-form-row span{font-size:13px}
    .student-form-row small{display:block;margin-top:2px;color:#66756d;font-size:11px}
    .student-form-row button{height:28px;border:1px solid #e5ebe7;border-radius:6px;background:#fff;padding:0 8px;font-size:11px;font-weight:700;color:#0a7c42}
    .student-list{margin-top:12px}
    .student-card:last-child{margin-bottom:0}
    @media(max-width:640px){.student-form-grid{grid-template-columns:1fr}.student-card-head{display:block}}
  `;
  document.head.appendChild(style);
}
function localDateStamp(){const d=new Date(); const Y=d.getFullYear(); const M=String(d.getMonth()+1).padStart(2,'0'); const D=String(d.getDate()).padStart(2,'0'); return Y+'-'+M+'-'+D;}

function supabaseConfigured(){return Boolean(SUPABASE_URL&&SUPABASE_ANON_KEY);}
function requireSupabase(){
  if(supabaseConfigured())return true;
  alert('还没有填写 Supabase 配置：请先在 app.js 里填 SUPABASE_URL 和 SUPABASE_ANON_KEY。');
  return false;
}
function requireLogin(){
  if(auth.accessToken&&auth.user)return true;
  showAccountModal('login');
  return false;
}
function authHeaders(extra={}){
  return {apikey:SUPABASE_ANON_KEY,Authorization:'Bearer '+auth.accessToken,'Content-Type':'application/json',...extra};
}
async function apiFetch(path,options={}){
  if(!supabaseConfigured())throw new Error('Supabase 配置为空');
  if(!auth.accessToken)throw new Error('请先登录');
  const res=await fetch(SUPABASE_URL+'/rest/v1/'+path,{...options,headers:authHeaders(options.headers||{})});
  if(!res.ok)throw new Error(await res.text());
  if(res.status===204)return null;
  const text=await res.text();
  return text?JSON.parse(text):null;
}
function isSubjectChoicesColumnMissing(err){return /subject_choices|schema cache|column/i.test(err?.message||String(err));}
async function writeStudentRecord(path,method,payload){
  try{
    return await apiFetch(path,{method,headers:{Prefer:'return=representation'},body:JSON.stringify(payload)});
  }catch(err){
    if(Object.prototype.hasOwnProperty.call(payload,'subject_choices')&&isSubjectChoicesColumnMissing(err)){
      const fallback={...payload};
      delete fallback.subject_choices;
      return apiFetch(path,{method,headers:{Prefer:'return=representation'},body:JSON.stringify(fallback)});
    }
    throw err;
  }
}
function updateAccountUI(){
  const accountBtn=$('#accountBtn');
  if(accountBtn){
    accountBtn.textContent=auth.user?.email?'账号中心：'+auth.user.email.split('@')[0]:'登录/注册';
    accountBtn.classList.toggle('logged-in',Boolean(auth.user));
  }
  const logoutBtn=$('#logoutHeaderBtn');
  if(logoutBtn)logoutBtn.hidden=!auth.user;
  const studentBtn=$('#studentPanelBtn');
  if(studentBtn){
    studentBtn.textContent=currentStudent?'学生：'+currentStudent.name+'｜'+studentTopSummary(currentStudent):'学生档案';
    studentBtn.title=currentStudent?studentTopSummary(currentStudent):'学生档案';
    studentBtn.classList.toggle('active-student',Boolean(currentStudent));
  }
  renderStudentContextBar();
}
function updateAuthGate(){
  const locked=!(auth.accessToken&&auth.user);
  document.body.classList.toggle('auth-locked',locked);
  const cover=$('#authCover');
  if(cover)cover.hidden=!locked;
}
function splitListInput(v){return String(v||'').split(/[，,、\s/]+/).map(x=>x.trim()).filter(Boolean);}
function subjectTypeValue(v){return v==='history'||v==='历史'?'history':'physics';}
function stageValue(v){return v==='specialty'||v==='专科'?'specialty':'undergraduate';}
function stageLabel(v){return v==='specialty'?'专科':'本科';}
function subjectLabel(v){return v==='history'?'历史':'物理';}

function showAccountModal(mode='login'){
  if(auth.user&&mode==='login'){showAccountCenter();return;}
  const isRegister=mode==='register';
  $('#modal').innerHTML='<h3>'+(isRegister?'注册账号':'登录账号')+'</h3><div class="modal-body">'+
    (supabaseConfigured()?'':'<div class="account-notice">数据库还没有配置。请先创建 Supabase 项目，执行 supabase/schema.sql，然后把 URL 和 anon key 填进 app.js。界面已经接好，配置后即可注册登录。</div>')+
    '<div class="account-tabs"><button id="loginTab" class="'+(isRegister?'':'active')+'" type="button">登录</button><button id="registerTab" class="'+(isRegister?'active':'')+'" type="button">注册</button></div>'+
    '<div class="account-form">'+
    (isRegister?'<label>姓名或昵称<input id="accountName" placeholder="例如：王老师"></label>':'')+
    '<label>邮箱<input id="accountEmail" type="email" value="" placeholder="you@example.com" autocomplete="off" autocapitalize="none" spellcheck="false"></label>'+
    '<label>密码<input id="accountPassword" type="password" placeholder="至少 6 位" autocomplete="new-password"></label>'+
    '</div>'+
    '<div class="modal-actions"><button onclick="document.getElementById(\'modalMask\').classList.remove(\'open\')">取消</button><button id="accountSubmit" class="save">'+(isRegister?'注册':'登录')+'</button></div>'+
    '</div>';
  openModal();
  markAccountFieldsUserEditing();
  clearAnonymousAccountFields();
  $('#loginTab').addEventListener('click',()=>showAccountModal('login'));
  $('#registerTab').addEventListener('click',()=>showAccountModal('register'));
  $('#accountSubmit').addEventListener('click',()=>isRegister?registerSupabase():loginSupabase());
}
function markAccountFieldsUserEditing(){
  ['accountEmail','accountPassword'].forEach(function(id){
    const el=$('#'+id);
    if(!el)return;
    ['keydown','paste'].forEach(function(type){el.addEventListener(type,function(){el.dataset.userEdited='1';},{once:true});});
  });
}
function clearAnonymousAccountFields(){
  if(auth.user)return;
  [0,120,500].forEach(function(delay){setTimeout(function(){
    const email=$('#accountEmail');
    const password=$('#accountPassword');
    if(email&&!email.dataset.userEdited)email.value='';
    if(password&&!password.dataset.userEdited)password.value='';
  },delay);});
}
function showModuleChoiceModal(){
  if(!auth.user)return;
  $('#modal').innerHTML=`<h3>选择工作区</h3><div class="modal-body">
    <div class="account-notice"><b>登录成功。</b><br>你可以进入志愿填报系统，也可以进入升学规划资讯中心。资讯中心支持公开图文、PDF 在线查看和登录上传。</div>
    <div class="module-choice-grid" style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:14px">
      <button id="goPlanModule" class="save" type="button" style="border:1px solid #b7dfc6;border-radius:18px;background:#f0faf4;color:#0a7c42;padding:16px;text-align:left;font-weight:900">志愿填报系统<br><span style="display:block;margin-top:6px;color:#647067;font-size:12px;font-weight:600;line-height:1.5">继续使用本科/专科数据、学生档案、志愿表、选科与体检风控。</span></button>
      <button id="goContentModule" type="button" style="border:1px solid #bfdbfe;border-radius:18px;background:#eff6ff;color:#1d4ed8;padding:16px;text-align:left;font-weight:900">升学规划资讯<br><span style="display:block;margin-top:6px;color:#647067;font-size:12px;font-weight:600;line-height:1.5">查看公开图文资料、在线阅读 PDF，并上传公开资料。</span></button>
    </div>
    <div class="modal-actions"><button onclick="document.getElementById('modalMask').classList.remove('open')" type="button">暂不选择</button></div>
  </div>`;
  openModal();
  $('#goPlanModule')?.addEventListener('click',()=>closeModal());
  $('#goContentModule')?.addEventListener('click',()=>{window.location.href='../content/index.html';});
}
function showAccountCenter(){
  $('#modal').innerHTML='<h3>账号中心</h3><div class="modal-body">'+
    '<div class="student-account-box"><b>'+esc(auth.user?.email||'已登录')+'</b><span class="muted">'+(currentStudent?'当前学生：'+esc(currentStudent.name):'尚未选择学生')+'</span></div>'+
    '<div class="account-notice">退出登录前，请先确认当前志愿表已经"保存到学生"。系统会保留这个账号自己的本地草稿，但不会自动把未保存内容上传到数据库。</div>'+
    '<div class="modal-actions"><button id="accountOpenStudents" type="button">学生档案</button><button id="accountLogout" class="delete" type="button">退出登录</button><button onclick="document.getElementById(\'modalMask\').classList.remove(\'open\')" type="button">关闭</button></div>'+
    '</div>';
  openModal();
  $('#accountOpenStudents')?.addEventListener('click',function(){closeModal();openStudentDirectory();});
  $('#accountLogout')?.addEventListener('click',function(){logoutSupabase();});
}
function showLoginModal(){showAccountModal('login');}
async function registerSupabase(){
  if(!requireSupabase())return;
  const email=$('#accountEmail').value.trim();
  const password=$('#accountPassword').value;
  const displayName=$('#accountName')?.value.trim()||'';
  if(!email||!password){alert('请输入邮箱和密码。');return;}
  try{
    const res=await fetch(SUPABASE_URL+'/auth/v1/signup',{method:'POST',headers:{apikey:SUPABASE_ANON_KEY,'Content-Type':'application/json'},body:JSON.stringify({email,password,data:{display_name:displayName}})});
    if(!res.ok)throw new Error(await res.text());
    const data=await res.json();
    if(data.access_token){
      auth={accessToken:data.access_token,refreshToken:data.refresh_token||'',user:data.user};
      saveAuth();
      await ensureUserProfile(displayName);
      loadCurrentStudent();
      loadCurrentVolunteerDraft();
      closeModal();
      updateAccountUI();
      updateAuthGate();
      updateVolunteerUI();
      render();
      renderStudentPanel();
      showModuleChoiceModal();
      alert('注册并登录成功。');
    }else{
      alert('注册成功。若 Supabase 开启了邮箱确认，请先到邮箱完成确认后再登录。');
      showAccountModal('login');
    }
  }catch(err){alert('注册失败：'+err.message);}
}
async function loginSupabase(){
  if(!requireSupabase())return;
  const email=($('#accountEmail')||$('#loginEmail')).value.trim();
  const password=($('#accountPassword')||$('#loginPwd')).value;
  try{await loginSupabaseWithCredentials(email,password,{notify:true});}catch(err){}
}
async function loginSupabaseWithCredentials(email,password,options={}){
  try{
    if(!email||!password)throw new Error('请输入邮箱和密码。');
    const res=await fetch(SUPABASE_URL+'/auth/v1/token?grant_type=password',{method:'POST',headers:{apikey:SUPABASE_ANON_KEY,'Content-Type':'application/json'},body:JSON.stringify({email,password})});
    if(!res.ok)throw new Error(await res.text());
    const data=await res.json();
    auth={accessToken:data.access_token,refreshToken:data.refresh_token||'',user:data.user};
    saveAuth();
    await ensureUserProfile(data.user?.user_metadata?.display_name||'');
    loadCurrentStudent();
    loadCurrentVolunteerDraft();
    closeModal();
    updateAccountUI();
    updateAuthGate();
    updateVolunteerUI();
    render();
    renderStudentPanel();
    fetchNotes();
    showModuleChoiceModal();
    if(options.notify!==false)alert('登录成功。');
    return true;
  }catch(err){
    if(options.notify!==false)alert('登录失败：'+err.message);
    throw err;
  }
}
async function handleLandingAuthMessage(event){
  if(event.origin!==window.location.origin||event.data?.source!=='haoshengya-login')return;
  const frame=$('#authLandingFrame')?.contentWindow;
  try{
    if(event.data.action==='register'){
      showAccountModal('register');
      return;
    }
    if(event.data.action==='login'){
      await loginSupabaseWithCredentials(String(event.data.email||''),String(event.data.password||''),{notify:false});
      frame?.postMessage({source:'jiangsu-plan-auth',status:'ok'},event.origin);
    }
  }catch(err){
    frame?.postMessage({source:'jiangsu-plan-auth',status:'error',message:'登录失败：'+err.message},event.origin);
  }
}
async function ensureUserProfile(displayName=''){
  if(!auth.user?.id)return;
  try{
    await apiFetch('profiles?on_conflict=id',{method:'POST',headers:{Prefer:'resolution=ignore-duplicates'},body:JSON.stringify({id:auth.user.id,email:auth.user.email,display_name:displayName||auth.user.email,role:'consultant',status:'active'})});
  }catch(err){console.warn('创建/更新用户资料失败',err);}
}
function logoutSupabase(options={}){
  if(auth.user&&!options.skipConfirm){
    const name=currentStudent?.name?'当前学生：'+currentStudent.name+'\n':'';
    const ok=confirm(name+'退出登录前，请确认当前志愿表已经点过"保存到学生"。\n\n系统会保存这个账号自己的本地草稿，但未保存到学生的内容不会进入数据库。\n\n确定退出登录吗？');
    if(!ok)return false;
  }
  saveCurrentVolunteerDraft();
  saveCurrentStudent();
  auth={accessToken:'',refreshToken:'',user:null};
  currentStudent=null;
  currentVolunteerForm=null;
  volunteerKeys=[];
  volunteerMajorKeys={};
  volunteerMeta={};
  clearSavedAuth();
  updateAccountUI();
  updateAuthGate();
  updateVolunteerUI();
  render();
  renderStudentPanel();
  closeModal();
  alert('已退出登录。');
  return true;
}

async function fetchStudents(){
  return apiFetch('students?select=*&archived=eq.false&order=updated_at.desc');
}
async function fetchVolunteerFormSummaries(){
  return apiFetch('volunteer_forms?select=id,student_id,title,status,stage,created_at,updated_at&stage=eq.specialty&order=updated_at.desc');
}
function studentSummary(s){
  const medical=studentMedicalCodes(s);
  return stageLabel(s.stage)+'｜'+studentSubjectSummary(s)+'｜'+(s.score||'—')+'分｜位次 '+(s.rank||'—')+(medical.length?'｜体检 '+medical.join('/'):'')+((s.target_cities||[]).length?'｜城市 '+s.target_cities.join('、'):'');
}
function shortDateTime(v){
  if(!v)return '';
  const d=new Date(v);
  if(Number.isNaN(d.getTime()))return '';
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')+' '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');
}
function renderStudentPanel(){
  const body=$('#studentPanelBody');
  const subtitle=$('#studentPanelSubtitle');
  if(!body)return;
  updateAccountUI();
  if(subtitle)subtitle.textContent=currentStudent?'当前学生：'+currentStudent.name:'登录后可新增学生、保存和加载志愿表。';
  if(!supabaseConfigured()){
    body.innerHTML='<div class="account-notice"><b>还差最后一步数据库配置。</b><br>我已经把账号、学生、志愿表的前端逻辑接好了。你需要在 Supabase 创建项目，执行 <code>supabase/schema.sql</code>，再把 URL 和 anon key 填到 app.js 顶部。</div>';
    return;
  }
  if(!auth.user){
    body.innerHTML='<div class="student-empty">请先登录或注册账号，然后就可以新增学生、保存志愿表。</div><div class="student-inline-actions" style="margin-top:12px"><button class="save" id="studentLoginNow">登录/注册</button></div>';
    $('#studentLoginNow')?.addEventListener('click',function(){showAccountModal('login');});
    return;
  }
  body.innerHTML='<div class="student-empty">正在读取学生档案...</div>';
  Promise.all([fetchStudents(),fetchVolunteerFormSummaries()]).then(function(results){
    const students=results[0]||[];
    const forms=results[1]||[];
    syncCurrentStudentWithList(students);
    body.innerHTML=studentPanelHTML(students,forms);
    bindStudentMedicalPickers();
    bindStudentPanelControls(students,forms);
  }).catch(function(err){
    body.innerHTML='<div class="account-notice">读取学生失败：'+esc(err.message)+'</div>';
  });
}
function syncCurrentStudentWithList(students){
  if(!currentStudent?.id)return;
  const fresh=students.find(function(s){return s.id===currentStudent.id;});
  if(fresh){currentStudent=fresh;saveCurrentStudent();applyCurrentStudentProfileToFilters({noFilter:true});return;}
  currentStudent=null;
  currentVolunteerForm=null;
  saveCurrentStudent();
  loadCurrentVolunteerDraft();
  updateAccountUI();
  updateVolunteerUI();
}
function studentPanelHTML(students,forms){
  const formsByStudent=new Map();
  forms.forEach(function(f){
    const arr=formsByStudent.get(f.student_id)||[];
    arr.push(f);
    formsByStudent.set(f.student_id,arr);
  });
  const account='<div class="student-account-box"><b>'+esc(auth.user?.email||'已登录')+'</b><span class="muted">'+(currentStudent?'当前学生：'+esc(currentStudent.name):'尚未选择学生')+'</span></div>';
  const form='<section class="student-account-box"><b>新增学生</b><div class="student-form-grid">'+
    '<label>姓名<input id="newStudentName" placeholder="学生姓名"></label>'+
    '<label>手机号<input id="newStudentPhone" placeholder="可选"></label>'+
    '<label>批次<select id="newStudentStage"><option value="specialty" selected>专科</option><option value="undergraduate">本科</option></select></label>'+
    '<label>科类<select id="newStudentSubject"><option value="physics">物理</option><option value="history">历史</option></select></label>'+
    '<div class="wide student-choice-field"><span>再选科目</span>'+subjectChoicesInputsHTML('newStudentSubjects',[])+'</div>'+
    '<label>分数<input id="newStudentScore" type="number" placeholder="例如 586"></label>'+
    '<label>位次<input id="newStudentRank" type="number" placeholder="例如 39000"></label>'+
    '<label class="wide">目标城市<input id="newStudentCities" placeholder="南京、苏州、上海"></label>'+
    '<div class="wide student-choice-field"><span>体检代码</span>'+medicalCodePickerHTML('newStudentMedical',[])+'<input id="newStudentMedical" placeholder="也可手动输入，如 21 35，可空"></div>'+
    '</div><div class="student-inline-actions"><button id="createStudentBtn" class="save" type="button">新增学生</button><button id="refreshStudentsBtn" type="button">刷新列表</button></div></section>';
  const list=students.length?'<div class="student-list">'+students.map(function(s){
    const savedForms=formsByStudent.get(s.id)||[];
    const formList=savedForms.length?'<div class="student-form-list"><div class="student-form-list-title"><span>已保存志愿表</span><span>'+savedForms.length+' 份</span></div>'+savedForms.slice(0,8).map(function(f){return '<div class="student-form-row"><span>'+esc(f.title||'未命名志愿表')+'<small>'+esc(shortDateTime(f.updated_at||f.created_at))+'</small></span><button type="button" data-load-form="'+esc(f.id)+'">加载</button></div>';}).join('')+(savedForms.length>8?'<div class="muted" style="font-size:12px">仅显示最近 8 份。</div>':'')+'</div>':'<div class="student-form-list"><div class="muted" style="font-size:12px">还没有保存过志愿表。</div></div>';
    return '<article class="student-card '+(currentStudent?.id===s.id?'active':'')+'" data-student-id="'+esc(s.id)+'"><div class="student-card-head"><div><h4>'+esc(s.name)+'</h4><p>'+esc(studentSummary(s))+'</p></div><span class="badge">'+esc(stageLabel(s.stage))+'</span></div><div class="student-actions"><button class="save" data-select-student="'+esc(s.id)+'">设为当前</button><button data-edit-student="'+esc(s.id)+'">编辑档案</button><button data-save-for-student="'+esc(s.id)+'">保存当前志愿表</button><button data-load-latest-form="'+esc(s.id)+'">加载最近志愿表</button><button data-new-draft-for-student="'+esc(s.id)+'">新建空草稿</button></div>'+formList+'</article>';
  }).join('')+'</div>':'<div class="student-empty">还没有学生。先新增一个学生，然后在志愿表里点"保存到学生"。</div>';
  return account+form+list;
}
function bindStudentPanelControls(students,forms){
  const byId=new Map(students.map(function(s){return [s.id,s];}));
  const formById=new Map(forms.map(function(f){return [f.id,f];}));
  $('#createStudentBtn')?.addEventListener('click',createStudentFromPanel);
  $('#refreshStudentsBtn')?.addEventListener('click',renderStudentPanel);
  $$('[data-select-student]').forEach(function(btn){btn.addEventListener('click',function(){
    setCurrentStudent(byId.get(btn.dataset.selectStudent)||null);
  });});
  $$('[data-edit-student]').forEach(function(btn){btn.addEventListener('click',function(){
    showStudentEditor(byId.get(btn.dataset.editStudent)||null);
  });});
  $$('[data-save-for-student]').forEach(function(btn){btn.addEventListener('click',async function(){
    currentStudent=byId.get(btn.dataset.saveForStudent)||null;
    saveCurrentStudent();
    applyCurrentStudentProfileToFilters({noFilter:true});
    saveCurrentVolunteerDraft();
    await saveCurrentVolunteerForm();
  });});
  $$('[data-load-latest-form]').forEach(function(btn){btn.addEventListener('click',async function(){
    saveCurrentVolunteerDraft();
    currentStudent=byId.get(btn.dataset.loadLatestForm)||null;
    saveCurrentStudent();
    applyCurrentStudentProfileToFilters({noFilter:true});
    await loadLatestVolunteerFormForStudent(currentStudent,{skipDraftSave:true});
  });});
  $$('[data-load-form]').forEach(function(btn){btn.addEventListener('click',async function(){
    const form=formById.get(btn.dataset.loadForm);
    if(!form)return;
    saveCurrentVolunteerDraft();
    currentStudent=byId.get(form.student_id)||currentStudent;
    saveCurrentStudent();
    applyCurrentStudentProfileToFilters({noFilter:true});
    await loadVolunteerForm(form,{skipDraftSave:true});
  });});
  $$('[data-new-draft-for-student]').forEach(function(btn){btn.addEventListener('click',function(){
    setCurrentStudent(byId.get(btn.dataset.newDraftForStudent)||null,{loadDraft:false,clearDraft:true});
  });});
}
function showStudentEditor(student){
  if(!student)return;
  const choices=studentSubjectChoices(student);
  $('#modal').innerHTML='<h3>编辑学生档案</h3><div class="modal-body"><div class="student-form-grid student-edit-grid">'+
    '<label>姓名<input id="editStudentName" value="'+esc(student.name||'')+'" placeholder="学生姓名"></label>'+
    '<label>手机号<input id="editStudentPhone" value="'+esc(student.phone||'')+'" placeholder="可选"></label>'+
    '<label>批次<select id="editStudentStage"><option value="undergraduate" '+(stageValue(student.stage)==='undergraduate'?'selected':'')+'>本科</option><option value="specialty" '+(stageValue(student.stage)==='specialty'?'selected':'')+'>专科</option></select></label>'+
    '<label>科类<select id="editStudentSubject"><option value="physics" '+(subjectTypeValue(student.subject_type)==='physics'?'selected':'')+'>物理</option><option value="history" '+(subjectTypeValue(student.subject_type)==='history'?'selected':'')+'>历史</option></select></label>'+
    '<div class="wide student-choice-field"><span>再选科目</span>'+subjectChoicesInputsHTML('editStudentSubjects',choices)+'</div>'+
    '<label>分数<input id="editStudentScore" type="number" value="'+esc(student.score??'')+'" placeholder="例如 586"></label>'+
    '<label>位次<input id="editStudentRank" type="number" value="'+esc(student.rank??'')+'" placeholder="例如 39000"></label>'+
    '<label class="wide">目标城市<input id="editStudentCities" value="'+esc((student.target_cities||[]).join('、'))+'" placeholder="南京、苏州、上海"></label>'+
    '<div class="wide student-choice-field"><span>体检代码</span>'+medicalCodePickerHTML('editStudentMedical',student.medical_codes||[])+'<input id="editStudentMedical" value="'+esc((student.medical_codes||[]).join(' '))+'" placeholder="也可手动输入，如 21 35，可空"></div>'+
    '</div><div class="modal-actions"><button type="button" onclick="document.getElementById(\'modalMask\').classList.remove(\'open\')">取消</button><button id="updateStudentBtn" class="save" type="button">保存修改</button></div></div>';
  openModal();
  bindStudentMedicalPickers();
  $('#updateStudentBtn')?.addEventListener('click',function(){updateStudentFromModal(student.id);});
}
async function updateStudentFromModal(studentId){
  if(!requireLogin())return;
  const name=$('#editStudentName').value.trim();
  if(!name){alert('请填写学生姓名。');return;}
  const subjectChoices=subjectChoicesFromInputs('editStudentSubjects');
  const payload={name:name,phone:$('#editStudentPhone').value.trim()||null,province:'江苏',stage:stageValue($('#editStudentStage').value),subject_type:subjectTypeValue($('#editStudentSubject').value),subject_choices:subjectChoices,score:dbInteger($('#editStudentScore').value),rank:dbInteger($('#editStudentRank').value),target_cities:splitListInput($('#editStudentCities').value),medical_codes:studentMedicalCodesFromInputs('editStudentMedical','#editStudentMedical')};
  try{
    const rows=await writeStudentRecord('students?id=eq.'+encodeURIComponent(studentId),'PATCH',payload);
    const updated={...(rows?.[0]||payload),id:studentId,owner_id:auth.user.id,subject_choices:subjectChoices};
    saveLocalStudentSubjectChoices(studentId,subjectChoices);
    if(currentStudent?.id===studentId){
      currentStudent=updated;
      saveCurrentStudent();
      applyCurrentStudentProfileToFilters({noFilter:true});
      cleanupVolunteerForSubjectRequirements();
    }
    closeModal();
    updateAccountUI();
    updateVolunteerUI();
    render();
    renderVolunteerPanel();
    renderStudentPanel();
    alert('学生档案已更新。');
  }catch(err){alert('更新学生失败：'+err.message);}
}
function setCurrentStudent(student,options){
  if(!options)options={};
  saveCurrentVolunteerDraft();
  currentStudent=student||null;
  currentVolunteerForm=null;
  saveCurrentStudent();
  if(options.clearDraft){
    volunteerKeys=[];
    volunteerMajorKeys={};
    volunteerMeta={};
    saveCurrentVolunteerDraft();
  }else if(options.loadDraft!==false){
    loadCurrentVolunteerDraft();
  }
  applyCurrentStudentProfileToFilters({noFilter:true});
  cleanupVolunteerForSubjectRequirements();
  updateAccountUI();
  updateVolunteerUI();
  renderVolunteerPanel();
  render();
  renderStudentPanel();
}
async function createStudentFromPanel(){
  if(!requireLogin())return;
  const name=$('#newStudentName').value.trim();
  if(!name){alert('请填写学生姓名。');return;}
  const subjectChoices=subjectChoicesFromInputs('newStudentSubjects');
  try{
    const rows=await writeStudentRecord('students','POST',{owner_id:auth.user.id,name:name,phone:$('#newStudentPhone').value.trim()||null,province:'江苏',stage:stageValue($('#newStudentStage').value),subject_type:subjectTypeValue($('#newStudentSubject').value),subject_choices:subjectChoices,score:dbInteger($('#newStudentScore').value),rank:dbInteger($('#newStudentRank').value),target_cities:splitListInput($('#newStudentCities').value),medical_codes:studentMedicalCodesFromInputs('newStudentMedical','#newStudentMedical')});
    currentStudent={...rows[0],subject_choices:subjectChoices};
    saveLocalStudentSubjectChoices(currentStudent.id,subjectChoices);
    volunteerKeys=[];
    volunteerMajorKeys={};
    volunteerMeta={};
    saveCurrentStudent();
    applyCurrentStudentProfileToFilters({noFilter:true});
    saveCurrentVolunteerDraft();
    updateAccountUI();
    updateVolunteerUI();
    render();
    renderStudentPanel();
    alert('学生已新增。');
  }catch(err){alert('新增学生失败：'+err.message);}
}
function groupPayloadForSave(key,index){
  const rec=getGroupRecord(key);
  if(!rec)return null;
  const {s,g}=rec;
  const meta=volunteerMeta[key]||{};
  return {form_id:null,owner_id:auth.user.id,position:index+1,group_key:key,school_name:s.name,school_code:s.schoolCode||null,province:s.province||null,city:s.city||null,batch:s.batch||null,subject:s.subject||null,group_name:g.groupName,group_code:g.groupCode||null,group_alias:groupDisplayName(s,g)||null,requirement:g.requirement||null,plan26:dbInteger(g.plan26),plan25:dbInteger(g.plan25),score25:dbNumber(g.score25),rank25:dbInteger(g.rank25),avg_score3:dbNumber(g.avgScore3),avg_rank3:dbInteger(g.avgRank3),strategy:meta.strategy||'待定',obey_adjustment:true,note:meta.note||null,source_payload:{group:g}};
}
function majorPayloadsForSave(groupKey,dbGroupId){
  const rec=getGroupRecord(groupKey);
  if(!rec)return [];
  const byKey=new Map((rec.g.majors||[]).map(function(m){return [m.key,m];}));
  return selectedMajorOrder(groupKey).map(function(majorKey,index){
    const m=byKey.get(majorKey);
    if(!m)return null;
    return {form_group_id:dbGroupId,owner_id:auth.user.id,position:index+1,major_key:majorKey,major_code:m.code||null,major_name:m.name,major_class:m.majorClass||null,discipline:m.discipline||null,plan26:dbInteger(m.plan26),plan25:dbInteger(m.plan25),score25:dbNumber(m.score25),rank25:dbInteger(m.rank25),avg_score3:dbNumber(m.avgScore3),avg_rank3:dbInteger(m.avgRank3),source_payload:{major:m}};
  }).filter(Boolean);
}
async function replaceVolunteerFormGroups(formId){
  const oldGroups=await apiFetch('volunteer_form_groups?select=id&form_id=eq.'+encodeURIComponent(formId));
  const oldIds=(oldGroups||[]).map(function(g){return g.id;}).filter(Boolean);
  if(oldIds.length)await apiFetch('volunteer_form_majors?form_group_id=in.('+oldIds.join(',')+')',{method:'DELETE'});
  await apiFetch('volunteer_form_groups?form_id=eq.'+encodeURIComponent(formId),{method:'DELETE'});
}
async function saveCurrentVolunteerForm(){
  if(!requireSupabase()||!requireLogin())return;
  if(!currentStudent){alert('请先到学生档案新增或选择一个学生。');openStudentDirectory();return;}
  if(!volunteerKeys.length){alert('当前志愿表为空，先加入专业组后再保存。');return;}
  try{
    const title=currentStudent.name+' 专科志愿表 '+localDateStamp();
    const payload={student_id:currentStudent.id,owner_id:auth.user.id,title:currentVolunteerForm?.title||title,stage:'specialty',source_version:VERSION,max_group_count:VOLUNTEER_LIMIT,snapshot:{volunteerKeys,volunteerMajorKeys,volunteerMeta,medicalCodes:[...state.medicalCodes]}};
    const editingId=currentVolunteerForm?.id;
    const forms=editingId
      ? await apiFetch('volunteer_forms?id=eq.'+encodeURIComponent(editingId),{method:'PATCH',headers:{Prefer:'return=representation'},body:JSON.stringify(payload)})
      : await apiFetch('volunteer_forms',{method:'POST',headers:{Prefer:'return=representation'},body:JSON.stringify(payload)});
    if(editingId&&!forms?.length)throw new Error('没有权限更新这份志愿表，或记录已不存在。');
    const form=forms?.[0]||{...payload,id:editingId};
    if(editingId)await replaceVolunteerFormGroups(editingId);
    const groupRows=volunteerKeys.map(function(key,index){return groupPayloadForSave(key,index);}).filter(Boolean).map(function(row){return {...row,form_id:form.id};});
    const savedGroups=groupRows.length?await apiFetch('volunteer_form_groups',{method:'POST',headers:{Prefer:'return=representation'},body:JSON.stringify(groupRows)}):[];
    const majorRows=savedGroups.flatMap(function(row){return majorPayloadsForSave(row.group_key,row.id);});
    if(majorRows.length)await apiFetch('volunteer_form_majors',{method:'POST',headers:{Prefer:'return=representation'},body:JSON.stringify(majorRows)});
    currentVolunteerForm=form;
    saveCurrentVolunteerDraft();
    updateAccountUI();
    renderStudentPanel();
    alert((editingId?'已更新':'已保存')+'到 '+currentStudent.name+'：'+groupRows.length+' 个专业组，'+majorRows.length+' 个专业。');
  }catch(err){alert('保存志愿表失败：'+err.message);}
}
async function loadLatestVolunteerFormForStudent(student,options){
  if(!options)options={};
  if(!student||!requireSupabase()||!requireLogin())return;
  try{
    const forms=await apiFetch('volunteer_forms?select=*&student_id=eq.'+encodeURIComponent(student.id)+'&order=updated_at.desc&limit=1');
    if(!forms.length){alert('这个学生还没有保存过志愿表。');return;}
    await loadVolunteerForm(forms[0],options);
  }catch(err){alert('加载志愿表失败：'+err.message);}
}
async function loadVolunteerForm(form,options){
  if(!options)options={};
  if(!options.skipDraftSave)saveCurrentVolunteerDraft();
  const groups=await apiFetch('volunteer_form_groups?select=*&form_id=eq.'+encodeURIComponent(form.id)+'&order=position.asc');
  const ids=groups.map(function(g){return g.id;});
  const majors=ids.length?await apiFetch('volunteer_form_majors?select=*&form_group_id=in.('+ids.join(',')+')&order=position.asc'):[];
  const groupById=new Map(groups.map(function(g){return [g.id,g];}));
  volunteerKeys=groups.map(function(g){return g.group_key;}).filter(function(k){return groupIndex.has(k);}).slice(0,VOLUNTEER_LIMIT);
  volunteerMeta={};
  volunteerMajorKeys={};
  groups.forEach(function(g){
    if(!groupIndex.has(g.group_key))return;
    volunteerMeta[g.group_key]={strategy:g.strategy==='待定'?'':g.strategy,obey:g.obey_adjustment?'是':'否',note:g.note||''};
    volunteerMajorKeys[g.group_key]=[];
  });
  majors.forEach(function(m){
    const g=groupById.get(m.form_group_id);
    if(!g||!volunteerMajorKeys[g.group_key])return;
    volunteerMajorKeys[g.group_key].push(m.major_key);
  });
  volunteerKeys.forEach(ensureVolunteerSelection);
  currentVolunteerForm=form;
  saveCurrentVolunteerDraft();
  updateVolunteerUI();
  renderVolunteerPanel();
  render();
  renderStudentPanel();
  openPanel('volunteerPanel');
  alert('已加载：'+form.title);
}
async function recordVolunteerExportIfPossible(rowCount){
  if(!supabaseConfigured()||!auth.accessToken||!currentStudent||!currentVolunteerForm)return;
  try{
    await apiFetch('volunteer_exports',{method:'POST',body:JSON.stringify({form_id:currentVolunteerForm.id,student_id:currentStudent.id,owner_id:auth.user.id,format:'xls',file_name:'江苏志愿基础表_'+localDateStamp()+'.xls',group_count:volunteerKeys.length,major_count:Object.values(volunteerMajorKeys).reduce(function(sum,keys){return sum+(Array.isArray(keys)?keys.length:0);},0),source_payload:{rowCount}})});
  }catch(err){console.warn('记录导出失败',err);}
}

function init(){
  ensureAccountStyles();
  loadSavedAuth();
  loadCurrentStudent();
  loadCurrentVolunteerDraft();
  buildGroupIndex();
  createLayout();
  initFilters();
  buildProvincePanel();
  buildLevelPanel();
  buildSpecialPanel();
  buildRequirementPanel();
  buildClassPanel();
  updateProvinceButton();
  updateLevelButton();
  updateSpecialButton();
  updateRequirementButton();
  updateClassButton();
  bindEvents();
  applyCurrentStudentProfileToFilters({noFilter:true});
  updateVolunteerUI();
  updateAccountUI();
  updateAuthGate();
  applyFilters();
  fetchNotes();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init); else init();
})();
